<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/21
 * Time: 5:42 AM
 */

class Sales extends Controller
{
    private $salesModel;
    private $productModel;


    public function __construct()
    {
        $this->salesModel = $this->model('Sale');
        $this->productModel = $this->model('Product');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function reception()
    {
        $data = ['title' => 'Reception', 'description' => 'Page for new requests'];
        $template = [];
        $template['page_script'] = 'reception';
        $this->view('operations/reception', $data, $template);
    }

    public function orders()
    {
        $data = ['title' => 'Orders', 'description' => 'Page for Viewing Orders'];
        $template = [];
        $template['page_script'] = 'orders';
        $this->view('admin/orders', $data, $template);
    }

    public function order($id)
    {
        $data = ['title' => 'Order', 'description' => 'Page for Viewing Order Details', 'orderId' => $id];
        $template = [];
        $template['page_script'] = 'order';
        $this->view('operations/order', $data, $template);
    }

    private function getProductFieldsWithValues($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $fields = $this->salesModel->getProductFieldsWithValues($id);
        return $fields;

    }

    private function getSaleItemProcesses($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $processes = $this->salesModel->getSaleItemProcesses($id);
        return $processes;

    }

    private function getFieldValues($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $fields = $this->salesModel->getFieldValues($id);
        return $fields;

    }

    private function addOrder($orderDetails)
    {
        $customerId = $orderDetails['customerId'];
        $dateDue = $orderDetails['dateDue'];
        $datePlaced = $orderDetails['datePlaced'];
        $discount = $orderDetails['discount'];

        return $this->salesModel->addOrder($customerId, $dateDue, $datePlaced, $discount);
    }

    private function addItem($itemDetails)
    {
        $orderId = $itemDetails['orderId'];
        $productId = $itemDetails['productId'];
        $productType = $itemDetails['productType'];
        $quantity = $itemDetails['quantity'];
        $price = $itemDetails['price'];
        $priceCurrencyId = $itemDetails['priceCurrencyId'];

        $newItemId = $this->salesModel->addItem($orderId, $productId, $productType, $quantity, $price, $priceCurrencyId);
        $this->salesModel->addItemProcesses($newItemId, $productId);
        return $newItemId;

    }

    private function submitOrder($data)
    {
        $fieldDataTypeIds = [
            'text' => 1,
            'number' => 2,
            'date' => 3,
            'file' => 4];
        $fieldTypeIds = [
            'free' => 1,
            'bound' => 2

        ];
//        {
//            "itemFieldValues":[{
//            "fieldId":"4","fieldValue":"8","fieldType":"2"},{
//            "fieldId":"5","fieldValue":"jaafar","fieldType":"1"}]
//        }
        $itemFieldValues = $data['itemFieldValues'];
        $itemId = $data['itemId'];
        foreach ($itemFieldValues as $itemFieldValue) {
            $fieldId = $itemFieldValue['fieldId'];
            $fieldValue = $itemFieldValue['fieldValue'];
            $fieldType = $itemFieldValue['fieldType'];
            if ($fieldType == $fieldTypeIds['free']) {
                $fieldValueId = $this->salesModel->addFieldValue($fieldId, $fieldType, $fieldValue);
            }
            else {
                $fieldValueId = $fieldValue;
            }
            $this->salesModel->addItemValue($itemId, $fieldValueId);
        }
        return 1;
    }

    private function editOrderItem($data)
    {
        /*
            [itemId] => 56
            [itemFieldValues] => Array
                (
                    [0] => Array
                        (
                            [fieldId] => 7
                            [salesItemValueId] => 90
                            [fieldValue] => file testing 12
                            [fieldType] => 1
                        )
                )
         */
        $fieldDataTypeIds = [
            'text' => 1,
            'number' => 2,
            'date' => 3,
            'file' => 4];
        $fieldTypeIds = [
            'free' => 1,
            'bound' => 2

        ];
        $salesItemValueId = $data['itemFieldValues'][0]['salesItemValueId'];
        $fieldValue = $data['itemFieldValues'][0]['fieldValue'];
        $fieldType = $data['itemFieldValues'][0]['fieldType'];

        if ($fieldType == $fieldTypeIds['free']) {
            echo $this->salesModel->updateSalesItemValue($salesItemValueId, $fieldValue, 'free');
        }
        else {
            echo $this->salesModel->updateSalesItemValue($salesItemValueId, $fieldValue, 'bound');
        }
    }

    private function salesItemFile($salesItemId, $newFileId)
    {
//        unlink('test.html');
        $file = $_POST['file'];
        $temporary = explode(".", $file);
        $fileExtension = end($temporary);
        $fileUrl = FILEROOT . 'files\\sales_order_items\\' . $salesItemId . '\\' . $newFileId . '.' . $fileExtension;
        echo $fileUrl;
    }

    public function addFile($file, $fieldTypeId = 1, $salesItemId, $fieldId)
    {

        /*
         * field types and their respective Ids
         * free : 1
         * bound : 2
         */
        if (isset($file["type"])) {
            $fileValidationResponse = $this->validateFile($file);
            if ($fileValidationResponse['response']) {
                //set the variables needed
                $orderFilesDirectory = FILEROOT . 'files\\sales_order_items\\';
                $directory = $orderFilesDirectory . $salesItemId;
                if (!file_exists($directory)) {
                    mkdir($directory);
                }
                $fileDirectory = $directory . '\\';
                $fileExtension = $fileValidationResponse['extension'];
                $fileDetails = [];
                $fileDetails['name'] = $file['name'];
                $fileDetails['fieldTypeId'] = $fieldTypeId;
                $fileDetails['itemId'] = $salesItemId;
                $fileDetails['fieldId'] = $fieldId;
                $newFileId = $this->salesModel->addFile($fileDetails);
                //newFileId is the id of the fieldValue holding the file
                $newFileName = $newFileId . '.' . $fileExtension;
                $isUploaded = $this->uploadFile($file, $fileDirectory, $newFileName);
                if ($isUploaded) {
                    $fileUrl = URLROOT . '/public/files/sales_order_items/' . $salesItemId . '/' . $newFileId . '.' . $fileExtension;
                    $fileUrlChangeSuccess = $this->salesModel->updateFileURL($newFileId, $fileUrl);
                    if ($fileUrlChangeSuccess) {
                        return $newFileId;
                    }
                    else {
                        return 'Image URL Change Failed';
                    }
                }
                else {
                    return 'Upload Failed';
                }
            }
            else {
                return $fileValidationResponse['err_msg'];
            }
        }
        else {
            return '***Invalid Request***';
        }
    }

    public function replaceFile($file, $fieldTypeId = 1, $salesItemId, $fieldId, $currentFileId)
    {

        /*
         * field types and their respective Ids
         * free : 1
         * bound : 2
         */
        if (isset($file["type"])) {
            $fileValidationResponse = $this->validateFile($file);
            if ($fileValidationResponse['response']) {
                //set the variables needed
                $orderFilesDirectory = FILEROOT . 'files\\sales_order_items\\';
                $directory = $orderFilesDirectory . $salesItemId;
                $fileDirectory = $directory . '\\';
                $fileExtension = $fileValidationResponse['extension'];
                $fileDetails = [];
                $fileDetails['name'] = $file['name'];
                $fileDetails['fieldTypeId'] = $fieldTypeId;
                $fileDetails['itemId'] = $salesItemId;
                $fileDetails['fieldId'] = $fieldId;
//                $newFileId = $this->salesModel->addFile($fileDetails);
                //newFileId is the id of the fieldValue holding the file
                $newFileName = $currentFileId . '.' . $fileExtension;
                $this->removeFile($fileDirectory . $currentFileId . '.*');
                $isUploaded = $this->uploadFile($file, $fileDirectory, $newFileName);
                if ($isUploaded) {
                    echo($fileDirectory . $currentFileId . '.' . $fileExtension);
                    return $currentFileId;
                }
                else {
                    return 'Upload Failed';
                }
            }
            else {
                return $fileValidationResponse['err_msg'];
            }
        }
        else {
            return '***Invalid Request***';
        }
    }

    private function validateFile($file)
    {
        $response = ['response' => '', 'err_msg' => 'none'];
        //$validextensions = array("jpeg", "jpg", "png");

        //this explodes the name by the . so that we get the extension of the file
        $temporary = explode(".", $file["name"]);
        $file_extension = end($temporary);
        $file_extension = strtolower($file_extension);
        //check for valid file types
        if (($file["size"] < 10000000)) {

            //check if image has any errors
            if ($file["error"] > 0) {
                $response['response'] = false;
                $response['err_msg'] = "Error Code: " . $file["error"];
            }

            //this means image is validated
            else {
                $response['response'] = true;
                $response['extension'] = $file_extension;
            }
        }
        else {
            $response['response'] = false;
            if ($file["error"] > 0) {
                $response['err_msg'] = "Error Code: " . $file["error"];
            }

            $response['response'] = '***Invalid file Size or Type***';
        }
        return $response;

    }

    public function removeFile($path)
    {
//        unlink($path);
        array_map('unlink', glob($path));
    }

    private function updateOrder($orderDetails)
    {
        foreach ($orderDetails as $key => $value) {
            $newKey = self::camelCaseToUnderscore($key);
            if ($newKey != $key) {
                $orderDetails[$newKey] = $value;
                unset($orderDetails[$key]);
            }
        }
        return $this->salesModel->updateOrder($orderDetails);
    }

    private function updateItemQuantity($itemQuantity)
    {
        return $this->salesModel->updateItemQuantity($itemQuantity);
    }

    public function uploadFile($file, $directory, $newName)
    {
        $filename = $newName;
        $sourcePath = $file['tmp_name']; // Storing source path of the file in a variable
//        $sourcePath = str_replace('\\','/',$sourcePath);
        $targetPath = $directory . $filename; // Target path where file is to be stored
        $uploadSuccess = move_uploaded_file($sourcePath, $targetPath);
        if ($uploadSuccess) {
            return true;
        } // Moving Uploaded file
        else {
            return false;
        }
    }

    private function updateItemProcesses($processes)
    {
        $processes = $processes['processes'];
        foreach ($processes as $process){
            $processStatusIdList = [
                'true'=>2,
                'false'=>1
            ];
            $salesItemProcessId = $process['salesItemProcessId'];
            $processStatus = $processStatusIdList[$process['processStatus']];
            $this->salesModel->updateItemProcess( $salesItemProcessId, $processStatus);
        }
        return 1;
    }

    public function requests($request)
    {
        switch ($request) {
            case 'getAllProducts':
                if (isset(func_get_args()[1])) {

                    if (func_get_args()[1] == 'datatablesEncode') {
                        echo $this->datatables_encode($this->productModel->getAllProducts());
                    }
                    else {
                        echo $this->encode_json($this->productModel->getAllProducts());
                    }
                }
                else {
                    echo $this->encode_json($this->productModel->getAllProducts());
                }
                break;
            case 'getOrders':
                echo $this->datatables_encode($this->salesModel->getOrders());
                break;
            case 'getOrder':
                if (isset($_GET)) {
                    echo $this::encode_json($this->salesModel->getOrder($_GET['orderId']));
                }
                break;
            case 'getProductFieldsWithValues':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json($this->getProductFieldsWithValues($id));
                    break;
                }
            case 'getSaleItemProcesses':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json($this->getSaleItemProcesses($id));
                    break;
                }
            case 'getFieldValues':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json($this->getFieldValues($id));
                    break;
                }
            case 'addOrder':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $orderId = $this->addOrder($_POST);
                    echo $orderId;
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addItem':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addItem($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'submitOrder':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->submitOrder($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'editOrderItem':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->editOrderItem($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'updateItemProcesses':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->updateItemProcesses($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'uploadFile':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    if ($_POST['fieldTypeId']) {
                        $fieldTypeId = $_POST['fieldTypeId'];
                    }
                    else {
                        //set as bound
                        $fieldTypeId = 2;
                    }
                    $itemId = $_POST['itemId'];
                    $fieldId = $_POST['fieldId'];
                    echo $this->addFile($_FILES['file'], $fieldTypeId, $itemId, $fieldId);
                }
                break;
            case 'replaceFile':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    if ($_POST['fieldTypeId']) {
                        $fieldTypeId = $_POST['fieldTypeId'];
                    }
                    else {
                        //set as bound
                        $fieldTypeId = 2;
                    }
                    $itemId = $_POST['itemId'];
                    $fieldId = $_POST['fieldId'];
                    $fileId = $_POST['currentFileId'];
                    echo $this->replaceFile($_FILES['file'], $fieldTypeId, $itemId, $fieldId, $fileId);
                }
                break;
            case 'updateOrder':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->updateOrder($_POST);
                }
                break;
            case 'updateItemQuantity':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->updateItemQuantity($_POST);
                }
                break;

            default:
                echo "invalid request";
                break;
        }
    }
}

?>