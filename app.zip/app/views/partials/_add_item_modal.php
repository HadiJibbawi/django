<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 01/02/21
 * Time: 10:15 AM
 */

if (!isset($pane_properties)) {
    die('invalid small pane parameters');
}
if (!isset($pane_properties['colsize'])) {
    $pane_properties['colsize'] = 'col-3';
}
if (!isset($pane_properties['margin-top'])) {
    $pane_properties['margin-top'] = 'mt-5';
}
if (!isset($pane_properties['margin-left'])) {
    $pane_properties['margin-left'] = 'ml-5';
}
if (!isset($pane_properties['itemName'])) {
    die('need to supply item name');
}
if (!isset($pane_properties['modalTitle'])) {
    $pane_properties['modalTitle'] = 'Add ' . $pane_properties['itemName'];
}
if (!isset($pane_properties['modalId'])) {
    $pane_properties['modalId'] = 'add_' . $pane_properties['itemName'] . '_modal';
}
if (!isset($pane_properties['formName'])) {
    $pane_properties['formName'] = 'add_' . $pane_properties['itemName'] . '_form';
}
if (!isset($pane_properties['autoComplete'])) {
    $pane_properties['autoComplete'] = ' autocomplete="off" ';
}
$values = $pane_properties['values'];
?>
<!--Add Product Type Modal-->
<div id="<?php echo $pane_properties['modalId'] ?>" class="modal show" style="z-index: 1110;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="<?php echo $pane_properties['modalId'] ?>_label"><?php echo $pane_properties['modalTitle'] ?></h5>
                <button type="button" class="close" data-dismiss="modal" data-bind="click:function(){$('#<?php echo $pane_properties['modalId'] ?>').modal('hide')}">
                    <span>×</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="<?php echo $pane_properties['formName'] ?>" autocomplete="off">
                    <?php

                    foreach ($values as $value) {

                        if (isset($value['noNewRow'])) {
                            $noNewRow = true;
                        }
                        else {
                            $noNewRow = false;
                        }
                        if (isset($value['oldRow'])) {
                            $oldRow = true;
                        }
                        else {
                            $oldRow = false;
                        }
                        if (isset($value['colSize'])) {
                            $colSize = $value['colSize'];
                        }
                        else {
                            $colSize = 'col-12';
                        }
                        $randomNum = random_int(1, 10000);
                        $randomId = $value['title'] . $randomNum;
                        $name = $value['name'];
                        if (isset($value['placeholder'])) {
                            $placeholder = $value['placeholder'];
                        }
                        else {
                            $placeholder = ucfirst($value['title']);
                        }
                        $required = $value['required'] == 'false' ? '' : 'required';
                        if ($required){
                            $requiredString = '*';
                        }
                        else{
                            $requiredString = '';
                        }
                        $label = '<label for="' . $randomId . '" style="font-size: 1rem;font-weight: bold;">' . ucfirst($value['title']) . ' :'.$requiredString.'</label>';
                        if (isset($value['enable'])) {
                            if ($value['enable'] == 'true') {
                                $randomIdEnable = $randomId . 'check';
                                $enableHandle = $value['enableHandle'];
                                $labelEnable = '<label for="' . $randomIdEnable . '" style="font-size: 1rem;font-weight: bold">Enable :</label>';
                                $checkBoxEnable = '<input id="' . $randomIdEnable . '" type="checkbox" data-bind="checked: ' . $enableHandle . '">';
                                $enableString = "<div>\n" . $labelEnable . "\n" . $checkBoxEnable . "\n</div>";
                                $enableDataBindString = ',enable: ' . $enableHandle;
                            }
                            else {
                                if (isset($value['enableHandle'])) {
                                    $enableDataBindString = ',enable: ' . $value['enableHandle'];
                                }
                                else {
                                    $enableDataBindString = '';
                                }
                                $enableString = '';
                            }
                        }
                        else {
                            $enableDataBindString = '';
                            $enableString = '';
                        }
                        if ($value['type'] != 'select' && $value['type'] != 'button') {
                            $type = $value['type'];
                            $textInput = $value['value'];
                            $input = '<input  id="' . $randomId . '" '. $pane_properties['autoComplete'] .' type="' . $type . '" name="' . $name . '"  data-bind="textInput : ' . $textInput . ' ' . $enableDataBindString . '" placeholder="' . $placeholder . '" class="form-control mb-4 " ' . $required . ' />';
                        }
                        elseif ($value['type'] == 'button') {
                            if (isset($value['buttonClass'])) {
                                $buttonClass = $value['buttonClass'];
                            }
                            else {
                                $buttonClass = 'btn btn-primary';
                            }
                            if (isset($value['buttonClick'])) {
                                $buttonClick = $value['buttonClick'];
                            }
                            else {
                                $buttonClick = '';
                            }
                            $input = '<button type="button" class="' . $buttonClass . '" id="' . $randomId . '" data-bind="click:' . $buttonClick . ' ' . $enableDataBindString . '">' . ucfirst($value['title']) . '</button>';

                        }
                        else {
                            $options = $value['options'];
                            //this is the value of the javascript object to hold the chosen value
                            $valueOptions = $value['value'];
                            $caption = $value['caption'];

                            if (isset($value['optionsValue'])) {
                                $optionsValue = $value['optionsValue'];
                                $optionsValueString = ',optionsValue : \'' . $optionsValue . '\'';
                                if (isset($value['optionsText'])) {
                                    $optionsText = $value['optionsText'];
                                    $optionsValueString .= ',optionsText:\'' . $optionsText . '\'';
                                }
                            }
                            else {
                                $optionsValueString = '';
                            }
                            $input = '<select class="form-control mb-4" name="' . $name . '" id="' . $randomId . '" data-bind="options : ' . $options . ',value:' . $valueOptions . $optionsValueString . ',optionsCaption:\'' . $caption . '\' ' . $enableDataBindString . '"  ' . $required . ' ></select>';
                        }
                        if (!$oldRow) {
                            echo '<div class="row">';
                        }

                        echo '<div class="' . $colSize . '">';
                        echo $label;
                        echo $enableString;
                        echo $input;
                        echo '</div>';
                        if (!$noNewRow) {
                            echo '</div>';
                        }
                    }

                    $clearValuesFunction = '$root.clearNew' . $pane_properties['itemName'] . 'Modal';
                    $submitValuesFunction = '$root.add' . $pane_properties['itemName'];
                    ?>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:<?php echo $clearValuesFunction ?>">Clear</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" data-bind="click:function(){$('#<?php echo $pane_properties['modalId'] ?>').modal('hide')}">Close</button>
                        <button id="save_new_<?php echo $pane_properties['itemName']?>_btn" type="button" data-bind="click:<?php echo $submitValuesFunction ?>" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
