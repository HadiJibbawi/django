<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 05/03/21
 * Time: 6:16 PM
 */
?>

<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-around">
        <!--        --><?php
        //        $pane_properties = [];
        //        $pane_properties['emptyValueCheck'] = '$root.currentCustomer().name != \'\'';
        //        $pane_properties['formName'] = 'editCurrentCustomerForm';
        //        $pane_properties['title'] = '$root.currentCustomer().name';
        //        $pane_properties['resetFunction'] = '$root.resetCurrentCustomer';
        //        $pane_properties['submitFunction'] = '$root.submitEditCustomer';
        //        $values = [
        //            ['title' => 'name', 'name' => 'name', 'value' => '$root.currentCustomer().name', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
        //            ['title' => 'phoneNumber', 'name' => 'phoneNumber', 'value' => '$root.currentCustomer().phoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'secondaryPhoneNumber', 'name' => 'secondaryPhoneNumber', 'value' => '$root.currentCustomer().secondaryPhoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'emailAddress', 'name' => 'emailAddress', 'value' => '$root.currentCustomer().emailAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'deliveryAddress', 'name' => 'deliveryAddress', 'value' => '$root.currentCustomer().deliveryAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'DELETE', 'name' => 'delete','buttonClass'=>'btn btn-danger w-50', 'type' => 'button','enable'=>'true','buttonClick'=>'$root.deleteCurrentCustomer', 'enableHandle' => '$root.currentCustomer().enableDelete', 'required' => 'false']
        //
        //        ];
        //        $pane_properties['values'] = $values;
        //        include(APPROOT . '/views/partials/_small_object_details_pane.php');;
        //        ?>

        <div class="col-md-8 col-lg-8 col-sm-12">
            <div id="customers_table_container" class="col-12">
                <?php
                $table_columns = ['Full Name', 'Phone Number', "Company"];
                $table_properties = ["tableId" => "datatable_customers", "title" => 'Customers', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

<!--
firstName
middleName
lastName
title
deliveryAddress
customerGroup
customerCompany
-->

<?php
$pane_properties = [];
$pane_properties['formName'] = 'addCustomerForm';
$pane_properties['title'] = 'Customer';
$pane_properties['modalTitle'] = 'Add Customer';
$pane_properties['itemName'] = 'Customer';
$values = [
    ['title' => 'First Name',
        'name' => 'firstName',
        'value' => '$root.newCustomer().firstName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Middle Name',
        'name' => 'middleName',
        'value' => '$root.newCustomer().middleName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Last Name',
        'name' => 'lastName',
        'value' => '$root.newCustomer().lastName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.newCustomer().customerTitle',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.customerTitles',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Title',
        'required' => 'true'],

    ['title' => 'Delivery Address',
        'name' => 'deliveryAddress',
        'value' => '$root.newCustomer().deliveryAddress',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Group',
        'name' => 'customerGroup',
        'value' => '$root.newCustomer().customerGroup',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.customerGroups',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Group',
        'required' => 'false'],

    ['title' => 'Company',
        'name' => 'customerCompany',
        'value' => '$root.newCustomer().customerCompany',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.customerCompanies',
        'caption' => 'Choose Company',
        'optionsValue' => 'id',
        'optionsText' => 'name',
        'required' => 'false'],


];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');
?>






<?php
$pane_properties = [];
$pane_properties['formName'] = 'editCurrentCustomerForm';
$pane_properties['title'] = '$root.currentCustomer().firstName()';
$pane_properties['modalTitle'] = '$root.currentCustomer().displayName()';
$pane_properties['itemName'] = 'Customer';
$pane_properties['modalSizeClass'] = 'modal-xl';
$pane_properties['emptyValueCheck'] = '$root.currentCustomer().firstName != \'\'';
$pane_properties['formName'] = 'editCurrentCustomerForm';
$pane_properties['resetFunction'] = '$root.resetCurrentCustomer';
$pane_properties['submitFunction'] = '$root.submitEditCustomer';
//can set $pane_properties['modalId'] or else it will be edit_modalitem_modal
$values = [

    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.currentCustomer().customerTitle',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.customerTitles',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Title',
        'required' => 'true'],
    ['title' => 'First Name',
        'name' => 'firstName',
        'value' => '$root.currentCustomer().firstName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'
    ],
    ['title' => 'Middle Name',
        'name' => 'middleName',
        'value' => '$root.currentCustomer().middleName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Last Name',
        'name' => 'lastName',
        'value' => '$root.currentCustomer().lastName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],


    ['title' => 'Delivery Address',
        'name' => 'deliveryAddress',
        'value' => '$root.currentCustomer().deliveryAddress',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Group',
        'name' => 'customerGroup',
        'value' => '$root.currentCustomer().customerGroup',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.customerGroups',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Group',
        'required' => 'false'],

    ['title' => 'Company',
        'name' => 'customerCompany',
        'value' => '$root.currentCustomer().customerCompany',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.customerCompanies',
        'caption' => 'Choose Company',
        'optionsValue' => 'id',
        'optionsText' => 'name',
        'required' => 'false'],
    ['title' => 'Phone Numbers',
        'name' => 'phoneNumbers',
        'buttonClass' => 'btn btn-bdesign-primary w-80 product-type-field-values-button',
        'type' => 'button',
        'noNewRow' => 'true',
        'colSize' => 'col-6',
        'enable' => 'false',
        'buttonClick' => '$root.showCustomerPhoneNumbersModal',
//        'attributes' => 'data-bs-target="#customerPhoneNumbersModal" data-bs-toggle="modal" data-bs-dismiss="modal"',
//        'enableHandle' => '$root.currentField().isBound()',
        'required' => 'false'],
    ['title' => 'Email Addresses',
        'name' => 'emailAddresses',
        'buttonClass' => 'btn btn-bdesign-primary w-80 product-type-field-values-button',
        'oldRow' => 'true',
        'colSize' => 'col-6',
        'type' => 'button',
        'enable' => 'false',
        'buttonClick' => '$root.showCustomerEmailAddressesModal',
//        'attributes' => 'data-bs-target="#customerPhoneNumbersModal" data-bs-toggle="modal" data-bs-dismiss="modal"',
//        'enableHandle' => '$root.currentField().isBound()',
        'required' => 'false'],
    ['title' => 'DELETE',
        'name' => 'delete',
        'buttonClass' => 'btn btn-danger w-25',
        'type' => 'button',
        'enable' => 'true',
        'buttonClick' => '$root.deleteCurrentCustomer',
        'enableHandle' => '$root.currentCustomer().enableDelete',
        'required' => 'false']

];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_object_details_modal.php');
?>

<!--Phone Numbers Modal-->
<div id="customerPhoneNumbersModal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="customerPhoneNumbersLabel">Phone Numbers</h5>
                <button type="button" class="close" data-bind="click:$root.hideCustomerPhoneNumbersModal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <!--ko if : $root.currentCustomer().firstName != ''-->
                    <div class="row justify-content-around">
                        <div class="col-12">
                            <form id="customerPhoneNumbersForm">
                                <table class="table-hover">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th></th>
                                        <th>Country Code</th>
                                        <th></th>
                                        <th>Area Code</th>
                                        <th></th>
                                        <th>Subscriber Number</th>
                                        <th></th>
                                        <th>Extension</th>
                                    </tr>
                                    </thead>
                                    <tbody style="user-select: none;" data-bind="foreach : {data : $root.currentCustomer().phoneNumbers, includeDestroyed: false }">
                                    <tr>
                                        <td>
                                            <!--                                        <input type="text" class="form-control" data-bind="textInput:$data.countryCode">-->
                                            <select class="form-control-sm" data-bind="options:$root.customerPhoneNumberTypes,value:$data.phoneNumberTypeId,optionsValue:'id',optionsText:'type'"></select>
                                        </td>
                                        <td>
                                            <button class="btn-info btn-sm" data-bind="click:$root.addCustomerPhoneNumberType"><span class="fa fa-plus"></span></button>

                                        </td>
                                        <td>
                                            <select class="form-control-sm" data-bind="options:$root.phoneNumberCountryCodes,value:$data.countryCode,optionsValue:'id',optionsText:'displayName'"></select>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input style="min-width: 3rem;" type="text" class="form-control" data-bind="textInput:$data.areaCode" required>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input class="form-control" data-bind="textInput:$data.subscriberNumber" required>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input class="form-control" data-bind="textInput:$data.extension">
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bind="click:$root.currentCustomer().removePhoneNumber">
                                                X
                                            </button>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>
                                            <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentCustomer().addPhoneNumber">
                                                Add Number
                                            </button>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentCustomer().saveCustomerPhoneNumbers">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>

<!--Email Addresses Modal-->
<div id="customerEmailAddressesModal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="customerEmailAddressesLabel">Email Addresses</h5>
                <button type="button" class="close" data-bind="click:$root.hideCustomerEmailAddressesModal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <!--ko if : $root.currentCustomer().firstName != ''-->
                    <div class="row justify-content-around">
                        <div class="col-12">
                            <form id="customerEmailAddressesForm">
                                <table class="table-hover">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th> </th>
                                        <th>addresses</th>
                                    </tr>
                                    </thead>
                                    <tbody style="user-select: none;" data-bind="foreach : {data : $root.currentCustomer().emailAddresses, includeDestroyed: false }">
                                    <tr>
                                        <td>
                                            <select class="form-control-sm" data-bind="options:$root.customerEmailAddressTypes,value:$data.emailAddressTypeId,optionsValue:'id',optionsText:'type'"></select>
                                            <button class="btn-info btn-sm" data-bind="click:$root.addCustomerEmailAddressType"><span class="fa fa-plus"></span></button>
                                        </td>
                                        <td style="width: 10%;">

                                        </td>
                                        <td>
                                            <input class="form-control" type="email" data-bind="textInput:$data.emailAddress" required>
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bind="click:$root.currentCustomer().removeEmailAddress">
                                                X
                                            </button>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>
                                            <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentCustomer().addEmailAddress">
                                                Add Address
                                            </button>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentCustomer().saveCustomerEmailAddresses">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>