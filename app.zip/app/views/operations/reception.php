<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 29/04/20
 * Time: 2:40 PM
 */
?>
<div class="container-xl" style="margin: 5rem auto">
    <div class="card">
        <div class="card-body">
            <form id="newOrderForm">
                <div class="row justify-content-around">
                    <div class="col-8">
                        <div class="row justify-content-around">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-10">
                                        <label for="newOrderCustomer">Customer :</label>
                                        <select name="newOrderCustomer" id="newOrderCustomer" class="form-control" data-bind="options:$root.customers,value:$root.order.customer,optionsText:'name',optionsCaption:'Choose Customer'" required></select>
                                    </div>
                                    <div class="col-2" style="margin-top: 2rem">
                                        <a id="addCustomer" target="_blank" class="btn btn-info"> + </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-around">
                    <div class="col-8">
                        <label for="placeDateInput"> Placement Date :</label>
                        <input class="form-control" type="date" id="placeDateInput" data-bind="value:$root.order.datePlaced">
                    </div>
                </div>
                <div class="row justify-content-around">
                    <div class="col-8">
                        <label for="dueDateInput"> Due Date :</label>
                        <input class="form-control" type="date" id="dueDateInput" data-bind="value:$root.order.dateDue">
                    </div>
                </div>

            </form>
            <hr>
            <div class="row col-2">
                <button type="button" data-bs-toggle="modal" data-bs-target="#addItemModal" class="btn btn-info mb-2">Add Item</button>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-middle">
                            <thead>
                            <tr role="row">
                                <th>Title</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Batch Price</th>
                                <th>Details</th>
                                <th>Remove</th>
                            </tr>
                            </thead>
                            <tbody data-bind="foreach : { data: $root.items, includeDestroyed: false }">
                            <tr>
                                <td data-bind="text : $data.title()"></td>
                                <td><input type="number" data-bind="textInput : $data.quantity"></td>
                                <td data-bind="text : $data.Uprice()"></td>
                                <td data-bind="text : $data.Bprice()"></td>
                                <td><button class="btn btn-bdesign-primary" data-bind="click : function(){$root.setSaleItem($data);}"><span class="fa fa-share-square"></span></button></td>
                                <td><button class="btn btn-danger" data-bind="click : function(){$root.items.destroy($data);}"><span>&times;</span></button></td>
                            </tr>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <th data-bind="text :'Total : '+ $root.totalPrice()"></th>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <th><label for="discountInput">Discount: </label><input data-bind="textInput: $root.order.discount" class="form-control-sm" id="discountInput" type="number"></th>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <th data-bind="text :'Net Total : '+ $root.netPrice()"></th>
                                <td></td>
                                <td></td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <hr style="margin-bottom: 10rem;">
            <div style="position: absolute;bottom: 2rem;width: 100%;">
                <div class="row justify-content-around">
                    <div style="position: absolute;bottom: 0.5rem;left: 3rem;">
                        <button type="button" class="btn btn-secondary btn-lg" id="clearNewOrderButton" data-bind="click:$root.clearNewOrder">Reset</button>
                    </div>
                    <div style="position: absolute;bottom: 0.5rem;right:5rem;">
                        <button type="button" class="btn btn-success btn-lg" id="submitNewOrder" data-bind="click:$root.submitNewOrder">Submit</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
$pane_properties = [];
$pane_properties['formName'] = 'addCustomerForm';
$pane_properties['title'] = 'Customer';
$pane_properties['modalTitle'] = 'Add Customer';
$pane_properties['itemName'] = 'Customer';
$values = [
    ['title' => 'name', 'name' => 'name', 'value' => '$root.newCustomerName', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
    ['title' => 'phone Number', 'name' => 'phoneNumber', 'value' => '$root.newCustomerPhoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
    ['title' => 'secondary Phone Number', 'name' => 'secondaryPhoneNumber', 'value' => '$root.newCustomerSecondaryPhoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
    ['title' => 'email Address', 'name' => 'emailAddress', 'value' => '$root.newCustomerEmailAddress', 'type' => 'email', 'enable' => 'false', 'required' => 'false'],
    ['title' => 'delivery Address', 'name' => 'deliveryAddress', 'value' => '$root.newCustomerDeliveryAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');;
?>


<!-- Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addItemModalLabel">Add Item</h5>
                <button type="button" class="close" data-dismiss="modal" data-bind="click:function(){$('#addItemModal').modal('hide')}">
                    <span>×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row justify-content-around">

                    <div class="col-12">
                        <div id="products_table_container" class="col-12">
                            <?php
                            $table_columns = ['Product ', 'Code', 'Description'];
                            $table_properties = ["tableId" => "datatable_products", "title" => 'Products', 'title-size' => 'h3'];
                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                            ?>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-12">
                        <div class="card col-12 shadow">
                            <div class="card-body">
                                <form id="newItemForm">
                                    <h2> Fields : </h2>
                                    <div id="fieldsContainer" class="row justify-content-around" style="margin-bottom: 2rem" data-bind="foreach:$root.currentItemProduct().fields">
                                        <div class="col-12">

                                            <div class="row justify-content-around">
                                                <!-- ko if : $data.fieldDataTypeId == fieldDataTypeIds['text'] || $data.fieldDataTypeId == fieldDataTypeIds['number'] -->
                                                <!-- ko if : $data.fieldTypeId == fieldTypeIds['free'] -->
                                                <div class="col-8 mb-4">
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <input data-bind="textInput:$data.valueValue,attr:{'id':('productField' + $data.id),'type':$data.fieldDataType,'placeholder':title}" class="form-control" required>
                                                </div>
                                                <!-- /ko -->
                                                <!-- ko if : $data.fieldTypeId == fieldTypeIds['bound'] -->
                                                <div class="col-8 mb-4">
                                                    <!--                                <pre data-bind="text:ko.toJSON($data,null,2)"></pre>-->
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <!--                                <input data-bind="attr:{'id':($index() + 'myamazingid'),'type':$data.fieldDataType}" class="form-control">-->
                                                    <select class="form-control" data-bind="options:$data.boundFieldValues,value:$data.valueId,optionsValue:'id',optionsText:'value',optionsCaption:'Choose Value',attr:{'id':('productField' + $data.id),'name':('productField' + $data.id)}" required></select>
                                                </div>
                                                <!-- /ko -->
                                                <!-- /ko -->
                                                <!-- ko if : $data.fieldDataTypeId == fieldDataTypeIds['date'] -->
                                                <div class="col-8 mb-4">
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <input data-bind="value:$data.valueValue,attr:{'id':('productField' + $data.id),'type':$data.fieldDataType}" class="form-control" required>
                                                </div>
                                                <!-- /ko -->
                                                <!-- ko if : $data.fieldDataTypeId == fieldDataTypeIds['file'] -->
                                                <div class="col-8 mb-4">
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <input data-bind="attr:{'id':('productField' + $data.id),'type':$data.fieldDataType}" class="form-control-file" required>
                                                </div>
                                                <!-- /ko -->
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-bind="click:$root.addItem">Add Item</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="editItemModal" tabindex="-1" aria-labelledby="editItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editItemModalLabel">Edit Item</h5>
                <button type="button" class="close" data-dismiss="modal" data-bind="click:function(){$('#editItemModal').modal('hide')}">
                    <span>×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mt-5">
                    <div class="col-12">
                        <div class="card col-12 shadow">
                            <div class="card-body">
                                <form id="editItemForm">
                                    <h2> Fields : </h2>
                                    <div id="editItemfieldsContainer" class="row justify-content-around" style="margin-bottom: 2rem" data-bind="foreach:$root.currentOrderItem().fields">
                                        <div class="col-12">

                                            <div class="row justify-content-around">
                                                <!-- ko if : $data.fieldDataTypeId == fieldDataTypeIds['text'] || $data.fieldDataTypeId == fieldDataTypeIds['number'] -->
                                                <!-- ko if : $data.fieldTypeId == fieldTypeIds['free'] -->
                                                <div class="col-8 mb-4">
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <input data-bind="textInput:$data.valueValue,attr:{'id':('productField' + $data.id),'type':$data.fieldDataType,'placeholder':title}" class="form-control" required>
                                                </div>
                                                <!-- /ko -->
                                                <!-- ko if : $data.fieldTypeId == fieldTypeIds['bound'] -->
                                                <div class="col-8 mb-4">
                                                    <!--                                <pre data-bind="text:ko.toJSON($data,null,2)"></pre>-->
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <!--                                <input data-bind="attr:{'id':($index() + 'myamazingid'),'type':$data.fieldDataType}" class="form-control">-->
                                                    <select class="form-control" data-bind="options:$data.boundFieldValues,value:$data.valueId,optionsValue:'id',optionsText:'value',optionsCaption:'Choose Value',attr:{'id':('productField' + $data.id),'name':('productField' + $data.id)}" required></select>
                                                </div>
                                                <!-- /ko -->
                                                <!-- /ko -->
                                                <!-- ko if : $data.fieldDataTypeId == fieldDataTypeIds['date'] -->
                                                <div class="col-8 mb-4">
                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <input data-bind="value:$data.valueValue,attr:{'id':('productField' + $data.id),'type':$data.fieldDataType}" class="form-control" required>
                                                </div>
                                                <!-- /ko -->
                                                <!-- ko if : $data.fieldDataTypeId == fieldDataTypeIds['file'] -->
                                                <div class="col-8 mb-4" style="border-width: 1px;border-color: lightgrey;border-style: solid;padding: 1rem">

                                                    <label> Current File Name</label>
                                                    <input type="text" data-bind="value:$data.file().name" class="form-control" disabled>

                                                    <label data-bind="attr:{'for':('productField' + $data.id)},text:(title +' :')"></label>
                                                    <input data-bind="event: { change: function() { $data.changeFile($element.files[0]) } },attr:{'id':('productField' + $data.id),'type':$data.fieldDataType}" class="form-control-file">
                                                </div>
                                                <!-- /ko -->
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

