<nav class="navbar navbar-expand-lg navbar-bdesign bg-darkblue mb-3 fixed-top">
    <a class="navbar-brand" href="<?php echo URLROOT; ?>"><?php echo SITENAME; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav ml-auto">
            <?php if (isset($_SESSION['user_id'])) : ?>
<!--            <li class="nav-item">-->
<!--                <a class="nav-link" href="--><?php //echo URLROOT; ?><!--/pages/about">About</a>-->
<!--            </li>-->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/customers/customers">Customers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/agents/agents">Agents</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/suppliers/suppliers">Suppliers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/products/products">Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/products/categories">Categories</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/sales/reception">Reception</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/sales/orders">Orders</a>
            </li>
<!--            <li class="nav-item">-->
<!--                <a class="nav-link" href="--><?php //echo URLROOT; ?><!--/operations/workshop">Workshop</a>-->
<!--            </li>-->
<!--            <li class="nav-item">-->
<!--                <a class="nav-link" href="--><?php //echo URLROOT; ?><!--/admin/products">Products</a>-->
<!--            </li>-->
        </ul>
        <?php endif; ?>
        <ul class="navbar-nav mr-auto">
            <?php if (isset($_SESSION['user_id'])) : ?>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbar_config_dropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Config
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li><a class="dropdown-item" href="<?php echo URLROOT; ?>/admin/products">Product Types</a>
                        </li>
                        <li><a class="dropdown-item" href="<?php echo URLROOT; ?>/admin/customers">Customers</a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="<?php echo URLROOT; ?>/admin/users">Users</a></li>
                        <!--                        <li><a class="dropdown-item" href="#">Another action</a></li>-->
<!--                        <li><a class="dropdown-item" href="#">Something else here</a></li>-->
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URLROOT; ?>/users/logout">Logout</a>
                </li>
            <?php else : ?>
                <!--                <li class="nav-item">-->
                <!--                    <a class="nav-link" href="--><?php //echo URLROOT; ?><!--/users/register">Register</a>-->
                <!--                </li>-->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URLROOT; ?>/users/login">Login</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>