<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 01/02/21
 * Time: 10:15 AM
 */

if (!isset($pane_properties)) {
    die('invalid small pane parameters');
}
if (!isset($pane_properties['colsize'])) {
    $pane_properties['colsize'] = 'col-3';
}
if (!isset($pane_properties['margin-top'])) {
    $pane_properties['margin-top'] = 'mt-5';
}
if (!isset($pane_properties['margin-left'])) {
    $pane_properties['margin-left'] = 'ml-5';
}
if (!isset($pane_properties['emptyValueCheck'])) {
    die('need to supply empty value check for knockout');
}
if (!isset($pane_properties['formName'])) {
    die('need to supply form name');
}
if (!isset($pane_properties['title'])) {
    die('need to supply title');
}
$emptyValueCheck = '<!-- ko if: ' . $pane_properties['emptyValueCheck'] . '-->';
$emptyValueCheckFinish = '<!-- /ko -->';
$values = $pane_properties['values'];
?>
<?php echo $emptyValueCheck ?>
    <div class="<?php echo($pane_properties['colsize'] . ' ' . $pane_properties['margin-top'] . ' ' . $pane_properties['margin-left']) ?> ">
        <div class="card shadow" style="height: 100%;">
            <div class="card-body">
                <h3 style="height: 3rem;" class="" data-bind="text :<?php echo $pane_properties['title'] ?>.charAt(0).toUpperCase() + <?php echo $pane_properties['title'] ?>.slice(1)"></h3>
                <?php echo $emptyValueCheck ?>
                <div style="height: 90%;border-style: solid;padding: 1rem;border-color: lightgrey;border-width: 0.05rem;margin-bottom: 4rem">
                    <form id="<?php echo $pane_properties['formName'] ?>">
                        <?php

                        foreach ($values as $value) {
                            if (isset($value['noNewRow'])) {
                                $noNewRow = true;
                            }
                            else {
                                $noNewRow = false;
                            }
                            if (isset($value['oldRow'])) {
                                $oldRow = true;
                            }
                            else {
                                $oldRow = false;
                            }
                            if (isset($value['colSize'])) {
                                $colSize = $value['colSize'];
                            }
                            else {
                                $colSize = 'col-12';
                            }
                            $randomNum = random_int(1, 10000);
                            $randomId = $value['title'] . $randomNum;
                            $name = $value['name'];
                            if (isset($value['placeholder'])) {
                                $placeholder = $value['placeholder'];
                            }
                            else {
                                $placeholder = ucfirst($value['title']);
                            }

                            $required = $value['required'] == 'false' ? '' : 'required';
                            $label = '<label for="' . $randomId . '" style="font-size: 1rem;font-weight: bold;">' . ucfirst($value['title']) . ' :</label>';
                            if (isset($value['enable'])) {
                                if ($value['enable'] == 'true') {
                                    $randomIdEnable = $randomId . 'check';
                                    $enableHandle = $value['enableHandle'];
                                    $labelEnable = '<label for="' . $randomIdEnable . '" style="font-size: 1rem;font-weight: bold">Enable :</label>';
                                    $checkBoxEnable = '<input id="' . $randomIdEnable . '" type="checkbox" data-bind="checked: ' . $enableHandle . '">';
                                    $enableString = "<div>\n" . $labelEnable . "\n" . $checkBoxEnable . "\n</div>";
                                    $enableDataBindString = ',enable: ' . $enableHandle;
                                }
                                else {
                                    if (isset($value['enableHandle'])) {
                                        $enableDataBindString = ',enable: ' . $value['enableHandle'];
                                    }
                                    else {
                                        $enableDataBindString = '';
                                    }
                                    $enableString = '';
                                }
                            }
                            else {
                                $enableDataBindString = '';
                                $enableString = '';
                            }
                            if ($value['type'] != 'select' && $value['type'] != 'button') {
                                $type = $value['type'];
                                $textInput = $value['value'];
                                $input = '<input  id="' . $randomId . '" type="' . $type . '" name="' . $name . '"  data-bind="textInput : ' . $textInput . ' ' . $enableDataBindString . '" placeholder="' . $placeholder . '"  class="form-control mb-4 " ' . $required . ' />';
                            }
                            elseif ($value['type'] == 'button') {
                                if (isset($value['buttonClass'])) {
                                    $buttonClass = $value['buttonClass'];
                                }
                                else {
                                    $buttonClass = 'btn btn-primary';
                                }
                                if (isset($value['buttonClick'])) {
                                    $buttonClick = $value['buttonClick'];
                                }
                                else {
                                    $buttonClick = '';
                                }
                                $input = '<button type="button" class="' . $buttonClass . '" id="' . $randomId . '" data-bind="click:' . $buttonClick . ' ' . $enableDataBindString . '">' . ucfirst($value['title']) . '</button>';

                            }
                            else {
                                $options = $value['options'];
                                //this is the value of the javascript object to hold the chosen value
                                $valueOptions = $value['value'];
                                $caption = $value['caption'];

                                if (isset($value['optionsValue'])) {
                                    $optionsValue = $value['optionsValue'];
                                    $optionsValueString = ',optionsValue : \'' . $optionsValue . '\'';
                                    if (isset($value['optionsText'])) {
                                        $optionsText = $value['optionsText'];
                                        $optionsValueString .= ',optionsText:\'' . $optionsText . '\'';
                                    }
                                }
                                else {
                                    $optionsValueString = '';
                                }
                                $input = '<select class="form-control mb-4" name="' . $name . '" id="' . $randomId . '" data-bind="options : ' . $options . ',value:' . $valueOptions . $optionsValueString . ',optionsCaption:\'' . $caption . '\' ' . $enableDataBindString . '"></select>';
                            }
                            if (!$oldRow) {
                                echo $emptyValueCheck;
                                echo '<div class="row">';
                            }
                            echo '<div class="' . $colSize . '">';
                            echo $label;
                            echo $enableString;
                            echo $input;
                            echo '</div>';
                            if (!$noNewRow) {
                                echo '</div>';
                                echo $emptyValueCheckFinish;
                            }
                        }
                        $resetValuesFunction = $pane_properties['resetFunction'];
                        $submitValuesFunction = $pane_properties['submitFunction'];
                        ?>
                        <div style="position: absolute;bottom: 3rem;width: 100%;">
                            <div class="row justify-content-around">
                                <div style="position: absolute;bottom: 0.5rem;left: 0.8rem;">
                                    <button type="button" class="btn btn-secondary" id="clear<?php echo ucfirst($pane_properties['title']); ?>" data-bind="click:<?php echo $resetValuesFunction ?>">Reset</button>
                                </div>
                                <div style="position: absolute;bottom: 0.5rem;right:5rem;">
                                    <button type="button" class="btn btn-success" id="submit<?php echo ucfirst($pane_properties['title']); ?>" data-bind="click:<?php echo $submitValuesFunction ?>">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /ko -->
            </div>
        </div>
    </div>
<?php echo $emptyValueCheckFinish; ?>