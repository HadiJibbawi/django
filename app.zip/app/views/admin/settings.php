<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 26/05/20
 * Time: 3:23 PM
 */
?>
<!--<h2 style="margin-top: 4rem;margin-bottom: 2rem">--><?php //echo $data['title'] ?><!--</h2>-->

<div class="row">
    <div class="col-2 ml-2 mt-3 card shadow">
        <div class="card-body" style="min-height: 50rem;">
            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a style="color: #000000;" class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true"><span class="fa fa-minus"> </span> Products</a>
                <a style="color: #000000;" class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false"><span class="fa fa-minus"> </span> Profile</a>
                <a style="color: #000000;" class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false"><span class="fa fa-minus"> </span> Messages</a>
                <a style="color: #000000;" class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false"><span class="fa fa-minus"> </span> Settings</a>
            </div>
        </div>
    </div>

    <div class="col-9 ml-2 mt-3 card shadow">
        <div class="card-body">
            <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                    <ul class="nav nav-tabs bg-white">
                        <li class="nav-item">
                            <a class="nav-link active" id="v-pills-generic-item-options-tab" data-toggle="pill" href="#v-pills-generic-item-options" role="tab" aria-controls="v-pills-generic-item-options" aria-selected="false"><span class="fa fa-image text-dark"></span> Items & Options</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link "><span class="fa fa-info-circle text-dark"></span> Product Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"><span class="fa fa-box-open text-dark"></span> Items & Options</a>
                        </li>
                    </ul>
                    <div class="tab-pane" id="v-pills-generic-item-options" role="tabpanel" aria-labelledby="v-pills-generic-item-options-tab">
                        <div class="row">
                            <div class="col-3 mt-5 card shadow">
                                <div class="card-body">
                                    <table width="100%" class="">
                                        <tr>
                                            <th>
                                                <h3 style="height: 3rem;" id="current_option_name" class="m-3" data-bind="text :$root.currentOption().name().charAt(0).toUpperCase() + $root.currentOption().name().slice(1)"></h3>
                                            </th>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left">
                                                <!--ko if : $root.currentOption().name() != '' -->
                                                <label for="product_option_name">Option Name:</label>
                                                <input id="product_option_name" name="name" data-bind="textInput :  $root.currentOption().name,attr : {'placeholder' : 'Option Name'}" class="form-control" type="text"/>
                                                <!-- /ko -->
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left">
                                                <!--ko if : $root.currentOption().name() != '' -->
                                                <label class="mt-4" for="product_option_description">Description:</label>
                                                <input id="product_option_description" name="description" data-bind="textInput :  $root.currentOption().description,attr : {'placeholder' : 'Description'}" class="form-control" type="text"/>
                                                <!-- /ko -->
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left">
                                                <!--ko if : $root.currentOption().name() != '' -->
                                                <label class="mt-4" for="product_option_type">Type</label>
                                                <select id="product_option_type" name="optionType" class="form-control" data-bind="options : $root.optionTypes(),value:$root.currentOption().typeId,optionsValue : 'id',optionsText:'type',optionsCaption:'Choose Type'" required></select>
                                                <!-- /ko -->
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div class="row">
                                                    <!--ko if : $root.currentOption().name() != '' -->
                                                    <div class="col-6">
                                                        <button data-bind="click:$root.deleteOption" class="btn btn-danger mt-3">Delete</button>
                                                    </div>
                                                    <div class="col-6">
                                                        <button data-bind="click:$root.submitEdit" class="btn btn-violet-primary mt-3">Save</button>
                                                    </div>
                                                    <!-- /ko -->
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-8 ml-3">
                                <?php
                                $table_columns = ['Option', 'Description', 'Type'];
                                $table_properties = ["tableId" => "datatable_settings_options", "title" => 'Generic Options'];
                                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                                ?>
                            </div>
                        </div>
                        <div class="row justify-content-around mb-5">
                            <div id="option_values_table_container" class="col-11">
                            <?php
                            $table_columns = ['value','Delete'];
                            $table_properties = ["tableId" => "datatable_option_values", "title" => 'Option Values', 'title-size' => 'h3'];
                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">profile</div>
            <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">messages</div>
            <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">settings</div>
        </div>
    </div>
</div>
</div>

<!--Add Option Modal-->
<div id="new_option_modal" class="modal show">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="new_option_modal_label">New Option</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addOptionForm">
                    <div class="form-group">
                        <label for="new_option_name">Name</label>
                        <input id="new_option_name" name="name" data-bind="textInput :  $root.newOptionName,attr : {'placeholder' : 'Option Name'}" class="form-control" type="text" required/>
                        <br>
                        <label for="new_option_description">Description</label>
                        <input id="new_option_description" name="description" data-bind="textInput :  $root.newOptionDescription,attr : {'placeholder' : 'Description'}" class="form-control" type="text"/>
                        <br>
                        <label for="new_option_type">Type</label>
                        <br/>
                        <select class="form-control" name="type" id="new_option_type" data-bind="options : $root.optionTypes,value:$root.newOptionType,optionsValue : 'id',optionsText:'type',optionsCaption:'Choose Type'" required></select>
                        <br>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewOptionModal">Clear</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button id="save_new_option_btn" type="button" data-bind="click:$root.addOption" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>

<!--Add Option Value Modal-->
<div id="new_option_value_modal" class="modal show">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="new_option_value_modal_label">New Option Value</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addOptionValueForm">
                    <div class="form-group">
                        <label for="new_option_value_name">Name</label>
                        <input id="new_option_value_name" name="value" data-bind="textInput :  $root.newOptionValue,attr : {'placeholder' : 'Option Value'}" class="form-control" type="text" required/>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewOptionValueModal">Clear</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button id="save_new_option_value_btn" type="button" data-bind="click:$root.addOptionValue" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
