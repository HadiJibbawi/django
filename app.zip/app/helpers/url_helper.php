<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 05/04/20
 * Time: 10:25 PM
 */

//simple page redirect
function redirect($page)
{
    header('location: ' . URLROOT . '/' . $page);
}