<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:40 AM
 */

class Suppliers extends Controller
{
    private $supplierModel;

    public function __construct()
    {
        $this->supplierModel = $this->model('Supplier');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function suppliers()
    {
        $data = ['title' => 'Suppliers', 'description' => 'Page for Supplier Management'];
        $template = [];
        $template['page_script'] = 'suppliers';
        $this->view('admin/suppliers', $data, $template);
    }

    private function addSupplier($supplier)
    {

        return $this->supplierModel->addSupplier($supplier);
    }

    private function addPhoneNumberType($phoneNumberType)
    {

        return $this->supplierModel->addPhoneNumberType($phoneNumberType['data']);
    }
    private function addEmailAddressType($emailAddressType)
    {

        return $this->supplierModel->addEmailAddressType($emailAddressType['data']);

    }

    private function updateSupplier($supplier)
    {
        foreach ($supplier as $key => $item) {
            $newKey = $this->camelCaseToUnderscore($key);
            if ($newKey == $key) {
                continue;
            }
            $supplier[$newKey] = $item;
            unset($supplier[$key]);
        }
        if (isset($supplier['supplier_company'])) {
            $supplier['company'] = $supplier['supplier_company'];
            unset($supplier['supplier_company']);
        }
        if (isset($supplier['supplier_title'])) {
            $supplier['title'] = $supplier['supplier_title'];
            unset($supplier['supplier_title']);
        }
        if (isset($supplier['supplier_job'])) {
            $supplier['job'] = $supplier['supplier_job'];
            unset($supplier['supplier_job']);
        }
        echo $this->supplierModel->updateSupplier($supplier);
    }

    private function submitSupplierPhoneNumbers($phoneNumbers)
    {
        $supplierId = $phoneNumbers['supplierId'];
        $phoneNumbers = $phoneNumbers['data'];
        foreach ($phoneNumbers as $phoneNumber) {
            foreach ($phoneNumber as $key => $item) {
                $newKey = $this->camelCaseToUnderscore($key);
                if ($newKey == $key) {
                    continue;
                }
                $phoneNumber[$newKey] = $item;
                unset($phoneNumber[$key]);
            }
            if ($phoneNumber['id'] == 0) {
                if (isset($phoneNumber['_destroy'])) {
                    continue;
                }
                $phoneNumber['type'] = $phoneNumber['phone_number_type_id'];
                unset($phoneNumber['phone_number_type_id']);
                unset($phoneNumber['id']);
                $this->supplierModel->addSupplierPhoneNumber($supplierId, $phoneNumber);
            }
            else {
                if (isset($phoneNumber['_destroy'])) {
                    $this->supplierModel->deleteSupplierPhoneNumber($phoneNumber['id']);
                }
                else {
                    if (isset($phoneNumber['phone_number_type_id'])) {
                        $phoneNumber['type'] = $phoneNumber['phone_number_type_id'];
                        unset($phoneNumber['phone_number_type_id']);
                    }
                    $this->supplierModel->updatePhoneNumber($phoneNumber);
                }
            }
        }

        echo 1;
    }

    private function submitSupplierEmailAddresses($emailAddresses)
    {
        $supplierId = $emailAddresses['supplierId'];
        $emailAddresses = $emailAddresses['data'];
        foreach ($emailAddresses as $emailAddress) {
            foreach ($emailAddress as $key => $item) {
                $newKey = $this->camelCaseToUnderscore($key);
                if ($newKey == $key) {
                    continue;
                }
                $emailAddress[$newKey] = $item;
                unset($emailAddress[$key]);
            }
            if ($emailAddress['id'] == 0) {
                if (isset($emailAddress['_destroy'])) {
                    continue;
                }
                $emailAddress['type'] = $emailAddress['email_address_type_id'];
                unset($emailAddress['email_address_type_id']);
                $emailAddress['address'] = $emailAddress['email_address'];
                unset($emailAddress['email_address']);
                unset($emailAddress['id']);
                $this->supplierModel->addSupplierEmailAddress($supplierId, $emailAddress);
            }
            else {
                if (isset($phoneNumber['_destroy'])) {
                    $this->supplierModel->deleteSupplierEmailAddress($emailAddress['id']);
                }
                else {
                    if (isset($emailAddress['email_address_type_id'])) {
                        $emailAddress['type'] = $emailAddress['email_address_type_id'];
                        unset($emailAddress['email_address_type_id']);
                    }
                    if (isset($emailAddress['email_address'])) {
                        $emailAddress['address'] = $emailAddress['email_address'];
                        unset($emailAddress['email_address']);
                    }
                    $this->supplierModel->updateEmailAddress($emailAddress);
                }
            }
        }

        echo 1;
    }

    private function deleteSupplier($id)
    {
        return $this->supplierModel->deleteSupplier($id['id']);
    }

    public function requests($request)
    {
        switch ($request) {
            case 'getAllSuppliers':
                if (isset(func_get_args()[1])) {

                    if (func_get_args()[1] == 'datatablesEncode') {
                        echo $this->datatables_encode($this->supplierModel->getAllSuppliers());
                    }
                    else {
                        echo $this->encode_json($this->supplierModel->getAllSuppliers());
                    }
                }
                else {
                    echo $this->encode_json($this->supplierModel->getAllSuppliers());
                }
                break;
            case 'getSupplierPhoneNumberTypes':
                echo self::encode_json($this->supplierModel->getSupplierPhoneNumberTypes());
                break;
            case 'getSupplierJobs':
                echo self::encode_json($this->supplierModel->getSupplierJobs());
                break;
            case 'getAllPhoneNumberCountryCodes':
                echo self::encode_json($this->supplierModel->getAllPhoneNumberCountryCodes());
                break;
            case 'getSupplierEmailAddressTypes':
                echo self::encode_json($this->supplierModel->getSupplierEmailAddressTypes());
                break;
            case 'getSupplierPhoneNumbers':
                if (isset($_GET['supplierId'])) {
                    echo self::encode_json($this->supplierModel->getSupplierPhoneNumbers($_GET['supplierId']));
                }
                else {
                    echo 'supplierId not provided';
                }
                break;
            case 'getSupplierEmailAddresses':
                if (isset($_GET['supplierId'])) {
                    echo self::encode_json($this->supplierModel->getSupplierEmailAddresses($_GET['supplierId']));
                }
                else {
                    echo 'supplierId not provided';
                }
                break;
            case 'getSupplierTitles':
                echo self::encode_json($this->supplierModel->getSupplierTitles());
                break;
            case 'getSupplierGroups':
                echo self::encode_json($this->supplierModel->getSupplierGroups());
                break;
            case 'getSupplierCompanies':
                echo self::encode_json($this->supplierModel->getSupplierCompanies());
                break;
            case 'addSupplier':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addSupplier($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addPhoneNumberType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addPhoneNumberType($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addEmailAddressType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addEmailAddressType($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'updateSupplier':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateSupplier($_POST);
                }
                else {
                    $this->suppliers();
                }
                break;
            case 'submitSupplierPhoneNumbers':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->submitSupplierPhoneNumbers($_POST);
                }
                else {
                    $this->suppliers();
                }
                break;
            case 'submitSupplierEmailAddresses':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->submitSupplierEmailAddresses($_POST);
                }
                else {
                    $this->suppliers();
                }
                break;
            case 'deleteSupplier':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->deleteSupplier($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>