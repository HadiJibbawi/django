<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:40 AM
 */

class Customers extends Controller
{
    private $customerModel;

    public function __construct()
    {
        $this->customerModel = $this->model('Customer');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function customers()
    {
        $data = ['title' => 'Customers', 'description' => 'Page for Customer Management'];
        $template = [];
        $template['page_script'] = 'customers';
        $this->view('admin/customers', $data, $template);
    }

    private function addCustomer($customer)
    {

        return $this->customerModel->addCustomer($customer);
    }

    private function addPhoneNumberType($phoneNumberType)
    {

        return $this->customerModel->addPhoneNumberType($phoneNumberType['data']);
    }
    private function addEmailAddressType($emailAddressType)
    {

        return $this->customerModel->addEmailAddressType($emailAddressType['data']);

    }

    private function updateCustomer($customer)
    {
        foreach ($customer as $key => $item) {
            $newKey = $this->camelCaseToUnderscore($key);
            if ($newKey == $key) {
                continue;
            }
            $customer[$newKey] = $item;
            unset($customer[$key]);
        }
        if (isset($customer['customer_company'])) {
            $customer['company'] = $customer['customer_company'];
            unset($customer['customer_company']);
        }
        if (isset($customer['customer_title'])) {
            $customer['title'] = $customer['customer_title'];
            unset($customer['customer_title']);
        }
        echo $this->customerModel->updateCustomer($customer);
    }

    private function submitCustomerPhoneNumbers($phoneNumbers)
    {
        $customerId = $phoneNumbers['customerId'];
        $phoneNumbers = $phoneNumbers['data'];
        foreach ($phoneNumbers as $phoneNumber) {
            foreach ($phoneNumber as $key => $item) {
                $newKey = $this->camelCaseToUnderscore($key);
                if ($newKey == $key) {
                    continue;
                }
                $phoneNumber[$newKey] = $item;
                unset($phoneNumber[$key]);
            }
            if ($phoneNumber['id'] == 0) {
                if (isset($phoneNumber['_destroy'])) {
                    continue;
                }
                $phoneNumber['type'] = $phoneNumber['phone_number_type_id'];
                unset($phoneNumber['phone_number_type_id']);
                unset($phoneNumber['id']);
                $this->customerModel->addCustomerPhoneNumber($customerId, $phoneNumber);
            }
            else {
                if (isset($phoneNumber['_destroy'])) {
                    $this->customerModel->deleteCustomerPhoneNumber($phoneNumber['id']);
                }
                else {
                    if (isset($phoneNumber['phone_number_type_id'])) {
                        $phoneNumber['type'] = $phoneNumber['phone_number_type_id'];
                        unset($phoneNumber['phone_number_type_id']);
                    }
                    $this->customerModel->updatePhoneNumber($phoneNumber);
                }
            }
        }

        echo 1;
    }

    private function submitCustomerEmailAddresses($emailAddresses)
    {
        $customerId = $emailAddresses['customerId'];
        $emailAddresses = $emailAddresses['data'];
        foreach ($emailAddresses as $emailAddress) {
            foreach ($emailAddress as $key => $item) {
                $newKey = $this->camelCaseToUnderscore($key);
                if ($newKey == $key) {
                    continue;
                }
                $emailAddress[$newKey] = $item;
                unset($emailAddress[$key]);
            }
            if ($emailAddress['id'] == 0) {
                if (isset($emailAddress['_destroy'])) {
                    continue;
                }
                $emailAddress['type'] = $emailAddress['email_address_type_id'];
                unset($emailAddress['email_address_type_id']);
                $emailAddress['address'] = $emailAddress['email_address'];
                unset($emailAddress['email_address']);
                unset($emailAddress['id']);
                $this->customerModel->addCustomerEmailAddress($customerId, $emailAddress);
            }
            else {
                if (isset($phoneNumber['_destroy'])) {
                    $this->customerModel->deleteCustomerEmailAddress($emailAddress['id']);
                }
                else {
                    if (isset($emailAddress['email_address_type_id'])) {
                        $emailAddress['type'] = $emailAddress['email_address_type_id'];
                        unset($emailAddress['email_address_type_id']);
                    }
                    if (isset($emailAddress['email_address'])) {
                        $emailAddress['address'] = $emailAddress['email_address'];
                        unset($emailAddress['email_address']);
                    }
                    $this->customerModel->updateEmailAddress($emailAddress);
                }
            }
        }

        echo 1;
    }

    private function deleteCustomer($id)
    {
        return $this->customerModel->deleteCustomer($id['id']);
    }

    public function requests($request)
    {
        switch ($request) {
            case 'getAllCustomers':
                if (isset(func_get_args()[1])) {

                    if (func_get_args()[1] == 'datatablesEncode') {
                        echo $this->datatables_encode($this->customerModel->getAllCustomers());
                    }
                    else {
                        echo $this->encode_json($this->customerModel->getAllCustomers());
                    }
                }
                else {
                    echo $this->encode_json($this->customerModel->getAllCustomers());
                }
                break;
            case 'getCustomerPhoneNumberTypes':
                echo self::encode_json($this->customerModel->getCustomerPhoneNumberTypes());
                break;
            case 'getAllPhoneNumberCountryCodes':
                echo self::encode_json($this->customerModel->getAllPhoneNumberCountryCodes());
                break;
            case 'getCustomerEmailAddressTypes':
                echo self::encode_json($this->customerModel->getCustomerEmailAddressTypes());
                break;
            case 'getCustomerPhoneNumbers':
                if (isset($_GET['customerId'])) {
                    echo self::encode_json($this->customerModel->getCustomerPhoneNumbers($_GET['customerId']));
                }
                else {
                    echo 'customerId not provided';
                }
                break;
            case 'getCustomerEmailAddresses':
                if (isset($_GET['customerId'])) {
                    echo self::encode_json($this->customerModel->getCustomerEmailAddresses($_GET['customerId']));
                }
                else {
                    echo 'customerId not provided';
                }
                break;
            case 'getCustomerTitles':
                echo self::encode_json($this->customerModel->getCustomerTitles());
                break;
            case 'getCustomerGroups':
                echo self::encode_json($this->customerModel->getCustomerGroups());
                break;
            case 'getCustomerCompanies':
                echo self::encode_json($this->customerModel->getCustomerCompanies());
                break;
            case 'addCustomer':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addCustomer($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addPhoneNumberType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addPhoneNumberType($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addEmailAddressType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addEmailAddressType($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'updateCustomer':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateCustomer($_POST);
                }
                else {
                    $this->customers();
                }
                break;
            case 'submitCustomerPhoneNumbers':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->submitCustomerPhoneNumbers($_POST);
                }
                else {
                    $this->customers();
                }
                break;
            case 'submitCustomerEmailAddresses':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->submitCustomerEmailAddresses($_POST);
                }
                else {
                    $this->customers();
                }
                break;
            case 'deleteCustomer':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->deleteCustomer($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>