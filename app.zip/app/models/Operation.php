<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:51 AM
 */

class Operation
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }


    public function getOrders()
    {
        $this->db->query('SELECT o.id AS orderId,o.order_number as orderNumber,pt.id AS productTypeId,c.id AS customerId,pt.title AS productTypeTitle,c.name AS customerName FROM `orders` o LEFT JOIN product_types pt ON o.product_type_id = pt.id LEFT JOIN customers c ON o.customer_id = c.id');
        $orders = $this->db->resultSet();
        return $orders;
    }

    public function getProductTypeFieldsWithValues($productTypeId)
    {
        $this->db->query('SELECT ptf.id,f.title,f.description,ptf.field_id AS fieldId,fdt.type AS fieldDataType,fdt.id AS fieldDataTypeId,ft.id AS fieldTypeId,ft.type AS fieldType FROM `product_type_fields` ptf LEFT JOIN `fields` f ON ptf.field_id = f.id LEFT JOIN `field_types` ft ON f.field_type_id = ft.id LEFT JOIN `field_data_types` fdt ON f.data_type_id = fdt.id WHERE ptf.product_type_id = :productTypeId');
        $this->db->bind(':productTypeId', $productTypeId);
        $productTypeFields = $this->db->resultSet();
        foreach ($productTypeFields as $productTypeField) {
            $this->db->query('SELECT id,value FROM `field_values` WHERE field_id = :fieldId');
            $this->db->bind(':fieldId', $productTypeField->fieldId);
            $productTypeFieldValues = $this->db->resultSet();
            $productTypeField->productTypeFieldValues = $productTypeFieldValues;
        }
        return $productTypeFields;
    }

    public function getOrderFieldsWithValues($orderId)
    {
        $this->db->query('SELECT ov.id AS orderValueId,o.customer_id AS customerId,o.order_number as orderNumber, c.name AS customerName,pt.id AS productTypeId,pt.title AS productTypeTitle, f.id AS fieldId, f.title AS fieldTitle, f.data_type_id AS fieldDataTypeId, fv.id AS fieldValueId, fv.value AS fieldValueValue FROM `order_values` ov LEFT JOIN field_values fv ON ov.field_value_id = fv.id LEFT JOIN fields f ON fv.field_id = f.id LEFT JOIN orders o ON ov.order_id = o.id LEFT JOIN customers c ON o.customer_id = c.id LEFT JOIN product_types pt ON o.product_type_id = pt.id WHERE ov.order_id = :orderId');
        $this->db->bind(':orderId', $orderId);
        $orderFields = $this->db->resultSet();

        return $orderFields;
    }

    public function getOrderProcesses($orderId)
    {
        $this->db->query('SELECT p.id as processId,pt.sequence,pt.title,p.status FROM `processes` p LEFT JOIN process_types pt ON  p.process_id = pt.id WHERE order_id = :orderId ORDER BY pt.sequence ASC ' );
        $this->db->bind(':orderId', $orderId);
        $orderProcesses = $this->db->resultSet();

        return $orderProcesses;
    }

    public function addFile($fileDetails)
    {
        //name
        //fieldTypeId
        //orderId

        $orderId = $fileDetails['orderId'];
        $name = $fileDetails['name'];
        $fieldTypeId = $fileDetails['fieldTypeId'];
        $fieldId = $fileDetails['fieldId'];
        $this->db->query('INSERT INTO `field_values` (field_id, field_type, value) VALUES (:fieldId, :fieldTypeId, :name)');
        $this->db->bind(':name', $name);
        $this->db->bind(':fieldId', $fieldId);
        $this->db->bind(':fieldTypeId', $fieldTypeId);
        $this->db->execute();
        return $this->db->getLastInsertedId();
//        }
//        else {
//            return 'error : invalid option type';
//        }
    }

    public function updateFileURL($id, $url)
    {

        $this->db->query('UPDATE field_values SET value = :url WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->bind(':url', $url);
        return $this->db->execute();
    }

    public function submitOrderProcessesChanges($processes)
    {
        $processes = $processes['processes'];
        foreach ($processes as $process) {
            $status = $process['status'];
            $id = $process['id'];
            $this->db->query('UPDATE `processes` SET `status` = :status WHERE id = :id');
            $this->db->bind(':id', $id);
            $this->db->bind(':status', $status);
            $this->db->execute();
        }
        return 1;
    }

    public function addFieldValue($fieldId, $fieldType, $fieldValue)
    {

        $this->db->query('INSERT INTO `field_values` (field_id,field_type, value) VALUES (:fieldId,:fieldType,:fieldValue);');
        $this->db->bind(':fieldId', $fieldId);
        $this->db->bind(':fieldType', $fieldType);
        $this->db->bind(':fieldValue', $fieldValue);
        $this->db->execute();
        return $this->db->getLastInsertedId();
    }

    public function addOrderValue($orderId, $fieldValueId)
    {

        $this->db->query('INSERT INTO `order_values` (order_id,field_value_id) VALUES (:orderId,:fieldValueId);');
        $this->db->bind(':orderId', $orderId);
        $this->db->bind(':fieldValueId', $fieldValueId);
        return $this->db->execute();
    }

    public function addOrder($productTypeId,$orderNumber, $customerId, $dateDue, $datePlaced)
    {

        $dateDueString = [];
        $dateDueString[0] = '';
        $dateDueString[1] = '';
        $datePlacedString = [];
        $datePlacedString[0] = '';
        $datePlacedString[1] = '';
        if ($dateDue != null) {
            $dateDueString[0] = ', `date_due`';
            $dateDueString[1] = ',:dateDue';
        }
        if ($datePlaced != null) {
            $datePlacedString[0] = ',`date_placed`';
            $datePlacedString[1] = ',:datePlaced';
        }
        $this->db->query('INSERT INTO `orders` (`product_type_id`,`order_number`, `customer_id`' . $dateDueString[0] . $datePlacedString[0] . ') VALUES (:productTypeId,:orderNumber,:customerId' . $dateDueString[1] . $datePlacedString[1] . ')');
        $this->db->bind(':productTypeId', $productTypeId);
        $this->db->bind(':customerId', $customerId);
        $this->db->bind(':orderNumber', $orderNumber);
        if ($dateDue != null) {
            $this->db->bind(':dateDue', $dateDue);
        }
        if ($dateDue != null) {
            $this->db->bind(':datePlaced', $datePlaced);

        }
        $this->db->execute();
        $orderId =  $this->db->getLastInsertedId();
        $getProcessesTypesQuery = 'SELECT id FROM process_types WHERE product_type_id = :productTypeId';
        $this->db->query($getProcessesTypesQuery);
        $this->db->bind(':productTypeId', $productTypeId);
        $processTypes = $this->db->resultSet();
        foreach ($processTypes as $processType) {
            $this->db->query('INSERT INTO processes (process_id, order_id) VALUES (:processId,:orderId)');
            $this->db->bind(':processId', $processType->id);
            $this->db->bind(':orderId', $orderId);
            $this->db->execute();
        }
        return $orderId;
    }


}