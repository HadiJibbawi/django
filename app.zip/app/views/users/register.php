<?php require APPROOT . '/views/inc/header.php'; ?>
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card card-body bg-light mt-5 border border-secondary">
            <div class="container">
                <div class="row mx-auto">
                    <?php echo flash('car_registered'); ?>
                </div>
            </div>
            <h2>Submit Your Car Info</h2>
            <p>Please fill out this form by checking the corresponding Button</p>
            <form action="<?php echo URLROOT ?>/users/register" method="post">
                <div class="form-group">
                    <label for="name">Name: <sup>*</sup></label>
                    <input type="text" name="name" class="form-control form-control-lg <?php echo (!empty($data['name_err'])) ? 'is-invalid' : '' ?>" value="<?php echo $data['name']; ?>" required>
                    <span class="invalid-feedback"><?php echo $data['name_err']; ?></span>
                </div>
                <div class="form-group form-check">
                    <label for="car_number">Car Number Is Even? <sup>*</sup></label>
                    <input type="radio" name="car_number" id="even" class="form-control form-control-lg form-check-input <?php echo (!empty($data['car_number_err'])) ? '' : '' ?>" value="even" required>
                    <span class="invalid-feedback"><?php echo $data['car_number_err']; ?></span>
                </div>
                <br/><br/><br/>
                <div class="form-group form-check">
                    <label for="car_number">Car Number Is ODD? <sup>*</sup></label>
                    <input type="radio" name="car_number" id="odd" class="form-control form-control-lg form-check-input <?php echo (!empty($data['car_number_err'])) ? '' : '' ?>" value="odd" required>
                    <span class="invalid-feedback"><?php echo $data['car_number_err']; ?></span>
                </div>
                <br/><br/>
                <br/>
                <div class="row">
                    <div class="col">
                        <input type="submit" value="Submit" class="btn btn-success btn-block">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>

