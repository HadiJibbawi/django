from django.db import models
from home.models import UserProfile, User



class Schedule(models.Model):
    schedule_id = models.AutoField(primary_key=True) 
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    work_day = models.CharField(max_length=10)
    start_time = models.TimeField(auto_now=False, auto_now_add=False)
    end_time = models.TimeField(auto_now=False, auto_now_add=False)
    weekend = models.IntegerField()

        
class Actual_Schedule(models.Model):
    schedule_id = models.AutoField(primary_key=True) 
    user =models.ForeignKey(User, on_delete=models.CASCADE)
    schedule_date = models.DateField()
    schedule_day = models.CharField(max_length=10)
    entrance_time = models.TimeField()
    exit_time = models.TimeField()
    is_holiday = models.IntegerField()
    reason = models.CharField(max_length=180)
  