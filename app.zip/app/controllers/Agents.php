<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:40 AM
 */

class Agents extends Controller
{
    private $agentModel;

    public function __construct()
    {
        $this->agentModel = $this->model('Agent');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function agents()
    {
        $data = ['title' => 'Agents', 'description' => 'Page for Agent Management'];
        $template = [];
        $template['page_script'] = 'agents';
        $this->view('admin/agents', $data, $template);
    }

    private function addAgent($agent)
    {

        return $this->agentModel->addAgent($agent);
    }

    private function addPhoneNumberType($phoneNumberType)
    {

        return $this->agentModel->addPhoneNumberType($phoneNumberType['data']);
    }
    private function addEmailAddressType($emailAddressType)
    {

        return $this->agentModel->addEmailAddressType($emailAddressType['data']);

    }

    private function updateAgent($agent)
    {
        foreach ($agent as $key => $item) {
            $newKey = $this->camelCaseToUnderscore($key);
            if ($newKey == $key) {
                continue;
            }
            $agent[$newKey] = $item;
            unset($agent[$key]);
        }
        if (isset($agent['agent_company'])) {
            $agent['company'] = $agent['agent_company'];
            unset($agent['agent_company']);
        }
        if (isset($agent['agent_title'])) {
            $agent['title'] = $agent['agent_title'];
            unset($agent['agent_title']);
        }
        if (isset($agent['agent_job'])) {
            $agent['job'] = $agent['agent_job'];
            unset($agent['agent_job']);
        }
        echo $this->agentModel->updateAgent($agent);
    }

    private function submitAgentPhoneNumbers($phoneNumbers)
    {
        $agentId = $phoneNumbers['agentId'];
        $phoneNumbers = $phoneNumbers['data'];
        foreach ($phoneNumbers as $phoneNumber) {
            foreach ($phoneNumber as $key => $item) {
                $newKey = $this->camelCaseToUnderscore($key);
                if ($newKey == $key) {
                    continue;
                }
                $phoneNumber[$newKey] = $item;
                unset($phoneNumber[$key]);
            }
            if ($phoneNumber['id'] == 0) {
                if (isset($phoneNumber['_destroy'])) {
                    continue;
                }
                $phoneNumber['type'] = $phoneNumber['phone_number_type_id'];
                unset($phoneNumber['phone_number_type_id']);
                unset($phoneNumber['id']);
                $this->agentModel->addAgentPhoneNumber($agentId, $phoneNumber);
            }
            else {
                if (isset($phoneNumber['_destroy'])) {
                    $this->agentModel->deleteAgentPhoneNumber($phoneNumber['id']);
                }
                else {
                    if (isset($phoneNumber['phone_number_type_id'])) {
                        $phoneNumber['type'] = $phoneNumber['phone_number_type_id'];
                        unset($phoneNumber['phone_number_type_id']);
                    }
                    $this->agentModel->updatePhoneNumber($phoneNumber);
                }
            }
        }

        echo 1;
    }

    private function submitAgentEmailAddresses($emailAddresses)
    {
        $agentId = $emailAddresses['agentId'];
        $emailAddresses = $emailAddresses['data'];
        foreach ($emailAddresses as $emailAddress) {
            foreach ($emailAddress as $key => $item) {
                $newKey = $this->camelCaseToUnderscore($key);
                if ($newKey == $key) {
                    continue;
                }
                $emailAddress[$newKey] = $item;
                unset($emailAddress[$key]);
            }
            if ($emailAddress['id'] == 0) {
                if (isset($emailAddress['_destroy'])) {
                    continue;
                }
                $emailAddress['type'] = $emailAddress['email_address_type_id'];
                unset($emailAddress['email_address_type_id']);
                $emailAddress['address'] = $emailAddress['email_address'];
                unset($emailAddress['email_address']);
                unset($emailAddress['id']);
                $this->agentModel->addAgentEmailAddress($agentId, $emailAddress);
            }
            else {
                if (isset($phoneNumber['_destroy'])) {
                    $this->agentModel->deleteAgentEmailAddress($emailAddress['id']);
                }
                else {
                    if (isset($emailAddress['email_address_type_id'])) {
                        $emailAddress['type'] = $emailAddress['email_address_type_id'];
                        unset($emailAddress['email_address_type_id']);
                    }
                    if (isset($emailAddress['email_address'])) {
                        $emailAddress['address'] = $emailAddress['email_address'];
                        unset($emailAddress['email_address']);
                    }
                    $this->agentModel->updateEmailAddress($emailAddress);
                }
            }
        }

        echo 1;
    }

    private function deleteAgent($id)
    {
        return $this->agentModel->deleteAgent($id['id']);
    }

    public function requests($request)
    {
        switch ($request) {
            case 'getAllAgents':
                if (isset(func_get_args()[1])) {

                    if (func_get_args()[1] == 'datatablesEncode') {
                        echo $this->datatables_encode($this->agentModel->getAllAgents());
                    }
                    else {
                        echo $this->encode_json($this->agentModel->getAllAgents());
                    }
                }
                else {
                    echo $this->encode_json($this->agentModel->getAllAgents());
                }
                break;
            case 'getAgentPhoneNumberTypes':
                echo self::encode_json($this->agentModel->getAgentPhoneNumberTypes());
                break;
            case 'getAgentJobs':
                echo self::encode_json($this->agentModel->getAgentJobs());
                break;
            case 'getAllPhoneNumberCountryCodes':
                echo self::encode_json($this->agentModel->getAllPhoneNumberCountryCodes());
                break;
            case 'getAgentEmailAddressTypes':
                echo self::encode_json($this->agentModel->getAgentEmailAddressTypes());
                break;
            case 'getAgentPhoneNumbers':
                if (isset($_GET['agentId'])) {
                    echo self::encode_json($this->agentModel->getAgentPhoneNumbers($_GET['agentId']));
                }
                else {
                    echo 'agentId not provided';
                }
                break;
            case 'getAgentEmailAddresses':
                if (isset($_GET['agentId'])) {
                    echo self::encode_json($this->agentModel->getAgentEmailAddresses($_GET['agentId']));
                }
                else {
                    echo 'agentId not provided';
                }
                break;
            case 'getAgentTitles':
                echo self::encode_json($this->agentModel->getAgentTitles());
                break;
            case 'getAgentGroups':
                echo self::encode_json($this->agentModel->getAgentGroups());
                break;
            case 'getAgentCompanies':
                echo self::encode_json($this->agentModel->getAgentCompanies());
                break;
            case 'addAgent':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addAgent($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addPhoneNumberType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addPhoneNumberType($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addEmailAddressType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addEmailAddressType($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'updateAgent':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateAgent($_POST);
                }
                else {
                    $this->agents();
                }
                break;
            case 'submitAgentPhoneNumbers':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->submitAgentPhoneNumbers($_POST);
                }
                else {
                    $this->agents();
                }
                break;
            case 'submitAgentEmailAddresses':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->submitAgentEmailAddresses($_POST);
                }
                else {
                    $this->agents();
                }
                break;
            case 'deleteAgent':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->deleteAgent($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>