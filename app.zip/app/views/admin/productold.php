<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 11/05/20
 * Time: 12:56 PM
 */
?>

<?php
$table_columns = ['Option', 'Type'];
$table_properties = ["title" => 'Options'];
?>
<script>
    // noinspection JSAnnotator
    const originalProduct = <?php echo json_encode($data['product'])?>;
    // noinspection JSAnnotator
    const categories = <?php echo json_encode($data['categories'])?>;
    // noinspection JSAnnotator
    const discountTypes = <?php echo json_encode($data['discountTypes'])?>;
    // noinspection JSAnnotator
    const currentCurrency = '<?php echo $data['currency']?>';
    // noinspection JSAnnotator
    const defaultTab = '<?php echo $data['tab']?>';
</script>

<h2 style="margin-top: 4rem;margin-bottom: 2rem"><?php echo $data['title'] ?></h2>
<div class="card">
    <div class="card-header"></div>
    <div class="card-body">
        <ul class="nav nav-tabs bg-white">
            <li class="nav-item">
                <a class="nav-link" data-bind="css:{'active':$root.currentTab() == 'details'},click:function(data,event){$root.showTab('details')}"><span class="fa fa-info-circle text-dark"></span> Product Details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bind="css:{'active':$root.currentTab() == 'items'},click:function(data,event){$root.showTab('items')}"><span class="fa fa-box-open text-dark"></span> Items & Options</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bind="css:{'active':$root.currentTab() == 'images'},click:function(data,event){$root.showTab('images')}"><span class="fa fa-image text-dark"></span> Images
                </a>
            </li>
        </ul>
        <div class="card">
            <div id="product_current_tab" class="card-body">
                <div id="product_details_container" class="container" hidden>
                    <div class="row">
                        <div class="col-12 mt-4">
                            <label for="product_title">Title</label>
                            <input id="product_title" name="title" data-bind="textInput :  $root.title(),attr : {'placeholder' : 'Title'}" class="form-control" type="text"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mt-4">
                            <label for="product_description">Description</label>
                            <input id="product_description" name="description" data-bind="textInput :  $root.description(),attr : {'placeholder' : 'Description'}" class="form-control" type="text"/>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 mt-4">
                            <span style="cursor: default" class="btn" data-bind="click:function(data,event){$root.gender('M')}, css:{'boy-blue':$root.gender() == 'M','boy-blue-inactive':$root.gender() == 'F'}">Boy</span>
                            <span style="cursor: default" class="btn" data-bind=" click:function(data,event){$root.gender('F')},css:{'girl-pink-inactive':$root.gender() == 'M','girl-pink':$root.gender() == 'F'}">Girl</span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mt-4">
                            <label for="product_cost" data-bind="text:'Cost in ' + $root.currentCurrency"></label>
                            <input id="product_cost" name="cost" data-bind="textInput :  $root.cost(),attr : {'placeholder' : 'Cost '}" class="form-control" type="number"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mt-4">
                            <label for="product_discount" data-bind="text:'Discount in ' + $root.currentCurrency "></label>
                            <span style="cursor: default" class="btn" data-bind="click:function(data,event){$root.discountType($root.discountTypes['percentage'])}, css:{'button-checkbox-a':$root.discountType() == $root.discountTypes['percentage'],'button-checkbox-a-inactive':$root.discountType() == $root.discountTypes['amount']}"><span class="fa fa-percent"></span> Percentage</span>
                            <span style="cursor: default" class="btn" data-bind="click:function(data,event){$root.discountType($root.discountTypes['amount'])}, css:{'button-checkbox-b-inactive':$root.discountType() == $root.discountTypes['percentage'],'button-checkbox-b':$root.discountType() == $root.discountTypes['amount']}"><span class="fa fa-money-bill-wave"></span> Amount</span>
                            <input id="product_discount" name="discount" data-bind="attr:{'placeholder' : 'Discount '},textInput :  $root.discount" class="form-control mt-2" type="number"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6 mt-4">
                            <label for="product_price" data-bind="text:'Price in ' + $root.currentCurrency"></label>
                            <input id="product_price" name="price" data-bind="textInput :  $root.price(),attr : {'placeholder' : 'Price '}" class="form-control" type="number"/>
                        </div>
                        <div class="col-6 mt-4">
                            <label for="product_discounted_price" data-bind="text:'Price After Discount in ' + $root.currentCurrency"></label>
                            <input id="product_discounted_price" name="discounted_price" data-bind="textInput :  $root.discountedPrice(),attr : {'placeholder' : 'Discounted Price '}" class="form-control" type="number"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mt-4">
                            <label for="product_category">Category</label>
                            <select class="form-control" name="category" id="product_category" data-bind="options : $root.categories,value:$root.category(),optionsValue : 'id',optionsText:'title',optionsCaption:'Choose Category'"></select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mt-4">
                            <label for="status_buttons">Status</label>
                            <div id="status_buttons">
                                <span class="btn btn-outline-success" data-bind="click:function(data,event){$root.status('true')},style: {opacity:$root.status() == 'true' ? '1' : '0.7', backgroundColor: $root.status() == 'true' ? 'rgba(33,136,56,0.4)' : 'rgba(33,136,56,0.12)' },css:{'btn-outline-success':$root.status() == 'true','btn-outline-secondary':$root.status() == 'false'}"><span class="fa fa-check-circle">Published</span></span>
                                <span class="btn btn-outline-warning" data-bind="click:function(data,event){$root.status('false')},style: {color:$root.status() == 'false' ? 'black' : 'gray',opacity:$root.status() == 'false' ? '1' : '0.7', backgroundColor: $root.status() == 'false' ? 'rgba(255,193,7,0.4)' : 'rgba(255,193,7,0.12)' },css:{'btn-outline-warning':$root.status() == 'false','btn-outline-secondary':$root.status() == 'true'}"><span class="fa fa-times-circle">Unpublished</span></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <button data-bind="click:$root.deleteProduct" class="btn btn-danger mt-3">Delete</button>
                    </div>
                </div>
                <div id="product_items_container" class="container-fluid" hidden>
                    <div id="options_row" class="row justify-content-between">
                        <div class="col-5">
                            <?php
                            $table_columns = ['Option', 'Description', 'Type', 'Details'];
                            $table_properties = ["tableId" => "datatable_product_generic_options", "title" => 'Generic Options', 'title-size' => 'h3', 'padding' => '0.5rem'];
                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                            ?>
                        </div>
                        <div class="col-6">
                            <?php
                            $table_columns = ['Option', 'Description', 'Type'];
                            $table_properties = ["tableId" => "datatable_product_options", "title" => 'Options', 'title-size' => 'h3', 'padding' => '0.5rem'];
                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                            ?>
                        </div>
                    </div>
                    <hr>
                    <div id="items_row" class="row mb-5 justify-content-around">
                        <div class="col-6">
                            <?php
                            $table_columns = ['Item Options', 'Quantity'];
                            $table_properties = ["tableId" => "datatable_product_items", "title" => 'Items', 'padding' => '1rem'];
                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                            ?>
                        </div>
                        <div data-bind="if:$root.selectedItem().id != 0" id="item_details" class="col-5 card shadow mt-5">
                            <div class="bg-white mt-3">
                                <h2 data-bind="text : $root.selectedItem().optionValues()"></h2>
                            </div>
                            <div class="card-body">
                                <div class="col-12" style="background-color: white; padding: 1rem; margin: 0rem;border: lightgrey; border-style: solid;; border-width: 0.05rem;">
                                    <div class="row justify-content-start">
                                        <div class="col-6">
                                            <label for="item_quantity_input"> Quantity</label>
                                            <input id="item_quantity_input" type="number" data-bind="textInput : $root.selectedItem().quantity" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row" style="padding: 1rem;">
                                        <div id="table_option_values_header">
                                            <!--                                            <button class="btn btn-secondary btn-sm btn-info" type="button">-->
                                            <!--                                                <span><span class="fa fa-plus-circle">Add Value </span></span></button>-->
                                        </div>
                                        <table class="display table table-bordered table-striped table-responsive-sm table-responsive-md table-responsive-lg table-hover dataTable no-footer" style="width: 100%;" border="1">
                                            <thead>
                                            <tr>
                                                <th>Option</th>
                                                <th>Value</th>
                                            </tr>
                                            </thead>
                                            <tbody data-bind="foreach: $root.selectedItem().options() ">
                                            <tr>
                                                <!--     <td>-->
                                                <!--     <pre data-bind="text: ko.toJSON($data,null,2)"></pre>-->
                                                <!--    </td>-->
                                                <td data-bind="text : $data.name"></td>
                                                <!--<td data-bind="text : $data.value"></td>-->
                                                <!-- ko if: $data.typeId() == OptionTypeListId || $data.typeId() == OptionTypeColorId -->
                                                <td>
                                                    <select class="form-control" name="value" data-bind="options : $data.values,value:$data.selectedValue.id,optionsValue : 'id',optionsText:'value'" required></select>
                                                </td>
                                                <!-- /ko -->
                                                <!-- ko if: $data.typeId() == OptionTypeTextId-->
                                                <td>
                                                    <input type="text" class="form-control" data-bind="textInput:$data.selectedValue.value">
                                                </td>
                                                <!-- /ko -->
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="row justify-content-around">
                                        <div class="col-2">
                                            <button class="btn btn-success" data-bind="click : $root.saveItemDetails"> Save </button>
                                        </div>
                                        <div class="col-2">
                                            <button class="btn btn-danger" data-bind="click : $root.deleteItem"> Delete </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="product_images_container" class="container-fluid" hidden>
                    <div id="cover-image" class="row mb-5">
                        <div class="card shadow" style="width: 100%;">
                            <div class="card-body">
                                <h3> Cover Image </h3>
                                <div class="col-12" style="background-color: white; padding: 1rem; margin: 0rem;border: lightgrey; border-style: solid;; border-width: 0.05rem;">
                                    <div class="row justify-content-around">
                                        <div class="col-3">
                                            <div class="jms-overlay-container">
                                                <div class="jms-overlay-base-image">
                                                    <img class="product-image" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                                </div>
                                                <div class="jms-overlay-middle">
                                                    <div class="jms-overlay-text">
                                                        <span class="fa fa-camera"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="all_product_images" class="row mb-5">
                        <div class="card shadow" style="width: 100%;">
                            <div class="card-body">
                                <div class="row justify-content-around">
                                    <div class="col-3">
                                        <h3> Product Images </h3>
                                    </div>
                                    <div class="col-6"></div>
                                    <div class="col-3">
                                        <!--this makes the form input shape like a bootstrap button-->
                                        <!--                                        <label class="btn btn-violet-primary float-right">-->
                                        <!--                                            <span class="fa fa-plus-circle"></span> Add Images-->
                                        <!--                                            <input id="productImagesInput" type="file" multiple hidden>-->
                                        <!--                                        </label>-->
                                        <button class="btn btn-violet-primary float-right" data-bind="click:function(click,event){$('#add_images_modal').modal('show');}">
                                        <span class="fa fa-plus-circle"></span>Add Images
                                        </button>
                                    </div>
                                </div>
                                <div style="background-color: white; padding: 2rem; margin: 0rem;border: lightgrey; border-style: solid;; border-width: 0.05rem;">
                                    <div class="row">
                                        <div id="productImagesContainer" class="justify-content-left row">

                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>

                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>
                                            <div class=" col-2 mb-3 border">
                                                <input id="asdf" type="checkbox">
                                                <img class="product-image" draggable="false" data-bind="click:function(data,event){document.querySelector('#asdf').checked = !document.querySelector('#asdf').checked;}" src="/violet/img/1_red_jacket_girl_front.jpg" style=" width: 100%; height: auto;">
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="card">
                            <div class="card-header">
                                <h4> Other images</h4>
                            </div>
                            <div class="card-body">
                                <div class="col-12" style="background-color: white; padding: 1rem; margin: 0rem;border: lightgrey; border-style: solid;; border-width: 0.05rem;">
                                    <h4>
                                        asdf
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Add Option Modal-->
    <div id="new_option_modal" class="modal show">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title" id="new_option_modal_label">New Option</h5>
                    <button type="button" class="close" data-bs-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addOptionForm">
                        <div class="form-group">
                            <label for="new_option_name">Name</label>
                            <input id="new_option_name" name="name" data-bind="textInput :  $root.newOptionName,attr : {'placeholder' : 'Option Name'}" class="form-control" type="text" required/>
                            <br>
                            <label for="new_option_description">Description</label>
                            <input id="new_option_description" name="description" data-bind="textInput :  $root.newOptionDescription,attr : {'placeholder' : 'Description'}" class="form-control" type="text"/>
                            <br>
                            <label for="new_option_type">Type</label>
                            <br/>
                            <select class="form-control" name="type" id="new_option_type" data-bind="options : $root.optionTypes,value:$root.newOptionType,optionsValue : 'id',optionsText:'type',optionsCaption:'Choose Type'" required></select>
                            <br>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewOptionModal">Clear</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button id="save_new_option_btn" type="button" data-bind="click:$root.addOption" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </div>

    <!--Add Item Modal-->
    <div id="new_item_modal" class="modal show">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title" id="new_item_modal_label">New Item</h5>
                    <button type="button" class="close" data-bs-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addItemForm">
                        <div class="form-group">
                            <!--                       <div class="row">-->
                            <!--                           <label for="new_item_quantity">Quantity</label>-->
                            <!--                           <input id="new_item_quantity" name="name" data-bind="textInput :  $root.newItemQuantity,attr : {'placeholder' : 'Option Quantity'}" class="form-control" type="number" required/>-->
                            <!--                       </div>-->
                            <div class="row">
                                <h2 data-bind="text : $root.newItem().optionValues()"></h2>
                                <div class="col-12" style="background-color: white; padding: 1rem; margin: 0rem;border: lightgrey; border-style: solid;; border-width: 0.05rem;">
                                    <div class="row justify-content-start">
                                        <div class="col-6">
                                            <label for="new_item_quantity_input"> Quantity</label>
                                            <input id="new_item_quantity_input" type="number" data-bind="textInput : $root.newItem().quantity" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row" style="padding: 1rem;">
                                        <div id="new_item_table_option_values_header">
                                            <!--                                            <button class="btn btn-secondary btn-sm btn-info" type="button">-->
                                            <!--                                                <span><span class="fa fa-plus-circle">Add Value </span></span></button>-->
                                        </div>
                                        <table class="display table table-bordered table-striped table-responsive-sm table-responsive-md table-responsive-lg table-hover dataTable no-footer" style="width: 100%;" border="1">
                                            <thead>
                                            <tr>
                                                <th>Option</th>
                                                <th>Value</th>
                                            </tr>
                                            </thead>
                                            <tbody data-bind="foreach: $root.productOptions() ">
                                            <tr>
                                                <!--     <td>-->
                                                <!--     <pre data-bind="text: ko.toJSON($data,null,2)"></pre>-->
                                                <!--    </td>-->
                                                <td data-bind="text : $data.name()"></td>
                                                <!--<td data-bind="text : $data.value"></td>-->
                                                <!-- ko if: $data.typeId() == OptionTypeListId || $data.typeId() == OptionTypeColorId -->
                                                <td>
                                                    <select class="form-control" name="value" data-bind="options : $data.values,value:$data.selectedValue().id,optionsValue : 'id',optionsText:'value',optionsCaption:'Choose Value'" required></select>
                                                </td>
                                                <!-- /ko -->
                                                <!-- ko if: $data.typeId() == OptionTypeTextId-->
                                                <td>
                                                    <input type="text" class="form-control" data-bind="textInput:$data.selectedValue().value">
                                                </td>
                                                <!-- /ko -->
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewItemModal">Clear</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="add_new_item_btn" type="button" data-bind="click:$root.addItem" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>

<!--Edit Option Modal-->
<div id="edit_option_modal" class="modal show" style="z-index: 1100;">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="edit_option_modal_label">Edit Option</h5>
                <button type="button" class="close" data-bs-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-7 mt-5">
                        <div class="card">
                            <div class="card-body shadow">
                                <form id="editOptionForm" data-bind="if : $root.currentOption().id != '0'">
                                    <div class="form-group" data-bind="with : $root.currentOption()">
                                        <label for="edit_option_name">Name</label>
                                        <input id="edit_option_name" name="name" data-bind="textInput :  name,attr : {'placeholder' : 'Option Name'}" class="form-control" type="text" required/>
                                        <br>
                                        <label for="edit_option_description">Description</label>
                                        <input id="edit_option_description" name="description" data-bind="textInput :  description(),attr : {'placeholder' : 'Description'}" class="form-control" type="text"/>
                                        <br>
                                        <label for="edit_option_type">Type</label>
                                        <br/>
                                        <select class="form-control" name="type" id="edit_option_type" data-bind="options : $root.optionTypes,value:typeId,optionsValue : 'id',optionsText:'type',optionsCaption:'Choose Type'" required></select>
                                        <br>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearEditOptionModal">Clear</button>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button id="save_edit_option_btn" type="button" data-bind="click:$root.editCurrentOption" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div id="option_values_table_container" class="col-5"
                    ">
                    <?php
                    $table_columns = ['value', 'Remove'];
                    $table_properties = ["tableId" => "datatable_option_details_values", "title" => 'Option Values', 'title-size' => 'h3', 'padding' => '0.5rem'];
                    include(APPROOT . '/views/partials/_datatable_full_generic.php');
                    ?>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</div>


<!--Add Option Value Modal-->
<div id="new_option_value_modal" class="modal show" style="z-index: 1110;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="new_option_value_modal_label">New Option Value</h5>
                <button type="button" class="close" data-bs-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addOptionValueForm">
                    <div class="form-group">
                        <label for="new_option_value_name">Name</label>
                        <input id="new_option_value_name" name="value" data-bind="textInput :  $root.newOptionValue,attr : {'placeholder' : 'Option Value'}" class="form-control" type="text" required/>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewOptionValueModal">Clear</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button id="save_new_option_value_btn" type="button" data-bind="click:$root.addOptionValue" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>


<!--Add Images Modal-->
<div id="add_images_modal" class="modal show">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="add_images_modal_label">Add Images</h5>
                <button type="button" class="close" data-bs-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <!--this makes the form input shape like a bootstrap button-->
                    <label class="btn btn-violet-primary">
                        <span class="fa fa-plus-circle"></span> Select Images
                        <input id="productImagesInput" type="file" multiple hidden>
                    </label>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewOptionValueModal">Clear</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="save_new_option_value_btn" type="button" data-bind="click:$root.addOptionValue" class="btn btn-primary">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>


