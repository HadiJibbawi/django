from django.contrib import admin
from tracker.models import Schedule, Actual_Schedule

admin.site.register(Schedule)
admin.site.register(Actual_Schedule)