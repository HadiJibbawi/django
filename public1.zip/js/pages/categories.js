const category_view_model = new CategoryViewModel();

function CategoryViewModel() {
    const self = this;

    self.currentRow = ko.observable();
    self.currentCategory = ko.observable(new Category());
    self.currentParentCategoryStack = [];
    self.currentParentCategoryStack.push(new Category({'id': 1,'tier':'1'}));
    self.newCategory = ko.observable(new Category({}));

    self.productCategories = ko.observableArray([]);

    self.openEditCategory = function (data) {
        $('#edit_Category_modal').modal('show');
    };


    self.getAllProductCategories = function () {
        let route = ['products', 'requests', 'getAllProductCategories'];
        fetchDataJson(route, {}, function (categories) {
            self.productCategories(categories);
            self.productCategories.push({'id': '1', 'title': 'root'});
        });
    };
    self.getAllProductCategories();

    self.clearNewCategoryModal = function () {
        $.each(self.currentCategory(), function (prop) {
            prop(undefined);
        });
    };

    self.addCategory = function () {
        let addCategoryForm = $('#addCategoryForm');

        //perform validation check (simulate real form submit button)
        if (!addCategoryForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addCategoryForm).click().remove();
        }
        else {
            let route = ['products', 'requests', 'addCategory'];
            let category = {};
            $.each(self.newCategory(), function (index, prop) {
                if (index != 'id' && index != 'enableDelete' && index !='enableTier') {
                    if (prop() == undefined) {
                        prop('');
                    }
                    category[index] = prop();
                }
            });
            postData(route, category, function (result) {
                if (result == 1) {
                    toastr.success('Category Added Successfully');
                    // self.clearNewCategoryModal();
                    $('#datatable_categories').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Category Addition Failed');
                }
            });
            $('add_Category_modal').modal('hide');
        }
    };

    self.deleteCurrentCategory = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentCategory().title);
        if (confirmDelete) {
            let deleteRoute = ['products', 'requests', 'deleteCategory'];
            postData(deleteRoute, {'id': self.currentCategory().id()}, function (response) {
                if (response == '1') {
                    toastr.success('Category Deleted');
                    self.currentCategory(new Category());
                    $('#datatable_categories').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Category Deletion Failed');
                }
            });
        }
    };

    self.resetCurrentCategory = function () {
        let table = $('#datatable_categories').DataTable();
        let data = ko.toJS(table.row(self.currentRow()).data());
        category_view_model.currentCategory(new Category(data));
    };

    self.submitEditCategory = function () {

        let editCurrentCategoryForm = $('#editCurrentCategoryForm');

        if (!editCurrentCategoryForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentCategoryForm).click().remove();
        }
        else {

            let route = ['products', 'requests', 'updateCategory'];
            let table = $('#datatable_categories').DataTable();
            let category = {};
            const originalCategory = ko.toJS(table.row(self.currentRow()).data());
            const currentCategory = ko.toJS(self.currentCategory);
            console.log(originalCategory);
            console.log(currentCategory);
            for (const prop in originalCategory) {
                if (originalCategory[prop] != currentCategory[prop]) {
                    category[prop] = currentCategory[prop];
                }
            }
            if ($.isEmptyObject(category)) {
                alert('No changes have been made');
                return;
            }
            category['id'] = originalCategory.id;
            postData(route, category, function (result) {
                if (result == '1') {
                    toastr.success('Category Edited Successfully');
                    let table = $('#datatable_categories').DataTable();
                    table.ajax.reload();
                    self.currentCategory({'categoryidentifier': ''});
                }
                else {
                    toastr.warning('Category Edit Failed');
                }
            });
        }
    };
}

function Category(category) {
    const self = this;

    //foreach category.item create a
    self.id = category == undefined ? ko.observable('') : ko.observable(category.id);
    self.title = category == undefined ? ko.observable('') : ko.observable(category.title);
    self.description = category == undefined ? ko.observable('') : ko.observable(category.description);
    self.parent = category == undefined ? ko.observable('') : ko.observable(category.parent);
    self.tier = category == undefined ? ko.observable('') : ko.observable(category.tier);

    self.enableDelete = ko.observable(false);
    self.enableTier = ko.observable(false);
}

ko.applyBindings(category_view_model);

const categoriesTableId = 'datatable_categories';
const categoriesButtonFunc = '$(\'#add_Category_modal\').modal(\'show\');';
const categoriesDomParams = 'lfBrtip';
const categoriesCustomButton = {
    'class': 'btn-secondary btn',
    'text': 'Back',
    'icon': 'fa fa-backspace',
    'click': 'changeCategory(true)'
};
const categoriesContentName = 'Category';
const categoriesDatatableAjaxRoute = '/products/requests/getProductCategories/datatablesEncode/1';
const categoriesColumns = [
    {'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']},
    {'data': ['description', 'false']},
    {'data': ['tier', 'false']},
    {'data': ['id', 'new String(\'<button  onclick="category_view_model.openEditCategory(\' + data + \')" class="btn btn-bdesign-primary btn-sm"> Details <span class="fa fa-share-square"> </span></button>\')']}
];

//foreach Categoriesdatatable columns : add to categoryColumns {'data' : ['categoryColumnName' , 'renderer | false']}
// example : ['name', '(data.charAt(0).toUpperCase() + data.slice(1))']

configureDatatable(categoriesTableId, categoriesButtonFunc, categoriesCustomButton, categoriesDomParams, categoriesContentName, categoriesDatatableAjaxRoute, categoriesColumns);


$(document).ready(function () {
    let table = $('#datatable_categories').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_categories tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_categories tbody').on('click', 'tr', function () {
        category_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        category_view_model.currentCategory(new Category(data));
        console.log(ko.toJS(category_view_model.currentCategory()));
        if (data != undefined) {
            changeCategory();
        }
    });

    //this allows for a custom message in case the user enters an invalid password

});

function changeCategory(back = false) {
    let table = $('#datatable_categories').DataTable();

    if (back) {
        let top = category_view_model.currentParentCategoryStack[category_view_model.currentParentCategoryStack.length - 1];
        if (top.id() == 1) {
            return;
        }
        else {
            table.ajax.url(RootFolderUrl + '/products/requests/getProductCategories/datatablesEncode/' + category_view_model.currentParentCategoryStack.pop().parent());
            table.ajax.reload();
        }
    }
    else {
        table.ajax.url(RootFolderUrl + '/products/requests/getProductCategories/datatablesEncode/' + category_view_model.currentCategory().id());
        table.ajax.reload();
        console.log(category_view_model.currentParentCategoryStack.push(category_view_model.currentCategory()));
    }
}