<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 22/02/21
 * Time: 6:42 PM
 */
?>
<input id="orderId" type="text" hidden disabled value="<?php echo $data['orderId']; ?>"/>


<div style="margin-bottom: 8rem" class="container-fluid">
    <div class="row justify-content-around">
        <div class="col-12">
            <div class="card " style="margin-top: 5rem">
                <div class="card-body">
                    <div style="width: 100%;">
                        <button style="margin: 0 auto; width:15rem; display:block" class="btn btn-bdesign-primary btn-lg" data-bind="click:function(){$('#orderDetailsModal').modal('show')}">
                            order details
                        </button>
                    </div>
                    <hr>
                    <div class="row align-content-between justify-content-center">
                        <div class="col-12">
                            <div class="process-timeline" data-bind="foreach: $root.order.processes">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="single-process btn " data-bind="text:$data.title,css:{'btn-success':$data.status() ,'btn-off':!$data.status()},click:function(){$data.status(!$data.status())}"></div>
                                            </div>

                                            <div class="col-12" data-bind="if:$root.order.processes().length != ($index() + 1)">
                                                <div class="fa fa-arrow-down"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <hr>
                <div style="width: 100%;">
                    <button style="margin: 0 auto 2rem auto; width:15rem; display:block" class="btn btn-outline-success" data-bind="click:$root.submitOrderProcessesChanges">
                        Save
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


<!--order Details Modal-->
<div id="orderDetailsModal" class="modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="orderDetailsModal">Details</h5>
                <button type="button" class="close" data-bs-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <label for="orderNumber">Order Number : </label>
                        <input type="text" data-bind="value : $root.order.orderNumber" disabled>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <label for="orderProductType">Product Type : </label>
                        <input type="text" data-bind="value : $root.order.productType" disabled>
                    </div>
                    <div class="col-6">
                        <label for="orderCustomer">Customer : </label>
                        <input type="text" data-bind="value : $root.order.customer" disabled>
                    </div>
                </div>
                <hr>

                <div class="row justify-content-around">
                    <div class="col-12">
                        <div class="row" data-bind="foreach : $root.order.fields">
                            <!--                            <pre data-bind="text:ko.toJSON($data,null,2)"></pre>-->
                            <div class="col-12">
                                <div class="row">
                                    <!-- ko if: $data.fieldDataTypeId == "4" -->
                                    <div class="col-12">
                                        <label for="$index()" data-bind="text:$data.fieldTitle + ' : '"></label>
                                        <div class="" data-bind="attr:{'id':$index()}">
                                            <a target="_blank" data-bind="attr:{'href': $data.fieldValue},text:$data.fieldValue"></a>
                                        </div>
                                    </div>
                                    <!--/ko -->
                                    <!-- ko if: $data.fieldDataType != 'file'-->
                                    <div class="col-12">
                                        <label for="$index()" data-bind="text:$data.fieldTitle + ' : '"></label>
                                        <input class="form-control" data-bind="attr:{'id':$index(),'type':'text'},value:$data.fieldValue" disabled>

                                    </div>
                                    <!--/ko -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>