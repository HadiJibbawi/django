<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:51 AM
 */

class Product
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

// get all products
    public function getAllProducts()
    {
        $this->db->query('SELECT p.id,p.title,p.code,p.description,p.category AS categoryId,pc.title AS categoryTitle FROM `products` p LEFT JOIN product_categories pc ON p.category = pc.id;');

        $products = $this->db->resultSet();

//        foreach ($products as $product) {
////            $product->dateCreated = date('d/m/Y',strtotime($product->dateCreated));
//            $this->db->query('SELECT url FROM product_images WHERE type =1 AND product_id = :product_id');
//            $this->db->bind(':product_id', $product->id);
//            $this->db->resultSet();
//            $thumbnailCount = $this->db->rowCount();
//            if ($thumbnailCount > 0) {
//                $this->db->query('SELECT url FROM product_images WHERE type =1 AND product_id = :product_id LIMIT 1');
//                $this->db->bind(':product_id', $product->id);
//                $result = $this->db->single();
//                $product->imageUrl = $result->url;
//            }
//            else {
//                $this->db->query('SELECT url FROM product_images WHERE product_id = :product_id');
//                $this->db->bind(':product_id', $product->id);
//                $this->db->resultSet();
//                $productImageCount = $this->db->rowCount();
//                if ($productImageCount > 0) {
//                    $this->db->query('SELECT url FROM product_images WHERE type =0 AND product_id = :product_id LIMIT 1');
//                    $this->db->bind(':product_id', $product->id);
//                    $result = $this->db->single();
//                    $product->imageUrl = $result->url;
//                }
//                else {
//                    $product->imageUrl = APPLOGONAME;
//                }
//            }
//        }

        return $products;
    }

    public function getAllProductCategories()
    {
        $this->db->query('SELECT id,title,description,parent,tier FROM product_categories ');
        $categories = $this->db->resultSet();
        return $categories;
    }

    public function getProductCategories($parentId = 1)
    {
        $this->db->query('SELECT id,title,description,parent,tier FROM product_categories WHERE parent = :parentId');
        $this->db->bind(':parentId', $parentId);
        $categories = $this->db->resultSet();
        return $categories;
    }

    public function getProductCategory($categoryId)
    {
        $this->db->query('SELECT id,title,description,parent,tier FROM product_categories WHERE id = :id');
        $this->db->bind(':id', $categoryId);
        return $this->db->single();
    }

    public function getProductPrice($productId)
    {
        $this->db->query('SELECT price,currency_id AS currencyId FROM product_prices WHERE product_id = :productId');
        $this->db->bind(':productId', $productId);
        return $this->db->single();
    }


    public function getAllOptionTypes()
    {
        $this->db->query('SELECT id,type FROM product_option_types');
        $result = $this->db->resultSet();
        $productOptionTypes = [];
        foreach ($result as $row) {
            $productOptionTypes[$row->id] = $row->type;
        }
        return $productOptionTypes;
    }

    public function getProduct($id)
    {
        $this->db->query('SELECT id,title,code,category,description FROM products WHERE id = :id');
        $this->db->bind(':id', $id);
        $product = $this->db->single();
        $product->tags = $this->getProductTags($id);
        return $product;
    }

    public function getProductTags($productId)
    {
        $this->db->query('SELECT pt.id,pt.tag_id AS tagId, t.name AS tagName, t.description AS tagDescription FROM product_tags pt LEFT JOIN tags t ON pt.tag_id = t.id WHERE pt.product_id');
        $this->db->bind(':productId', $productId);
        $productTags = $this->db->resultSet();
        return $productTags;
    }

    public function addProduct($product)
    {
        $table = 'products';
        $columns = $product;
        $this->db->insertIntoTable($table, $columns);
        return $this->db->getLastInsertedId();
    }

    public function addProductPrice($productId, $productPrice)
    {
        $this->db->query('INSERT INTO product_prices (product_id, currency_id, price) VALUES (:productId,:currencyId,:price)');
        $this->db->bind(':productId', $productId);
        $this->db->bind(':price', $productPrice);
        $this->db->bind(':currencyId', 1);
        return $this->db->execute();
    }

    public function updateProductPrice($productId, $productPrice)
    {
        $this->db->query('update product_prices set price = :price where product_id = :productId');
        $this->db->bind(':productId', $productId);
        $this->db->bind(':price', $productPrice);
        return $this->db->execute();
    }

    public function addCategory($category)
    {
        $table = 'product_categories';
        $columns = $category;
        return $this->db->insertIntoTable($table, $columns);
    }

    public function updateProduct($product)
    {

        $table = 'products';
        $columns = $product;
        $primaryKeyName = 'id';
        $primaryKeyValue = $product['id'];

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }


    public function getProductFields($productId)
    {
        $this->db->query('SELECT pf.id,f.title,f.description,pf.field_id AS fieldId,fdt.type AS fieldDataType,fdt.id AS fieldDataTypeId,ft.id AS fieldTypeId,ft.type AS fieldType FROM `product_fields` pf LEFT JOIN `fields` f ON pf.field_id = f.id LEFT JOIN `field_types` ft ON f.field_type_id = ft.id LEFT JOIN `field_data_types` fdt ON f.data_type_id = fdt.id WHERE pf.product_id = :productId');
        $this->db->bind(':productId', $productId);
        $productFields = $this->db->resultSet();
        return $productFields;
    }

    public function deleteCategory($id)
    {
        $this->db->query('DELETE FROM `product_categories` WHERE id = :id');
        $this->db->bind(':id', $id);
        return $this->db->execute();
        //todo delete the rest
    }

    public function addProductField($field)
    {
        $productId = $field['productId'];
        $title = $field['title'];
        $description = $field['description'];
        $dataTypeId = $field['dataTypeId'];
        $typeId = $field['typeId'];
        $this->db->query('INSERT INTO `fields` (title, description,data_type_id,field_type_id) VALUES (:title,:description,:dataTypeId,:typeId)');
        $this->db->bind(':title', $title);
        $this->db->bind(':description', $description);
        $this->db->bind(':dataTypeId', $dataTypeId);
        $this->db->bind(':typeId', $typeId);

        $this->db->execute();
        $fieldId = $this->db->getLastInsertedId();

        $this->db->query('INSERT INTO `product_fields` (product_id, field_id) VALUES (:productId,:fieldId)');
        $this->db->bind(':productId', $productId);
        $this->db->bind(':fieldId', $fieldId);
        // Execute
        if ($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    }

    public function updateProductField($field)
    {

        //cleaning to make fields same name as column names in database
        if (isset($field['fieldDataTypeId'])) {
            $field['data_type_id'] = $field['fieldDataTypeId'];
            unset($field['fieldDataTypeId']);
        }
        if (isset($field['fieldTypeId'])) {
            $field['field_type_id'] = $field['fieldTypeId'];
            unset($field['fieldTypeId']);
        }

        $table = 'fields';
        $columns = $field;
        $primaryKeyName = 'id';
        $primaryKeyValue = $field['id'];

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function getFieldsDataTypes()
    {
        $query = 'SELECT id,type FROM `field_data_types`';
        $this->db->query($query);
        return $this->db->resultSet();
    }

    public function getFieldsTypes()
    {
        $query = 'SELECT id,type FROM `field_types`';
        $this->db->query($query);
        return $this->db->resultSet();
    }

    public function getFieldValues($fieldId)
    {
        $query = 'SELECT `id`,`value` FROM `field_values` WHERE field_id = :fieldId';
        $this->db->query($query);
        $this->db->bind(':fieldId', $fieldId);
        return $this->db->resultSet();
    }

    public function saveFieldValues($fieldValues)
    {
        $fieldTypes = ['free' => 1, 'bound' => 2];
        $fieldId = $fieldValues['fieldId'];
        $values = $fieldValues['values'];
        foreach ($values as $value) {
            if (isset($value['_destroy'])) {
                if ($value['_destroy'] == 'true') {
                    if ($value['id'] == '0') {
                        continue;
                    }
                    else {
                        $this->db->query('DELETE FROM `field_values` WHERE `id` = :id ');
                        $this->db->bind(':id', $value['id']);
                        $this->db->execute();
                    }
                }
            }
            else {
                if ($value['id'] == '0') {
                    $fieldValue = $value['value'];
                    $this->db->query('INSERT INTO `field_values` (field_id,field_type, value) VALUES (:fieldId,:fieldType,:fieldValue);');
                    $this->db->bind(':fieldId', $fieldId);
                    $this->db->bind(':fieldType', $fieldTypes['bound']);
                    $this->db->bind(':fieldValue', $fieldValue);
                    $this->db->execute();
                }
            }
        }

        return 1;
    }

    public function deleteField($ids)
    {
        $fieldId = $ids['fieldId'];
        $productFieldId = $ids['productFieldId'];
        $this->db->query('DELETE FROM `fields` WHERE id = :fieldId');
        $this->db->bind(':fieldId', $fieldId);
        $this->db->execute();
        $this->db->query('DELETE FROM `product_type_fields` WHERE id = :productFieldId');
        $this->db->bind(':productFieldId', $productFieldId);
        return $this->db->execute();
    }

    /* reached here in the new code */

    public function addProductProcess($processType)
    {

        $title = $processType['title'];
        $description = $processType['description'];
        $sequence = $processType['sequence'];
        $productId = $processType['productId'];

        $this->db->query('SELECT max(sequence) AS maxSequence FROM `processes` WHERE product_id = :productId');
        $this->db->bind(':productId', $productId);
        $largestSequence = $this->db->single()->maxSequence;
        if (intval($sequence) <= 1) {
            $sequence = 1;
            $this->db->query('UPDATE `processes` SET `sequence`= (`sequence`+1) WHERE product_id = :productId AND `sequence` >= 1');
            $this->db->bind(':productId', $productId);
            $this->db->execute();
        }
        elseif (intval($sequence) > 1 && intval($sequence) <= $largestSequence) {
            $this->db->query('UPDATE `processes` SET `sequence`= (`sequence`+1) WHERE product_id = :productId AND `sequence` >= :sequence');
            $this->db->bind(':productId', $productId);
            $this->db->bind(':sequence', $sequence);
            $this->db->execute();
        }
        elseif (intval($sequence) > $largestSequence) {
            $sequence = $largestSequence + 1;
        }


        $this->db->query('INSERT INTO `processes` (product_id,title, description,sequence) VALUES (:productId,:title,:description,:sequence)');
        $this->db->bind(':title', $title);
        $this->db->bind(':description', $description);
        $this->db->bind(':sequence', $sequence);
        $this->db->bind(':productId', $productId);

        // Execute
        if ($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    }

    public function getProductOptions($product_id)
    {
        $this->db->query('SELECT po.id,po.name,po.product_option_type AS typeId,po.description,pot.type AS type FROM product_options po LEFT JOIN product_option_types pot ON po.product_option_type = pot.id WHERE po.product_id = :product_id');
        $this->db->bind(':product_id', $product_id);
        $productOptions = $this->db->resultSet();
        foreach ($productOptions as $po) {
            $this->db->query('SELECT id,value FROM product_option_values WHERE product_option_id = :product_option_id');
            $this->db->bind(':product_option_id', $po->id);
            $poValues = $this->db->resultSet();
            $po->values = $poValues;
        }
        return $productOptions;
    }

    public function getProductOptionTypes()
    {
        $this->db->query('SELECT id,type,date_created FROM product_option_types');
        $productOptionTypes = $this->db->resultSet();
        return $productOptionTypes;
    }

    public function getProductOptionValues($optionId)
    {
        $this->db->query('SELECT id,value FROM product_option_values WHERE product_option_id = :option_id');
        $this->db->bind(':option_id', $optionId);
        $optionValues = $this->db->resultSet();
        return $optionValues;
    }

    public function addOption($option, $optionType)
    {

        $name = $option['name'];
        $description = $option['description'];
        $optionValueType = $option['type'];
        if (isset($optionType)) {
            if ($optionType == 'generic') {
                $this->db->query('INSERT INTO generic_product_options( name,description, product_option_type) VALUES (:name,:description,:type);');
                $this->db->bind(':name', $name);
                $this->db->bind(':description', $description);
                $this->db->bind(':type', $optionValueType);
            }
            else {
                $productId = $option['productId'];
                $this->db->query('INSERT INTO product_options( name,description,product_id, product_option_type) VALUES (:sname,:description,:productID,:type);');
                $this->db->bind(':sname', $name);
                $this->db->bind(':productID', $productId);
                $this->db->bind(':description', $description);
                $this->db->bind(':type', $optionValueType);
            }
            return $this->db->execute();
        }
        else {
            return 'error : invalid option type';
        }
    }

    public function addImage($imageDetails)
    {

        $productId = $imageDetails['productId'];
        $name = $imageDetails['name'];
        $imageTypeId = $imageDetails['imageTypeId'];
//        if (isset($optionType)) {
        $this->db->query('INSERT INTO `product_images` (product_id, name, type) VALUES (:productId, :name, :type)');
        $this->db->bind(':name', $name);
        $this->db->bind(':productId', $productId);
        $this->db->bind(':type', $imageTypeId);
        $this->db->execute();
        return $this->db->getLastInsertedId();
//        }
//        else {
//            return 'error : invalid option type';
//        }
    }

    public function updateImageURL($id, $url)
    {

        $this->db->query('UPDATE product_images SET url = :url WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->bind(':url', $url);
        return $this->db->execute();
    }

    public function addOptionValue($option, $optionType)
    {
        $value = $option['value'];
        $optionId = $option['optionId'];
        if (isset($optionType)) {
            if ($optionType == 'generic') {
                $this->db->query('INSERT INTO generic_product_option_values ( product_option_id, value) VALUES (:optionId,:value)');
                $this->db->bind(':value', $value);
                $this->db->bind(':optionId', $optionId);
            }
            else {
                $this->db->query('INSERT INTO product_option_values (product_option_id, value) VALUES (:optionId,:value)');
                $this->db->bind(':value', $value);
                $this->db->bind(':optionId', $optionId);
            }
        }
        return $this->db->execute();
    }

    public function deleteOptionValue($id, $isGeneric)
    {
        if ($isGeneric == 'true') {
            $this->db->query('DELETE FROM generic_product_option_values WHERE id = :id');
            $this->db->bind(':id', $id);
        }
        else {
            $this->db->query('DELETE FROM product_option_values WHERE id = :id');
            $this->db->bind(':id', $id);
            //todo : delete where this is referenced also
        }
        return $this->db->execute();
    }

    public function getGenericProductOptions()
    {
        $this->db->query('SELECT o.id,o.name,t.type AS type,o.product_option_type AS type_id,o.description FROM generic_product_options o LEFT JOIN product_option_types t ON o.product_option_type = t.id');
        $genericProductOptions = $this->db->resultSet();
        foreach ($genericProductOptions as $gpo) {
            $this->db->query('SELECT id,value FROM generic_product_option_values WHERE product_option_id = :product_option_id');
            $this->db->bind(':product_option_id', $gpo->id);
            $gpoValues = $this->db->resultSet();
            $gpo->values = $gpoValues;
        }
        return $genericProductOptions;
    }

    public function getGenericProductOptionValues($optionId)
    {
        $this->db->query('SELECT id,value FROM generic_product_option_values WHERE product_option_id = :generic_option_id');
        $this->db->bind(':generic_option_id', $optionId);
        $optionValues = $this->db->resultSet();
        return $optionValues;
    }

    public function getProductItems($product_id)
    {
        $this->db->query('SELECT id,quantity FROM product_items WHERE product_id = :product_id');
        $this->db->bind(':product_id', $product_id);
        $productItems = $this->db->resultSet();
        foreach ($productItems as $item) {
            $this->db->query('SELECT pio.id,pio.product_option_id AS optionId,po.name AS optionName,po.product_option_type AS optionType,pio.value AS value_id, pov.value AS value FROM product_item_options pio LEFT JOIN product_option_values pov ON pio.value = pov.id LEFT JOIN product_options po ON pio.product_option_id = po.id WHERE product_item_id = :product_item_id');
            $this->db->bind(':product_item_id', $item->id);
            $itemOptions = $this->db->resultSet();
            $values = [];
            foreach ($itemOptions as $itemOption) {
                array_push($values, $itemOption->value);
            }
            $optionValues = implode(',', $values);
            $item->options = $itemOptions;
            $item->optionValues = $optionValues;
        }
        return $productItems;
    }


    public function updateProcessType($processType)
    {
        if (isset($processType['sequence'])) {
            $sequence = $processType['sequence'];
//            echo 'sequence : ' . $sequence;
            $productId = $processType['productId'];
            $processTypeId = $processType['id'];
            $this->db->query('SELECT max(sequence) AS maxSequence FROM `processes` WHERE product_id = :productId');
            $this->db->bind(':productId', $productId);
            $largestSequence = $this->db->single()->maxSequence;
            $this->db->query('SELECT `sequence` AS oldSequence FROM `processes` WHERE id = :processTypeId');
            $this->db->bind(':processTypeId', $processTypeId);
            $oldSequence = $this->db->single()->oldSequence;
//            echo 'largst sequence : ' . $largestSequence;
            if (intval($sequence) != intval($oldSequence)) {
                if (intval($sequence) <= 1) {
                    $sequence = 1;
                }
                elseif (intval($sequence) > $largestSequence) {
                    $sequence = $largestSequence;
                }
                if (intval($sequence) >= 1 && intval($sequence) <= intval($largestSequence)) {

                    if (intval($sequence) < intval($oldSequence)) {
                        $this->db->query('UPDATE `processes` SET `sequence`= (`sequence`+1) WHERE product_id = :productId AND `sequence` >= :sequence AND sequence < :oldSequence');
                    }
                    else {
                        $this->db->query('UPDATE `processes` SET `sequence`= (`sequence`-1) WHERE product_id = :productId AND `sequence` <= :sequence AND sequence > :oldSequence');
                    }
                    $this->db->bind(':productId', $productId);
                    $this->db->bind(':sequence', $sequence);
                    $this->db->bind(':oldSequence', $oldSequence);
                    $this->db->execute();
                }

                $processType['sequence'] = $sequence;
            }
            else {
                unset($processType['sequence']);
            }
        }
        unset($processType['productId']);
        $table = 'processes';
        $columns = $processType;
        $primaryKeyName = 'id';
        $primaryKeyValue = $processType['id'];

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function deleteProduct($id)
    {
        $this->db->query('DELETE FROM `products` WHERE id = :id');
        $this->db->bind(':id', $id);
        return $this->db->execute();
        //todo delete the rest
    }

    public function getProductProcesses($productId)
    {
        $this->db->query('SELECT `id`,`title`,`cost`,`description`,`sequence` FROM `processes` WHERE product_id = :productId');
        $this->db->bind(':productId', $productId);
        $productProcesses = $this->db->resultSet();
        return $productProcesses;
    }


    public function addProductItem($item)
    {
        $OptionTypeListId = 1;
        $OptionTypeTextId = 2;
        $OptionTypeColorId = 3;
        $productId = $item['productId'];
        $quantity = $item['quantity'];
        $this->db->query('INSERT INTO product_items (product_id, quantity) VALUES (:productId,:quantity);');
        $this->db->bind(':productId', $productId);
        $this->db->bind(':quantity', $quantity);
        $this->db->execute();
        $itemId = $this->db->getLastInsertedId();
        $options = $item['options'];
        foreach ($options as $option) {
            $optionId = $option['id'];
            if ($option['typeId'] == $OptionTypeTextId) {
                $optionValueText = $option['optionValueText'];
                $optionType = $option['optionType'];
                $this->addOptionValue(['optionId' => $optionId, 'value' => $optionValueText], $optionType);
                $valueId = $this->db->getLastInsertedId();
            }
            else {
                $valueId = $option['optionValueId'];
            }
            $this->db->query('INSERT INTO product_item_options (product_item_id, product_option_id, value) VALUES (:productItemId,:productOptionId,:value)');
            $this->db->bind(':productItemId', $itemId);
            $this->db->bind(':productOptionId', $optionId);
            $this->db->bind(':value', $valueId);
            $this->db->execute();
        }
        return 1;
    }

    public function deleteProductItem($item)
    {
//        return $item;
////        die();
        $OptionTypeListId = 1;
        $OptionTypeTextId = 2;
        $OptionTypeColorId = 3;
        $itemOptions = $item['options'];
        foreach ($itemOptions as $option) {
            $optionId = $option['id'];
            if ($option['typeId'] == $OptionTypeTextId) {
                $optionValueId = $option['optionValueId'];
                $isGeneric = $option['isGeneric'];
                $this->deleteOptionValue($optionValueId, $isGeneric);
            }
        }
        $productItemId = $item['id'];
        $this->db->query('DELETE FROM product_item_options WHERE product_item_id = :productItemId');
        $this->db->bind(':productItemId', $productItemId);
        $this->db->execute();
        $this->db->query('DELETE FROM product_items WHERE id = :productItemId');
        $this->db->bind(':productItemId', $productItemId);
        return $this->db->execute();
    }

    public function submitOptionEdit($option, $isGeneric)
    {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
        $productOptionType = $_POST['typeId'];
        if ($isGeneric == 'true') {
            $this->db->query('UPDATE generic_product_options SET name = :name,product_option_type = :productOptionType,description = :description WHERE id = :id');
            $this->db->bind(':id', $id);
            $this->db->bind(':name', $name);
            $this->db->bind(':description', $description);
            $this->db->bind(':productOptionType', $productOptionType);
        }
        else {
            $this->db->query('UPDATE product_options SET name = :name,product_option_type = :productOptionType,description = :description WHERE id = :id');
            $this->db->bind(':id', $id);
            $this->db->bind(':name', $name);
            $this->db->bind(':description', $description);
            $this->db->bind(':productOptionType', $productOptionType);
        }
        return $this->db->execute();
    }

    public function saveItemOptionChanges($item)
    {
        $optionTypeListId = 1;
        $optionTypeTextId = 2;
        $optionTypeColorId = 3;

        $itemId = $item['id'];
        $quantity = $item['quantity'];
        $options = $item['options'];
        $this->db->query('UPDATE `product_items` SET quantity = :quantity WHERE id = :itemId');
        $this->db->bind(':itemId', $itemId);
        $this->db->bind(':quantity', $quantity);
        $this->db->execute();

        foreach ($options as $option) {
            $optionId = $option['id'];
            $optionTypeId = $option['typeId'];
            if ($option['isGeneric'] == 'true') {
                $this->db->query('UPDATE `generic_product_option_values` SET value = :valueId WHERE id = :optionId');
                $this->db->bind(':optionId', $optionId);
                $this->db->bind(':itemId', $itemId);
                $this->db->bind(':valueId', $valueId);
            }
            else {
                $this->db->query('SELECT * FROM product_item_options WHERE `product_item_id` = :itemId AND `product_option_id` = :optionId');
                $this->db->bind(':itemId', $itemId);
                $this->db->bind(':optionId', $optionId);
                $oldItemOption = $this->db->single();
                if ($this->db->rowCount() > 0) {
                    $update = true;
                }
                else {
                    $update = false;
                }

                if ($optionTypeId == $optionTypeTextId) {
                    $valueText = $option['selectedValueText'];
                    $this->db->query('INSERT INTO product_option_values ( product_option_id, value) VALUES (:optionId,:valueText)');
                    $this->db->bind(':valueText', $valueText);
                    $this->db->bind(':optionId', $optionId);
                    $this->db->execute();
                    $newValueId = $this->db->getLastInsertedId();
                    if ($update) {
                        $this->db->query('DELETE FROM product_option_values WHERE id = :oldValue');
                        $this->db->bind(':oldValue', $oldItemOption->value);
                        $this->db->execute();

                        $this->db->query('UPDATE `product_item_options` SET `value` = :valueId WHERE `product_item_id` = :itemId AND `product_option_id` = :optionId');
                        $this->db->bind(':itemId', $itemId);
                        $this->db->bind(':optionId', $optionId);
                        $this->db->bind(':valueId', $newValueId);
                    }
                    else {
                        $this->db->query('INSERT INTO product_item_options (product_item_id, product_option_id, value) VALUES (:itemId,:optionId,:valueId)');
                        $this->db->bind(':itemId', $itemId);
                        $this->db->bind(':optionId', $optionId);
                        $this->db->bind(':valueId', $newValueId);
                    }
                }
                else {
                    $valueId = $option['selectedValueId'];

                    if ($update) {
                        $this->db->query('UPDATE `product_item_options` SET `value` = :valueId WHERE `product_item_id` = :itemId AND `product_option_id` = :optionId');
                        $this->db->bind(':itemId', $itemId);
                        $this->db->bind(':optionId', $optionId);
                        $this->db->bind(':valueId', $valueId);
                    }
                    else {
                        $this->db->query('INSERT INTO product_item_options (product_item_id, product_option_id, value) VALUES (:itemId,:optionId,:valueId)');
                        $this->db->bind(':itemId', $itemId);
                        $this->db->bind(':optionId', $optionId);
                        $this->db->bind(':valueId', $valueId);
                    }
                }
            }
            $this->db->execute();
        }
        return 1;
    }
//    public function deleteProduct($id)
//    {
//        $this->db->query('DELETE FROM products WHERE id = :id');
//        $this->db->bind(':id', $id);
//        return $this->db->execute();

//    }

    public function deleteProcess($id)
    {
        $processTypeId = $id['processTypeId'];
        $this->db->query('DELETE FROM `processes` WHERE id = :processTypeId');
        $this->db->bind(':processTypeId', $processTypeId);
        return $this->db->execute();
    }

    public function deleteOption($id, $isGeneric)
    {
        if ($isGeneric == 'true') {
            $this->db->query('DELETE FROM generic_product_options WHERE id = :id');
            $this->db->bind(':id', $id);
        }
        else {
            $this->db->query('DELETE FROM product_options WHERE id = :id');
            $this->db->bind(':id', $id);
            //todo : delete where this is referenced also
        }
        return $this->db->execute();
    }

}