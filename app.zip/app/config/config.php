<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 03/04/20
 * Time: 10:40 AM
 */
// DB Params
//define('DB_HOST','jaafar');
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','baydoun');
define('CHARSET','utf8');

//App Root
define('APPROOT', dirname(dirname(__FILE__)));
//File Root
define('FILEROOT', 'C:\\xampp\\htdocs\\baydoun\\public\\');
//URL Root
define('URLROOT','http://jaafar:8888/baydoun');
//define('URLROOT','http://localhost:8888/bdesign');
//define('URLROOT','http://192.168.1.102:8888/violet');
//App Logo URL
//define('APPLOGOURL','http://192.168.1.102:8888/violet/img/violet_logo.jpg');
define('APPLOGOURL','http://jaafar:8888/baydoun/img/baydoun.jpg');
//define('APPLOGOURL','http://localhost:8888/bdesign/img/bdesign.jpg');
//img Root Folder URL
//define('IMGROOTURL','http://192.168.1.102:8888/violet/img');
define('IMGROOTURL','http://jaafar:8888/baydoun/public/img');
//define('IMGROOTURL','http://localhost:8888/bdesign/public/img');
//App Logo Name
define('APPLOGONAME','baydoun.jpg');
//Site Name // this should be the site not framework
define('SITENAME','Baydoun Design');
//App Version
define('APPVERSION','1.0.0');
