<div class="container">
    <div class="row">
        <?php echo flash('login_success'); ?>
    </div>
</div>
<div class="jumbotron jumbotron-fluid text-center">
    <div class="container">
        <h1 class="display-3"><?php echo $data['title'] ?></h1>
        <p class="lead"><?php echo $data['description'] ?></p>
    </div>
</div>
<!--<div class="container">-->
<!--    <div class="row">-->
<!--        <div class="col-1"></div>-->
<!--        <div class="col-3">-->
<!--            <div class="card" style="width: 18rem;">-->
<!--                <img src="--><?php //echo URLROOT ?><!--/public/img/car.png" class="card-img-top" alt="car clipart" height="200rem" width="300rem">-->
<!--                <div class="card-body">-->
<!--                    <h5 class="card-title">User Car Registration</h5>-->
<!--                    <p class="card-text">Please register your car</p>-->
<!--                    <a href="--><?php //echo URLROOT ?><!--/users/register" class="btn btn-primary">Register</a>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-3"></div>-->
<!--        <div class="col-3">-->
<!--            <div class="card" style="width: 18rem;">-->
<!--                <img src="--><?php //echo URLROOT ?><!--/public/img/chart.png" class="card-img-top" alt="car clipart" height="200rem" width="300rem">-->
<!--                <div class="card-body">-->
<!--                    <h5 class="card-title">Admin panel</h5>-->
<!--                    <p class="card-text">Please Login</p>-->
<!--                    <a href="--><?php //echo URLROOT ?><!--/users/login" class="btn btn-primary">Login</a>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-2"></div>-->
<!--    </div>-->
<!--</div>-->
<?php require APPROOT . '/views/inc/footer.php'; ?>

