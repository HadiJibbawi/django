const fieldDataTypeIds = {
    'text': 1,
    'number': 2,
    'date': 3,
    'file': 4

};
const fieldTypeIds = {
    'free': 1,
    'bound': 2
};
const productTypes = {
    'standard': 1,
    'custom': 2
};
const currencies = {
    'LBP': 1,
    'USD': 2
};
$("#addCustomer").attr("href", RootFolderUrl + '/customers/customers');

const order_view_model = new OrderViewModel();

function OrderViewModel() {
    const self = this;

    self.newCustomerName = ko.observable();
    self.newCustomerPhoneNumber = ko.observable('');
    self.newCustomerSecondaryPhoneNumber = ko.observable('');
    self.newCustomerEmailAddress = ko.observable('');
    self.newCustomerDeliveryAddress = ko.observable('');

    self.currentItemProduct = ko.observable(new Item());
    self.currentOrderItem = ko.observable(new Item());

    self.items = ko.observableArray([]);
    self.totalPrice = ko.computed(function () {
        let total = 0;
        $.each(self.items(), function (index, item) {
            if (item._destroy != true) {
                total += (parseInt(item.price()) * parseInt(item.quantity()));
            }
        });
        return numberWithCommas(total);
    });
    self.products = ko.observableArray([]);
    self.customers = ko.observableArray([]);
    self.currentProduct = ko.observable();
    self.order = new Order({'id': '0', 'customer': {}});
    self.currentProductFields = ko.observableArray();
    self.netPrice = ko.computed(function () {
        let total = 0;
        $.each(self.items(), function (index, item) {
            if (item._destroy != true) {
                total += (parseInt(item.price()) * parseInt(item.quantity()));
            }
        });
        let net = parseInt(total - parseInt(self.order.discount()));
        if (net < 0 || isNaN(net) || self.order.discount() < 0) {
            self.order.discount(0);
            if(net < 0 ){
                self.order.discount(total);
            }
            net = parseInt(total) - parseInt(self.order.discount());
        }
        return numberWithCommas(net);
    });

    self.setSaleItem = function (item) {
        self.currentOrderItem(item);
        $('#editItemModal').modal('show');
    };

    self.clearNewOrder = function () {
        let currentProduct = self.currentProduct();
        self.currentProduct(undefined);
        self.currentProduct(currentProduct);
        self.order.customer(undefined);
    };

    self.clearNewCustomerModal = function () {
        self.newCustomerName(undefined);
        self.newCustomerPhoneNumber('');
        self.newCustomerSecondaryPhoneNumber('');
        self.newCustomerEmailAddress('');
        self.newCustomerDeliveryAddress('');
    };

    self.addCustomer = function () {
        let addCustomerForm = $('#addCustomerForm');

        if (!addCustomerForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addCustomerForm).click().remove();
        }
        else {
            let route = ['sales', 'requests', 'addCustomer'];
            let customer = {};
            customer.name = self.newCustomerName();
            customer.phoneNumber = self.newCustomerPhoneNumber();
            customer.secondaryPhoneNumber = self.newCustomerSecondaryPhoneNumber();
            customer.emailAddress = self.newCustomerEmailAddress();
            customer.deliveryAddress = self.newCustomerDeliveryAddress();
            postData(route, customer, function (result) {
                if (result == '1') {
                    toastr.success('Customer Added Successfully');
                    self.clearNewCustomerModal();
                    self.getAllCustomers();
                }
                else {
                    toastr.warning('Customer Addition Failed');
                }
            });

            $('#add_Customer_modal').modal('hide');

        }
    };

    self.submitNewOrder = function () {

        let newOrderForm = $('#newOrderForm');

        if (!newOrderForm [0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(newOrderForm).click().remove();
        }
        else {
            if (self.items().length == 0) {
                swal.fire('Empty Cart', 'Please add items before submitting', 'warning');
                return;
            }
            let route = ['sales', 'requests', 'addOrder'];
            let orderData = {};

            orderData.customerId = self.order.customer().id;
            orderData.dateDue = self.order.dateDue();
            orderData.datePlaced = self.order.datePlaced();
            orderData.discount = self.order.discount();
            postData(route, orderData, function (orderId) {
                $.each(self.items(), function (index, item) {
                    let itemData = {};
                    itemData.productId = item.productId();
                    itemData.productType = item.productType();
                    itemData.orderId = orderId;
                    itemData.quantity = item.quantity();
                    itemData.price = item.price();
                    itemData.priceCurrencyId = item.priceCurrencyId();
                    let itemRoute = ['sales', 'requests', 'addItem'];
                    postData(itemRoute, itemData, function (itemId) {
                        console.log(itemId);
                        let data = [];
                        console.log(ko.toJS(item));
                        $.each(item.fields(), function (index, field) {
                            let fieldValue = {};
                            let fieldId = field.fieldId;
                            fieldValue['fieldId'] = fieldId;
                            if (field.fieldDataTypeId == fieldDataTypeIds['text'] || field.fieldDataTypeId == fieldDataTypeIds['number']) {
                                if (field.fieldTypeId == fieldTypeIds['bound']) {
                                    fieldValue['fieldValue'] = field.valueId();
                                    fieldValue['fieldType'] = field.fieldTypeId;
                                    data.push(fieldValue);
                                }
                                else {
                                    fieldValue['fieldValue'] = field.valueValue();
                                    fieldValue['fieldType'] = field.fieldTypeId;
                                    data.push(fieldValue);
                                }
                            }
                            else if (field.fieldDataTypeId == fieldDataTypeIds['date']) {
                                fieldValue['fieldValue'] = field.valueValue();
                                fieldValue['fieldType'] = field.fieldTypeId;
                                data.push(fieldValue);
                            }
                            else {
                                let fileInput = document.querySelector('#productField' + field.id);
                                //get current file from list of files
                                // const currentFile = fileInput.files[0];
                                const currentFile = field.file();
                                if (currentFile != null && currentFile != undefined) {
                                    //this event fires one the image has been loaded
                                    uploadFile(currentFile, RootFolderUrl + '/sales/requests/uploadFile', fieldTypeIds['free'], fieldId, itemId, function (result) {
                                        fieldValue['fieldValue'] = result;
                                        fieldValue['fieldType'] = fieldTypeIds['bound'];
                                        let itemFields = {};
                                        let newData = [];
                                        newData.push(fieldValue);
                                        itemFields['itemFieldValues'] = newData;
                                        itemFields['itemId'] = itemId;
                                        let route = ['sales', 'requests', 'submitOrder'];
                                        postData(route, itemFields, function (result) {
                                            // console.log(result);
                                        });
                                    });
                                }
                            }

                        });
                        // console.log(data);
                        let itemFields = {};
                        itemFields['itemId'] = itemId;
                        itemFields['itemFieldValues'] = data;
                        let route = ['sales', 'requests', 'submitOrder'];
                        postData(route, itemFields, function (result) {
                            Swal.fire({
                                title: 'Order successful',
                                text: 'Order ID: ' + orderId,
                                icon: 'success',
                                confirmButtonText: 'New Order'
                            }).then((result) => {
                                if (result.isConfirmed || !result.isConfirmed) {
                                    window.location.reload(true);
                                }
                            })
                        });
                    });
                });
            });
        }
    };

    self.addItem = function () {
        let newItemForm = $('#newItemForm');

        if (!newItemForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(newItemForm).click().remove();
        }
        else {
            // console.log(ko.toJS(self.currentItemProduct()));'
            $.each(self.currentItemProduct().fields(), function (index, field) {
                if (field.fieldDataTypeId == fieldDataTypeIds['file']) {
                    let fileInput = document.querySelector('#productField' + field.id);
                    //get current file from list of files
                    field.file = ko.observable(fileInput.files[0]);

                }
            });
            self.items.push(self.currentItemProduct());
            $('#addItemModal').modal('hide');
        }


    };
    self.getProducts = function () {
        let route = ['sales', 'requests', 'getAllProducts'];
        fetchDataJson(route, {}, function (products) {
            self.products(products);
        });
    };
    self.getAllCustomers = function () {
        self.customers([]);
        let route = ['customers', 'requests', 'getAllCustomers'];
        fetchDataJson(route, {}, function (customers) {
            // self.customers(customers);
            // console.log(customers);
            $.each(customers, function (index, customer) {
                let newCustomer = {};
                newCustomer.id = customer.id;
                newCustomer.name = customer.customerTitle + '. ' + customer.firstName + ' ' + customer.lastName;
                self.customers.push(new Customer(newCustomer));
            });
        });
    };
    self.getAllCustomers();
    self.getProducts();
}

function Order(order) {

    const self = this;


    self.id = order.id;
    self.customer = ko.observable(order.customer);
    self.dateDue = ko.observable();
    self.datePlaced = ko.observable();
    self.discount = ko.observable(0);

    self.setDates = function () {
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        mm = mm > 9 ? mm : '0' + mm;
        dd = dd > 9 ? dd : '0' + dd;
        let yyyy = today.getFullYear();
        let placedDate = yyyy + '-' + mm + '-' + dd;
        // console.log(today.getDate() + 12);
        today.setDate(today.getDate() + 7);
        dd = today.getDate();
        mm = today.getMonth() + 1;
        mm = mm > 9 ? mm : '0' + mm;
        dd = dd > 9 ? dd : '0' + dd;
        yyyy = today.getFullYear();
        let dueDate = yyyy + '-' + mm + '-' + dd;
        self.dateDue(dueDate);
        self.datePlaced(placedDate);
    };
    self.setDates();
}

function Item(item) {
    const self = this;

    self.id = item == undefined ? ko.observable('') : ko.observable('');
    self.productId = item == undefined ? ko.observable('') : ko.observable(item.id);
    self.productType = item == undefined ? ko.observable('') : ko.observable(productTypes['standard']);
    self.title = item == undefined ? ko.observable('') : ko.observable(item.title);
    self.quantity = ko.observable(1);
    self.fields = ko.observableArray([]);
    self.price = ko.observable(0);
    self.priceCurrencyId = ko.observable(1);

    self.Uprice = ko.computed(function () {
        return numberWithCommas(self.price());
    });
    self.Bprice = ko.computed(function () {
        return numberWithCommas(parseInt(self.price()) * parseInt(self.quantity()));
    });

    self.getFields = function () {
        // console.log(currentProductId);
        let route = ['sales', 'requests', 'getProductFieldsWithValues', self.productId()];
        fetchDataJson(route, {}, function (fields) {
            self.fields([]);
            $.each(fields, function (index, field) {
                self.fields.push(new Field(field));
            });
            // self.order.fields(fields);
            // console.log(fields);
        });
    };
    self.getProductPrice = function () {
        let route = ['products', 'requests', 'getProductPrice'];
        fetchDataJson(route, {'productId': self.productId()}, function (price) {
            self.price(price.price);
            self.priceCurrencyId(price.currencyId);
        })
    };
    self.getProductPrice();
    self.getFields();
}

function Field(field) {

    const self = this;

    self.id = field.id;
    self.title = field.title;
    self.description = field.description;
    self.fieldDataType = field.fieldDataType;
    self.fieldDataTypeId = field.fieldDataTypeId;
    self.fieldId = field.fieldId;
    self.fieldType = field.fieldType;
    self.fieldTypeId = field.fieldTypeId;

    self.valueId = ko.observable(0);
    self.valueValue = ko.observable();

    self.boundFieldValues = ko.observableArray([]);
    self.changeFile = function(file){
        self.file(file);
    };
    $.each(field.productFieldValues, function (index, fieldValue) {
        self.boundFieldValues.push(fieldValue);
    });

}

// function FieldValue(fieldValue) {
//     const self = this;
//
//     self.id = fieldValue.id;
//     self.value= fieldValue.value;
//
// }

function Customer(customer) {

    const self = this;

    self.id = customer.id;
    self.name = customer.name;
}


const productsTableId = 'datatable_products';
const productsButtonFunc = '';
const productsContentName = 'Product';
const productsDomParams = 'lfrtip';
const productsDatatableAjaxRoute = '/products/requests/getAllProducts';
const productsColumns = [
    {'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']},
    {'data': ['code', 'false']},
    {'data': ['description', 'false']}];

configureDatatable(productsTableId, productsButtonFunc, {}, productsDomParams, productsContentName, productsDatatableAjaxRoute, productsColumns);


function IgnoreKeyboardScrolling(e) {
    if (!e) {
        e = window.event;
    }
    if (e.keyCode >= 37 && e.keyCode <= 40) // arrows
    {
        e.returnValue = false;
        e.cancel = true;
    }
}


function uploadFile(file, path, fieldTypeId, fieldId, itemId, callback) {
    let form = new FormData();
    form.append('file', file, file.name);
    form.append('fieldTypeId', fieldTypeId);
    form.append('itemId', itemId);
    form.append('fieldId', fieldId);

    $.ajax({
        url: path,
        data: form,
        type: 'POST',
        contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
        processData: false, // NEEDED, DON'T OMIT THIS
        success: function (result) {
            callback(result);
        }
    });
}

ko.applyBindings(order_view_model);

$(document).ready(function () {
    let table = $('#datatable_products').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_products tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_products tbody').on('click', 'tr', function () {
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        order_view_model.currentItemProduct(new Item(data));
        // console.log(order_view_model.currentItemProduct());

    });

    //this allows for a custom message in case the product enters an invalid password

});

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}