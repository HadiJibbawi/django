<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:40 AM
 */

class Operations extends Controller
{
    private $productModel;
    private $operationModel;
    private $userModel;

    public function __construct()
    {
        $this->productModel = $this->model('Product');
        $this->userModel = $this->model('User');
        $this->operationModel = $this->model('Operation');
    }

    //this function is here is the index root function
    public function index()
    {
        //todo: navigation page
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function reception()
    {

        $data = ['title' => 'Reception', 'description' => 'Page for new requests'];
        $template = [];
        $template['page_script'] = 'reception';
        $this->view('operations/reception', $data, $template);
    }

    public function orders()
    {

        $data = ['title' => 'Orders', 'description' => 'Page for viewing orders'];
        $template = [];
        $template['page_script'] = 'orders';
        $this->view('operations/orders', $data, $template);
    }

    public function customers()
    {
        $data = ['title' => 'Customers', 'description' => 'Page for Customer Management'];
        $template = [];
        $template['page_script'] = 'customers';
        $this->view('admin/customers', $data, $template);
    }

    public function workshop($orderId)
    {
        if (!isset($orderId)) {
            $this->orders();
        }
        else {
            $data = ['title' => 'Workshop', 'description' => 'Page for manging processes in workshop', 'orderId' => $orderId];
            $template = [];
            $template['page_script'] = 'workshop';
            $this->view('operations/workshop', $data, $template);
        }
    }

    private function getProductTypes()
    {
        $productTypes = $this->productModel->getAllProductTypes();
    }

    private function getOrderFieldsWithValues($orderId)
    {
        $orderValues = $this->operationModel->getOrderFieldsWithValues($orderId);
        return $orderValues;
    }

    private function getOrderProcesses($orderId)
    {
        $orderProcesses = $this->operationModel->getOrderProcesses($orderId);
        return $orderProcesses;
    }

    private function getProductTypeFields($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $fields = $this->productModel->getProductTypeFields($id);
        return $fields;

    }

    private function getProductTypeFieldsWithValues($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $fields = $this->operationModel->getProductTypeFieldsWithValues($id);
        return $fields;

    }

    public function addFile($file, $fieldTypeId = 1, $orderId, $fieldId)
    {

        /*
         * field types and their respective Ids
         * free : 1
         * bound : 2
         */
        if (isset($file["type"])) {
            $fileValidationResponse = $this->validateFile($file);
            if ($fileValidationResponse['response']) {
                //set the variables needed
                $orderFilesDirectory = FILEROOT . 'files\\orders\\';
                $directory = $orderFilesDirectory . $orderId;
                if (!file_exists($directory)) {
                    mkdir($directory);
                }
                $fileDirectory = $directory . '\\';
                $fileExtension = $fileValidationResponse['extension'];
                $fileDetails = [];
                $fileDetails['name'] = $file['name'];
                $fileDetails['fieldTypeId'] = $fieldTypeId;
                $fileDetails['orderId'] = $orderId;
                $fileDetails['fieldId'] = $fieldId;
                $newFileId = $this->operationModel->addFile($fileDetails);
                $newFileName = $newFileId . '.' . $fileExtension;
                $isUploaded = $this->uploadFile($file, $fileDirectory, $newFileName);
                if ($isUploaded) {
                    $fileUrl = URLROOT . '/public/files/orders/' . $orderId . '/' . $newFileId . '.' . $fileExtension;
                    $fileUrlChangeSuccess = $this->operationModel->updateFileURL($newFileId, $fileUrl);
                    if ($fileUrlChangeSuccess) {
                        return $newFileId;
                    }
                    else {
                        return 'Image URL Change Failed';
                    }
                }
                else {
                    return 'Upload Failed';
                }
            }
            else {
                return $fileValidationResponse['err_msg'];
            }
        }
        else {
            return '***Invalid Request***';
        }
    }

    private function validateFile($file)
    {
        $response = ['response' => '', 'err_msg' => 'none'];
        //$validextensions = array("jpeg", "jpg", "png");

        //this explodes the name by the . so that we get the extension of the file
        $temporary = explode(".", $file["name"]);
        $file_extension = end($temporary);
        $file_extension = strtolower($file_extension);
        //check for valid file types
        if (($file["size"] < 10000000)) {

            //check if image has any errors
            if ($file["error"] > 0) {
                $response['response'] = false;
                $response['err_msg'] = "Error Code: " . $file["error"];
            }

            //this means image is validated
            else {
                $response['response'] = true;
                $response['extension'] = $file_extension;
            }
        }
        else {
            $response['response'] = false;
            if ($file["error"] > 0) {
                $response['err_msg'] = "Error Code: " . $file["error"];
            }

            $response['response'] = '***Invalid file Size or Type***';
        }
        return $response;

    }

    public function uploadFile($file, $directory, $newName)
    {
        $filename = $newName;
        $sourcePath = $file['tmp_name']; // Storing source path of the file in a variable
//        $sourcePath = str_replace('\\','/',$sourcePath);
        $targetPath = $directory . $filename; // Target path where file is to be stored
        $uploadSuccess = move_uploaded_file($sourcePath, $targetPath);
        if ($uploadSuccess) {
            return true;
        } // Moving Uploaded file
        else {
            return false;
        }
    }

    private function addOrder($orderDetails)
    {
        $productTypeId = $orderDetails['productTypeId'];
        $orderNumber = $orderDetails['orderNumber'];
        $customerId = $orderDetails['customerId'];
        $dateDue = $orderDetails['dateDue'];
        $datePlaced = $orderDetails['datePlaced'];

        return $this->operationModel->addOrder($productTypeId,$orderNumber, $customerId, $dateDue, $datePlaced);
    }

    private function addCustomer($customer)
    {

        return $this->operationModel->addCustomer($customer);
    }

    private function updateCustomer($customer)
    {
        foreach ($customer as $key => $item){
            $newKey = $this->camelCaseToUnderscore($key);
            if ($newKey == $key) {
                continue;
            }
            $customer[$newKey] = $item;
            unset($customer[$key]);
        }
//        print_r($customer);
        echo $this->operationModel->updateCustomer($customer);
    }

    private function deleteCustomer($id){
        return $this->operationModel->deleteCustomer($id['id']);
    }

    private function submitOrder($data)
    {
        $fieldDataTypeIds = [
            'text' => 1,
            'number' => 2,
            'date' => 3,
            'file' => 4];

        $fieldTypeIds = [
            'free' => 1,
            'bound' => 2

        ];
        $orderFieldValues = $data['orderFieldValues'];
        $orderId = $data['orderId'];
        foreach ($orderFieldValues as $orderFieldValue) {
            $fieldId = $orderFieldValue['fieldId'];
            $fieldValue = $orderFieldValue['fieldValue'];
            $fieldType = $orderFieldValue['fieldType'];
            if ($fieldType == $fieldTypeIds['free']) {
                $fieldValueId = $this->operationModel->addFieldValue($fieldId, $fieldType, $fieldValue);
            }
            else {
                $fieldValueId = $fieldValue;
            }
            $this->operationModel->addOrderValue($orderId, $fieldValueId);
        }
        return 1;
    }

    private function submitOrderProcessesChanges($data)
    {
        return $this->operationModel->submitOrderProcessesChanges($data);
    }

    public function testapi($test_type)
    {

        //echo $this->encode_json(func_get_args());
        // this would get me the whole parameter array passed to this
        // function, (although php doesn't mind more parameters than needed
//        $num = $number * 2;
//        $return_val = ['number' => $num];
//        echo $this->encode_json($return_val);
//        echo 'pages';
        echo $test_type;
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            echo print_r($_POST['data']);
        }
    }

    public function requests($request)
    {
        switch ($request) {
            case 'getProductTypes':
                echo $this->encode_json($this->productModel->getAllProductTypes());
                break;
            case 'getAllCustomers':
                if (isset(func_get_args()[1])) {

                    if (func_get_args()[1] == 'datatablesEncode') {
                        echo $this->datatables_encode($this->operationModel->getAllCustomers());
                    }
                    else {
                        echo $this->encode_json($this->operationModel->getAllCustomers());
                    }
                }
                else {
                    echo $this->encode_json($this->operationModel->getAllCustomers());
                }
                break;
            case 'getOrders':
                echo $this->datatables_encode($this->operationModel->getOrders());
                break;
            case 'getProductTypeFields':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json($this->getProductTypeFields($id));
                    break;
                }
            case 'getProductTypeFieldsWithValues':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json($this->getProductTypeFieldsWithValues($id));
                    break;
                }
            case 'getOrderFieldsWithValues':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $orderId = func_get_args()[1];
                    echo $this->encode_json($this->getOrderFieldsWithValues($orderId));
                    break;
                }
            case 'getOrderProcesses':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $orderId = func_get_args()[1];
                    echo $this->encode_json($this->getOrderProcesses($orderId));
                    break;
                }
            case 'uploadFile':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    if ($_POST['fieldTypeId']) {
                        $fieldTypeId = $_POST['fieldTypeId'];
                    }
                    else {
                        //set as product image
                        $fieldTypeId = 2;
                    }
                    $orderId = $_POST['orderId'];
                    $fieldId = $_POST['fieldId'];
                    echo $this->addFile($_FILES['file'], $fieldTypeId, $orderId, $fieldId);
                }
                break;
            case 'addOrder':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $orderId = $this->addOrder($_POST);
                    echo $orderId;
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addCustomer':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addCustomer($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'updateCustomer':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateCustomer($_POST);
                }
                else {
                    $this->customers();
                }
                break;
            case 'deleteCustomer':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->deleteCustomer($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'submitOrder':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->submitOrder($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'submitOrderProcessesChanges':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->submitOrderProcessesChanges($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>