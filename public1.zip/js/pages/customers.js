//id
//name
//phone_number
//secondary_phone_number
//email_address
//delivery_address
//date_created
let customer_view_model;
customer_view_model = new CustomerViewModel();

function CustomerViewModel() {
    const self = this;

    self.currentRow = ko.observable();
    self.currentCustomer = ko.observable({'firstName': ''});

    self.newCustomer = ko.observable(new Customer());

    self.customers = ko.observableArray([]);
    self.customerTitles = ko.observableArray([]);
    self.customerGroups = ko.observableArray([]);
    self.customerCompanies = ko.observableArray([]);
    self.customerPhoneNumberTypes = ko.observableArray([]);
    self.customerEmailAddressTypes = ko.observableArray([]);
    self.phoneNumberCountryCodes = ko.observableArray([]);


    self.showCustomerPhoneNumbersModal = function () {
        $('#customerPhoneNumbersModal').modal('show');
    };
    self.addCustomerEmailAddressType = function () {
        let newType = prompt('please enter new email address type');
        let route = ['customers', 'requests', 'addEmailAddressType'];
        postData(route,{data:newType},function (response) {
            if (response == '1') {
                toastr.success('type added');
                self.getCustomerEmailAddressTypes();
            }
        })
    };
    self.addCustomerPhoneNumberType = function () {
        let newType = prompt('please enter new phone number type');
        let route = ['customers', 'requests', 'addPhoneNumberType'];
        postData(route,{data:newType},function (response) {
            if (response == '1') {
                toastr.success('type added');
                self.getCustomerPhoneNumberTypes();
            }
        })
    };
    self.hideCustomerPhoneNumbersModal = function () {
        $('#customerPhoneNumbersModal').modal('hide');
    };
    self.showCustomerEmailAddressesModal = function () {
        $('#customerEmailAddressesModal').modal('show');
    };
    self.hideCustomerEmailAddressesModal = function () {
        $('#customerEmailAddressesModal').modal('hide');
    };
    self.getPhoneNumberCountryCodes = function () {
        let route = ['customers', 'requests', 'getAllPhoneNumberCountryCodes'];
        fetchDataJson(route, {}, function (phoneNumberCountryCodes) {
            $.each(phoneNumberCountryCodes, function (index, code) {
                self.phoneNumberCountryCodes.push(new CountryCode(code));
            });
        });
    };
    self.getPhoneNumberCountryCodes();
    self.getCustomerPhoneNumberTypes = function () {
        let route = ['customers', 'requests', 'getCustomerPhoneNumberTypes'];
        fetchDataJson(route, {}, function (CustomerPhoneNumberTypes) {
            self.customerPhoneNumberTypes(CustomerPhoneNumberTypes);
        });
    };

    self.getCustomerPhoneNumberTypes();
    self.getCustomerEmailAddressTypes = function () {
        let route = ['customers', 'requests', 'getCustomerEmailAddressTypes'];
        fetchDataJson(route, {}, function (CustomerEmailAddressTypes) {
            self.customerEmailAddressTypes(CustomerEmailAddressTypes);
        });
    };
    self.getCustomerEmailAddressTypes();

    self.getCustomerTitles = function () {
        let route = ['customers', 'requests', 'getCustomerTitles'];
        fetchDataJson(route, {}, function (titles) {
            self.customerTitles(titles);
        });
    };
    self.getCustomerTitles();

    self.getCustomerGroups = function () {
        let route = ['customers', 'requests', 'getCustomerGroups'];
        fetchDataJson(route, {}, function (groups) {
            self.customerGroups(groups);
        });
    };
    self.getCustomerGroups();

    self.getCustomerCompanies = function () {
        let route = ['customers', 'requests', 'getCustomerCompanies'];
        fetchDataJson(route, {}, function (companies) {
            self.customerCompanies(companies);
        });
    };
    self.getCustomerCompanies();

    self.clearNewCustomerModal = function () {
        self.newCustomer({});
    };

    self.addCustomer = function () {
        let addCustomerForm = $('#addCustomerForm');

        if (!addCustomerForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addCustomerForm).click().remove();
        }
        else {
            let route = ['customers', 'requests', 'addCustomer'];
            let customer = {};
            customer.firstName = self.newCustomer().firstName();
            customer.middleName = self.newCustomer().middleName();
            customer.lastName = self.newCustomer().lastName();
            customer.customerTitle = self.newCustomer().customerTitle();
            customer.deliveryAddress = self.newCustomer().deliveryAddress();
            customer.customerGroup = self.newCustomer().customerGroup() == undefined ? 0 : self.newCustomer().customerGroup();
            customer.customerCompany = self.newCustomer().customerCompany() == undefined ? 0 : self.newCustomer().customerCompany();
            postData(route, customer, function (result) {
                if (result == '1') {
                    toastr.success('Customer Added Successfully');
                    self.clearNewCustomerModal();
                    $('#datatable_customers').DataTable().ajax.reload();

                }
                else {
                    toastr.warning('Customer Addition Failed');
                }
            });

            $('#add_Customer_modal').modal('hide');

        }
    };

    self.deleteCurrentCustomer = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentCustomer().displayName());
        if (confirmDelete) {
            let deleteRoute = ['customers', 'requests', 'deleteCustomer'];
            postData(deleteRoute, {'id': self.currentCustomer().id}, function (response) {
                if (response == '1') {
                    toastr.success('Customer Deleted');
                    $('#edit_Customer_modal').modal('hide');
                    self.currentCustomer({'firstName': ''});
                    $('#datatable_customers').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Customer Deletion Failed');
                }
            });
        }
    };

    self.resetCurrentCustomer = function () {
        let table = $('#datatable_customers').DataTable();
        let data = ko.toJS(table.row(self.currentRow()).data());
        customer_view_model.currentCustomer(new Customer(data));
    };

    self.submitEditCustomer = function () {

        let editCurrentCustomerForm = $('#editCurrentCustomerForm');

        if (!editCurrentCustomerForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentCustomerForm).click().remove();
        }
        else {
            let route = ['customers', 'requests', 'updateCustomer'];
            let table = $('#datatable_customers').DataTable();
            let customer = {};
            const originalCustomer = ko.toJS(table.row(self.currentRow()).data());
            const currentCustomer = ko.toJS(self.currentCustomer);
            console.log(originalCustomer);
            console.log(currentCustomer);

            for (const prop in originalCustomer) {
                if (prop != 'emailAddresses' && prop != 'phoneNumbers' && prop != 'customerGroupId' && prop != 'customerCompanyId' && prop != 'customerTitleId') {
                    if (originalCustomer[prop] != currentCustomer[prop]) {
                        customer[prop] = currentCustomer[prop];
                    }
                }
            }

            if ($.isEmptyObject(customer)) {
                alert('No changes have been made');
                return;
            }
            customer['id'] = originalCustomer.id;
            postData(route, customer, function (result) {
                if (result == '1') {
                    toastr.success('Customer Edited Successfully');
                    let table = $('#datatable_customers').DataTable();
                    table.ajax.reload();
                }
                else {
                    toastr.warning('Customer Edit Failed');
                }
            });
        }
    };


}

function Customer(customer) {

    const self = this;

    self.setCustomerPhoneNumbers = function () {
        let phoneNumbers = ko.observableArray([]);
        $.each(customer.phoneNumbers, function (index, phoneNumber) {
            phoneNumbers.push(new PhoneNumber(phoneNumber))
        });
        return phoneNumbers;
    };
    self.setCustomerEmailAddresses = function () {
        let emailAddresses = ko.observableArray([]);
        $.each(customer.emailAddresses, function (index, emailAddress) {
            emailAddresses.push(new EmailAddress(emailAddress))
        });
        return emailAddresses;
    };

    self.id = customer == undefined ? ko.observable('') : ko.observable(customer.id);
    self.firstName = customer == undefined ? ko.observable('') : ko.observable(customer.firstName);
    self.middleName = customer == undefined ? ko.observable('') : ko.observable(customer.middleName);
    self.lastName = customer == undefined ? ko.observable('') : ko.observable(customer.lastName);
    self.customerTitle = customer == undefined ? ko.observable('') : ko.observable(customer.customerTitleId);
    self.deliveryAddress = customer == undefined ? ko.observable('') : ko.observable(customer.deliveryAddress);
    self.customerGroup = customer == undefined ? ko.observable('') : ko.observable(customer.customerGroupId);
    self.customerCompany = customer == undefined ? ko.observable('') : ko.observable(customer.customerCompanyId);

    self.phoneNumbers = customer == undefined ? ko.observableArray() : self.setCustomerPhoneNumbers();
    self.emailAddresses = customer == undefined ? ko.observableArray() : self.setCustomerEmailAddresses();
    self.enableDelete = ko.observable(false);

    self.addPhoneNumber = function () {
        //122 is the id for lebanon
        self.phoneNumbers.push(new PhoneNumber({'id': '0', 'countryCode': 122}));
    };
    self.removePhoneNumber = function (phoneNumber) {
        let confirmDelete = confirm('are you sure you want to delete this phone number?');
        if (confirmDelete) {
            self.phoneNumbers.destroy(phoneNumber);
        }
    };
    self.addEmailAddress = function () {
        //122 is the id for lebanon
        self.emailAddresses.push(new EmailAddress({'id': '0'}));
    };
    self.removeEmailAddress = function (emailAddress) {
        let confirmDelete = confirm('are you sure you want to delete this email address?');
        if (confirmDelete) {
            self.emailAddresses.destroy(emailAddress);
        }
    };

    self.saveCustomerPhoneNumbers = function () {
        let savePhoneNumbersForm = $('#customerPhoneNumbersForm');

        if (!savePhoneNumbersForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(savePhoneNumbersForm).click().remove();
        }
        else {
            let route = ['customers', 'requests', 'submitCustomerPhoneNumbers'];
            let phoneNumbers = [];
            let table = $('#datatable_customers').DataTable();
            let currentPhoneNumbers = ko.toJS(self.phoneNumbers);
            $.each(currentPhoneNumbers, function (index, phoneNumber) {
                let tempPhoneNumber = {};
                if (phoneNumber.id != 0) {
                    const originalCustomer = ko.toJS(table.row(customer_view_model.currentRow()).data());
                    let originalPhoneNumber = ko.utils.arrayFirst(originalCustomer.phoneNumbers, function (originalNumber) {
                        return originalNumber.id == phoneNumber.id;
                    });
                    for (const prop in phoneNumber) {

                        if (originalPhoneNumber[prop] != phoneNumber[prop]) {
                            if (tempPhoneNumber.id == undefined) {
                                tempPhoneNumber.id = phoneNumber.id;
                            }
                            tempPhoneNumber[prop] = phoneNumber[prop];
                        }
                    }
                }
                else {
                    tempPhoneNumber = phoneNumber;
                }
                phoneNumbers.push(tempPhoneNumber);
            });

            postData(route, {'customerId': self.id(), 'data': phoneNumbers}, function (result) {
                if (result == '1') {
                    toastr.success('Phone Numbers saved Added Successfully');
                    $('#datatable_customers').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Phone Numbers save Failed');
                }
            });
        }
    };
    self.saveCustomerEmailAddresses = function () {
        let saveEmailAddressesForm = $('#customerEmailAddressesForm');

        if (!saveEmailAddressesForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(saveEmailAddressesForm).click().remove();
        }
        else {
            let route = ['customers', 'requests', 'submitCustomerEmailAddresses'];
            let emailAddresses = [];
            let table = $('#datatable_customers').DataTable();
            let currentEmailAddresses = ko.toJS(self.emailAddresses);
            $.each(currentEmailAddresses, function (index, emailAddress) {
                let tempEmailAddress = {};
                if (emailAddress.id != 0) {
                    const originalCustomer = ko.toJS(table.row(customer_view_model.currentRow()).data());
                    let originalEmailAddress = ko.utils.arrayFirst(originalCustomer.emailAddresses, function (originalAddress) {
                        return originalAddress.id == emailAddress.id;
                    });
                    for (const prop in emailAddress) {

                        if (originalEmailAddress[prop] != emailAddress[prop]) {
                            if (tempEmailAddress.id == undefined) {
                                tempEmailAddress.id = emailAddress.id;
                            }
                            tempEmailAddress[prop] = emailAddress[prop];
                        }
                    }
                }
                else {
                    tempEmailAddress = emailAddress;
                }
                emailAddresses.push(tempEmailAddress);
            });

            postData(route, {'customerId': self.id(), 'data': emailAddresses}, function (result) {
                if (result == '1') {
                    toastr.success('Email Addresses saved Added Successfully');
                    $('#datatable_customers').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Email Addresses save Failed');
                }
            });


        }
    };

    let viewmodel = customer_view_model == undefined ? {customerTitles: ko.observableArray()} : customer_view_model;
    self.displayName = ko.computed(function () {
        // console.log('computed');
        let title = viewmodel.customerTitles()[self.customerTitle()] == undefined ? '' : (ko.utils.arrayFirst(viewmodel.customerTitles(), function (title) {
            return title.id == self.customerTitle();
        })).title;
        return title + '. ' + self.firstName() + ' ' + self.middleName() + ' ' + self.lastName();

    });
}

function PhoneNumber(phoneNumber) {
    const self = this;

    self.id = ko.observable(phoneNumber.id);
    self.phoneNumberTypeId = ko.observable(phoneNumber.phoneNumberTypeId);
    self.countryCode = ko.observable(phoneNumber.countryCode);
    self.areaCode = ko.observable(phoneNumber.areaCode);
    self.subscriberNumber = ko.observable(phoneNumber.subscriberNumber);
    self.extension = ko.observable(phoneNumber.extension);
    self.notes = ko.observable(phoneNumber.notes);
}


function EmailAddress(emailAddress) {
    const self = this;

    self.id = ko.observable(emailAddress.id);
    self.emailAddressTypeId = ko.observable(emailAddress.emailAddressTypeId);
    self.emailAddress = ko.observable(emailAddress.emailAddress);
}


function CountryCode(countryCode) {
    const self = this;

    self.id = countryCode.id;
    self.country = countryCode.country;
    self.code = countryCode.code;

    self.displayName = ko.computed(function () {
        let country = '';
        //this is to make sure the select is not over wide
        if (self.country.length > 10) {
            country = self.country.substring(0, 11);
        }
        else {
            country = self.country;
        }
        return country + ' (' + self.code + ')';
    });
}

ko.applyBindings(customer_view_model);
const customersTableId = 'datatable_customers';
const customersButtonFunc = '$(\'#add_Customer_modal\').modal(\'show\');';
const customersDomParams = 'lfBrtip';
const customersContentName = 'Customer';
const customersDatatableAjaxRoute = '/customers/requests/getAllCustomers/datatablesEncode';
const customersColumns = [
    {'data': [null, '((row.customerTitle) + ". " + (row.firstName.charAt(0).toUpperCase() + row.firstName.slice(1))) + " " + ((row.middleName.charAt(0).toUpperCase() + row.middleName.slice(1))) + " " +((row.lastName.charAt(0).toUpperCase() + row.lastName.slice(1)))']},
    {'data': [null, '(row.phoneNumbers.length > 0 ? (row.phoneNumbers[0].countryCodeLiteral+ \'-\' + row.phoneNumbers[0].areaCode + \'-\' + row.phoneNumbers[0].subscriberNumber + \'/\' + row.phoneNumbers[0].extension):"")']},
    {'data': ['customerCompany', 'false']}
];

configureDatatable(customersTableId, customersButtonFunc,{}, customersDomParams, customersContentName, customersDatatableAjaxRoute, customersColumns);

$(document).ready(function () {
    let table = $('#datatable_customers').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_customers tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_customers tbody').on('click', 'tr', function () {
        customer_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        customer_view_model.currentCustomer(new Customer(data));
        $('#edit_Customer_modal').modal('show');
    });

    //this allows for a custom message in case the user enters an invalid password

});
