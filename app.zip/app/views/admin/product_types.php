<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 31/01/21
 * Time: 1:12 PM
 */
?>
<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-center">
        <div class="col-10">
            <div id="products_table_container" class="col-12">
                <?php
                $table_columns = ['Product Type', 'Description', "Details"];
                $table_properties = ["tableId" => "datatable_productTypes", "title" => 'Product Types', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>