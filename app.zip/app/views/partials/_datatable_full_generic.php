<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 29/04/20
 * Time: 2:29 PM
 */

if (!isset($table_properties['width'])) {
    $table_properties['width'] = 'col-12';
}
if (!isset($table_properties['bg-color'])) {
    $table_properties['bg-color'] = 'white';
}
if (!isset($table_properties['padding'])) {
    $table_properties['padding'] = '2rem;';
}
if (!isset($table_properties['margin'])) {
    $table_properties['margin'] = '0rem';
}
if (!isset($table_properties['border'])) {
    $table_properties['border'] = 'lightgrey';
}
if (!isset($table_properties['border-style'])) {
    $table_properties['border-style'] = 'solid';
}
if (!isset($table_properties['border-width'])) {
    $table_properties['border-width'] = '0.05rem';
}
if (!isset($table_properties['title-size'])) {
    $table_properties['title-size'] = 'h2';
}
if (!isset($table_columns)) {
    die('Invalid Table Parameters');
}
if (!isset($table_properties['tableId'])) {
    die('Invalid Table Id');
}

?>
<div class="row mt-5">
    <div class="card col-12 shadow">
        <div class="card-body datatables-custom-card">
            <<?php echo $table_properties['title-size'] ?> class="mb-3"><?php echo $table_properties['title'] ?></<?php echo $table_properties['title-size'] ?>>
        <div class="<?php echo $table_properties['width'] ?>" style="background-color: <?php echo $table_properties['bg-color'] ?>; padding: <?php echo $table_properties['padding'] ?>; margin: <?php echo $table_properties['margin'] ?>;border: <?php echo $table_properties['border'] ?>; border-style: <?php echo $table_properties['border-style'] ?>;; border-width: <?php echo $table_properties['border-width'] ?>;">
            <table id="<?php echo $table_properties['tableId'] ?>" class="display table table-striped table-responsive-sm table-responsive-md table-responsive-lg table-hover" style="width: 100%;">
                <thead>
                <tr>
                    <?php foreach ($table_columns as $table_column) {
                        echo '<th>' . $table_column . '</th>';
                    } ?>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>