const appRootFolderName = '/baydoun';
const RootFolderUrl = 'http://jaafar:8888/baydoun';
const appMaincurrency = ' L.L ';

//this hides footer on very small screens

function fetchDataJson(routeParams, gets = {}, callback) {
    let url = appRootFolderName;

    if (Array.isArray(routeParams)) {
        routeParams.forEach(param => url += '/' + param);
    }
    $.getJSON(url, gets, function (data) {
        if (data != '') {
            // if data is not empty
            // callback with JSON data
            callback(data);
        }
    });
}

function postData(routeParams, data, callback = function () {
}) {
    let url = appRootFolderName;

    if (Array.isArray(routeParams)) {
        routeParams.forEach(param => url += '/' + param);
    }
    // check if data is valid JSON

    try {
        JSON.stringify(data);
    } catch (e) {
        console.error('invalid JSON data');
    }

    // console.log(url);
    $.post(url, data, function (data, status) {
        // console.log("data : " + data);
        // console.log("status: " + status);
        callback(data);
    });
}

function configureDatatable(tableId, buttonFunc = '', customButton = {}, domParams = 'r', contentName, datatableAjaxRoute, columns, pageLength = 10, Sort) {
    let columnsArray = [];
    let dom;
    let buttons;
    let sorting;
    $.each(columns, function (index, content) {
        let comma = '';
        if (index != 0) {
            comma = ','
        }
        let key = Object.keys(content)[0];
        if (key == 'data') {
            //test if render is needed
            if (content[key][1] == 'false') {
                columnsArray.push({data: '' + content[key][0]});
            }
            else {
                columnsArray.push({
                    data: '' + content[key][0], render: function (data, type, row) {
                        return eval(content[key][1]);
                    }
                });
            }
        }
        else if (key == 'defaultContent') {
            columnsArray.push({defaultContent: content[key]})
        }
    });
    if (buttonFunc == '') {
        dom = {dom: domParams}
    }
    else {
        dom = {
            dom: domParams,
            buttons: [
                {
                    text: '<span class="fa fa-plus-circle">Add ' + contentName + ' </span>',
                    action: function (e, dt, node, config) {
                        eval(buttonFunc);
                    },
                    className: 'btn-sm btn-info'
                }
            ]
        };
        if (!$.isEmptyObject(customButton)) {
            dom.buttons.push(
                {
                    text: '<span class="' + customButton['icon'] + '">' + customButton['text'] + ' </span>',
                    action: function (e, dt, node, config) {
                        eval(customButton['click']);
                    },
                    className: customButton['class']+' ml-5'
                });
        }
    }
    if (Sort != undefined) {
        sorting = {
            "order": [[Sort['columnIndex'], Sort['order']]]
        };
    }
    else {
        sorting = {};
    }
    let ajaxConfig = {
        "ajax": RootFolderUrl + datatableAjaxRoute
    };
    let pageLengthConfig = {
        "pageLength": pageLength
    };
    columnsArray = {columns: columnsArray};
    let combine = $.extend({}, dom, ajaxConfig, pageLengthConfig, columnsArray, sorting);
    $('#' + tableId).DataTable(combine);
}