<?php

class Pages extends Controller
{
    public function __construct()
    {

    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Violet Fasion', 'description' => 'Please login if you\'re an admin or else, please register your car'];
        $this->view('pages/index', $data);

    }

    public function about()
    {
        $data = ['title' => 'About', 'description' => 'Admin panel for Baydoun Design'];
        $this->view('pages/about', $data);
    }

    public function documentation()
    {
        $data = ['title' => 'Documentation', 'description' => 'this is the documetation page'];
        $this->view('pages/documentation', $data);
    }

    public function testapi($test_type)
    {

        //echo $this->encode_json(func_get_args());
        // this would get me the whole parameter array passed to this
        // function, (although php doesn't mind more parameters than needed
//        $num = $number * 2;
//        $return_val = ['number' => $num];
//        echo $this->encode_json($return_val);
//        echo 'pages';
        echo $test_type;
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            echo print_r($_POST['data']);
        }
    }

    public function requests($request)
    {
        switch ($request) {
            case 'get_users':
                echo $this->encode_json(["response" => "you have requested users"]);
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}