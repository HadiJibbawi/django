//id
//name
//phone_number
//secondary_phone_number
//email_address
//delivery_address
//date_created
let supplier_view_model;
supplier_view_model = new SupplierViewModel();

function SupplierViewModel() {
    const self = this;

    self.currentRow = ko.observable();
    self.currentSupplier = ko.observable({'firstName': ''});

    self.newSupplier = ko.observable(new Supplier());

    self.suppliers = ko.observableArray([]);
    self.supplierTitles = ko.observableArray([]);
    self.supplierJobs = ko.observableArray([]);
    self.supplierGroups = ko.observableArray([]);
    self.supplierCompanies = ko.observableArray([]);
    self.supplierPhoneNumberTypes = ko.observableArray([]);
    self.supplierEmailAddressTypes = ko.observableArray([]);
    self.phoneNumberCountryCodes = ko.observableArray([]);


    self.showSupplierPhoneNumbersModal = function () {
        $('#supplierPhoneNumbersModal').modal('show');
    };
    self.addSupplierEmailAddressType = function () {
        let newType = prompt('please enter new email address type');
        let route = ['suppliers', 'requests', 'addEmailAddressType'];
        postData(route,{data:newType},function (response) {
            if (response == '1') {
                toastr.success('type added');
                self.getSupplierEmailAddressTypes();
            }
        })
    };
    self.addSupplierPhoneNumberType = function () {
        let newType = prompt('please enter new phone number type');
        let route = ['suppliers', 'requests', 'addPhoneNumberType'];
        postData(route,{data:newType},function (response) {
            if (response == '1') {
                toastr.success('type added');
                self.getSupplierPhoneNumberTypes();
            }
        })
    };
    self.hideSupplierPhoneNumbersModal = function () {
        $('#supplierPhoneNumbersModal').modal('hide');
    };
    self.showSupplierEmailAddressesModal = function () {
        $('#supplierEmailAddressesModal').modal('show');
    };
    self.hideSupplierEmailAddressesModal = function () {
        $('#supplierEmailAddressesModal').modal('hide');
    };
    self.getPhoneNumberCountryCodes = function () {
        let route = ['suppliers', 'requests', 'getAllPhoneNumberCountryCodes'];
        fetchDataJson(route, {}, function (phoneNumberCountryCodes) {
            $.each(phoneNumberCountryCodes, function (index, code) {
                self.phoneNumberCountryCodes.push(new CountryCode(code));
            });
        });
    };
    self.getPhoneNumberCountryCodes();
    self.getSupplierPhoneNumberTypes = function () {
        let route = ['suppliers', 'requests', 'getSupplierPhoneNumberTypes'];
        fetchDataJson(route, {}, function (SupplierPhoneNumberTypes) {
            self.supplierPhoneNumberTypes(SupplierPhoneNumberTypes);
        });
    };

    self.getSupplierPhoneNumberTypes();
    self.getSupplierJobs = function () {
        let route = ['suppliers', 'requests', 'getSupplierJobs'];
        fetchDataJson(route, {}, function (supplierJobs) {
            self.supplierJobs(supplierJobs);
        });
    };

    self.getSupplierJobs();
    self.getSupplierEmailAddressTypes = function () {
        let route = ['suppliers', 'requests', 'getSupplierEmailAddressTypes'];
        fetchDataJson(route, {}, function (SupplierEmailAddressTypes) {
            self.supplierEmailAddressTypes(SupplierEmailAddressTypes);
        });
    };
    self.getSupplierEmailAddressTypes();

    self.getSupplierTitles = function () {
        let route = ['suppliers', 'requests', 'getSupplierTitles'];
        fetchDataJson(route, {}, function (titles) {
            self.supplierTitles(titles);
        });
    };
    self.getSupplierTitles();

    self.getSupplierGroups = function () {
        let route = ['suppliers', 'requests', 'getSupplierGroups'];
        fetchDataJson(route, {}, function (groups) {
            self.supplierGroups(groups);
        });
    };
    self.getSupplierGroups();

    self.getSupplierCompanies = function () {
        let route = ['suppliers', 'requests', 'getSupplierCompanies'];
        fetchDataJson(route, {}, function (companies) {
            self.supplierCompanies(companies);
        });
    };
    self.getSupplierCompanies();

    self.clearNewSupplierModal = function () {
        self.newSupplier({});
    };

    self.addSupplier = function () {
        let addSupplierForm = $('#addSupplierForm');

        if (!addSupplierForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addSupplierForm).click().remove();
        }
        else {
            let route = ['suppliers', 'requests', 'addSupplier'];
            let supplier = {};
            supplier.firstName = self.newSupplier().firstName();
            supplier.middleName = self.newSupplier().middleName();
            supplier.lastName = self.newSupplier().lastName();
            supplier.supplierTitle = self.newSupplier().supplierTitle();
            supplier.address = self.newSupplier().address();
            supplier.supplierJob = self.newSupplier().supplierJob() == undefined ? 0 : self.newSupplier().supplierJob();
            supplier.supplierGroup = self.newSupplier().supplierGroup() == undefined ? 0 : self.newSupplier().supplierGroup();
            supplier.supplierCompany = self.newSupplier().supplierCompany() == undefined ? 0 : self.newSupplier().supplierCompany();
            postData(route, supplier, function (result) {
                if (result == '1') {
                    toastr.success('Supplier Added Successfully');
                    self.clearNewSupplierModal();
                    $('#datatable_suppliers').DataTable().ajax.reload();

                }
                else {
                    toastr.warning('Supplier Addition Failed');
                }
            });

            $('#add_Supplier_modal').modal('hide');

        }
    };

    self.deleteCurrentSupplier = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentSupplier().displayName());
        if (confirmDelete) {
            let deleteRoute = ['suppliers', 'requests', 'deleteSupplier'];
            postData(deleteRoute, {'id': self.currentSupplier().id}, function (response) {
                if (response == '1') {
                    toastr.success('Supplier Deleted');
                    $('#edit_Supplier_modal').modal('hide');
                    self.currentSupplier({'firstName': ''});
                    $('#datatable_suppliers').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Supplier Deletion Failed');
                }
            });
        }
    };

    self.resetCurrentSupplier = function () {
        let table = $('#datatable_suppliers').DataTable();
        let data = ko.toJS(table.row(self.currentRow()).data());
        supplier_view_model.currentSupplier(new Supplier(data));
    };

    self.submitEditSupplier = function () {

        let editCurrentSupplierForm = $('#editCurrentSupplierForm');

        if (!editCurrentSupplierForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentSupplierForm).click().remove();
        }
        else {
            let route = ['suppliers', 'requests', 'updateSupplier'];
            let table = $('#datatable_suppliers').DataTable();
            let supplier = {};
            const originalSupplier = ko.toJS(table.row(self.currentRow()).data());
            const currentSupplier = ko.toJS(self.currentSupplier);
            console.log(originalSupplier);
            console.log(currentSupplier);

            for (const prop in originalSupplier) {
                if (prop != 'emailAddresses' && prop != 'phoneNumbers' && prop != 'supplierGroupId' && prop != 'supplierCompanyId' && prop != 'supplierTitleId') {
                    if (originalSupplier[prop] != currentSupplier[prop]) {
                        supplier[prop] = currentSupplier[prop];
                    }
                }
            }

            if ($.isEmptyObject(supplier)) {
                alert('No changes have been made');
                return;
            }
            supplier['id'] = originalSupplier.id;
            postData(route, supplier, function (result) {
                if (result == '1') {
                    toastr.success('Supplier Edited Successfully');
                    let table = $('#datatable_suppliers').DataTable();
                    table.ajax.reload();
                }
                else {
                    toastr.warning('Supplier Edit Failed');
                }
            });
        }
    };


}

function Supplier(supplier) {

    const self = this;

    self.setSupplierPhoneNumbers = function () {
        let phoneNumbers = ko.observableArray([]);
        $.each(supplier.phoneNumbers, function (index, phoneNumber) {
            phoneNumbers.push(new PhoneNumber(phoneNumber))
        });
        return phoneNumbers;
    };
    self.setSupplierEmailAddresses = function () {
        let emailAddresses = ko.observableArray([]);
        $.each(supplier.emailAddresses, function (index, emailAddress) {
            emailAddresses.push(new EmailAddress(emailAddress))
        });
        return emailAddresses;
    };

    self.id = supplier == undefined ? ko.observable('') : ko.observable(supplier.id);
    self.firstName = supplier == undefined ? ko.observable('') : ko.observable(supplier.firstName);
    self.middleName = supplier == undefined ? ko.observable('') : ko.observable(supplier.middleName);
    self.lastName = supplier == undefined ? ko.observable('') : ko.observable(supplier.lastName);
    self.supplierTitle = supplier == undefined ? ko.observable('') : ko.observable(supplier.supplierTitleId);
    self.address = supplier == undefined ? ko.observable('') : ko.observable(supplier.address);
    self.supplierGroup = supplier == undefined ? ko.observable('') : ko.observable(supplier.supplierGroupId);
    self.supplierCompany = supplier == undefined ? ko.observable('') : ko.observable(supplier.supplierCompanyId);
    self.supplierJob = supplier == undefined ? ko.observable('') : ko.observable(supplier.supplierJobId);

    self.phoneNumbers = supplier == undefined ? ko.observableArray() : self.setSupplierPhoneNumbers();
    self.emailAddresses = supplier == undefined ? ko.observableArray() : self.setSupplierEmailAddresses();
    self.enableDelete = ko.observable(false);

    self.addPhoneNumber = function () {
        //122 is the id for lebanon
        self.phoneNumbers.push(new PhoneNumber({'id': '0', 'countryCode': 122}));
    };
    self.removePhoneNumber = function (phoneNumber) {
        let confirmDelete = confirm('are you sure you want to delete this phone number?');
        if (confirmDelete) {
            self.phoneNumbers.destroy(phoneNumber);
        }
    };
    self.addEmailAddress = function () {
        //122 is the id for lebanon
        self.emailAddresses.push(new EmailAddress({'id':'0'}));
    };
    self.removeEmailAddress = function (emailAddress) {
        let confirmDelete = confirm('are you sure you want to delete this email address?');
        if (confirmDelete) {
            self.emailAddresses.destroy(emailAddress);
        }
    };

    self.saveSupplierPhoneNumbers = function () {
        let savePhoneNumbersForm = $('#supplierPhoneNumbersForm');

        if (!savePhoneNumbersForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(savePhoneNumbersForm).click().remove();
        }
        else {
            let route = ['suppliers', 'requests', 'submitSupplierPhoneNumbers'];
            let phoneNumbers = [];
            let table = $('#datatable_suppliers').DataTable();
            let currentPhoneNumbers = ko.toJS(self.phoneNumbers);
            $.each(currentPhoneNumbers, function (index, phoneNumber) {
                let tempPhoneNumber = {};
                if (phoneNumber.id != 0) {
                    const originalSupplier = ko.toJS(table.row(supplier_view_model.currentRow()).data());
                    let originalPhoneNumber = ko.utils.arrayFirst(originalSupplier.phoneNumbers, function (originalNumber) {
                        return originalNumber.id == phoneNumber.id;
                    });
                    for (const prop in phoneNumber) {

                        if (originalPhoneNumber[prop] != phoneNumber[prop]) {
                            if (tempPhoneNumber.id == undefined) {
                                tempPhoneNumber.id = phoneNumber.id;
                            }
                            tempPhoneNumber[prop] = phoneNumber[prop];
                        }
                    }
                }
                else {
                    tempPhoneNumber = phoneNumber;
                }
                phoneNumbers.push(tempPhoneNumber);
            });

            postData(route, {'supplierId': self.id(), 'data': phoneNumbers}, function (result) {
                if (result == '1') {
                    toastr.success('Phone Numbers saved Added Successfully');
                    $('#datatable_suppliers').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Phone Numbers save Failed');
                }
            });
        }
    };
    self.saveSupplierEmailAddresses = function () {
        let saveEmailAddressesForm = $('#supplierEmailAddressesForm');

        if (!saveEmailAddressesForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(saveEmailAddressesForm).click().remove();
        }
        else {
            let route = ['suppliers', 'requests', 'submitSupplierEmailAddresses'];
            let emailAddresses = [];
            let table = $('#datatable_suppliers').DataTable();
            let currentEmailAddresses = ko.toJS(self.emailAddresses);
            $.each(currentEmailAddresses, function (index, emailAddress) {
                let tempEmailAddress = {};
                if (emailAddress.id != 0) {
                    const originalSupplier = ko.toJS(table.row(supplier_view_model.currentRow()).data());
                    let originalEmailAddress = ko.utils.arrayFirst(originalSupplier.emailAddresses, function (originalAddress) {
                        return originalAddress.id == emailAddress.id;
                    });
                    for (const prop in emailAddress) {

                        if (originalEmailAddress[prop] != emailAddress[prop]) {
                            if (tempEmailAddress.id == undefined) {
                                tempEmailAddress.id = emailAddress.id;
                            }
                            tempEmailAddress[prop] = emailAddress[prop];
                        }
                    }
                }
                else {
                    tempEmailAddress = emailAddress;
                }
                emailAddresses.push(tempEmailAddress);
            });

            postData(route, {'supplierId': self.id(), 'data': emailAddresses}, function (result) {
                if (result == '1') {
                    toastr.success('Email Addresses saved Added Successfully');
                    $('#datatable_suppliers').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Email Addresses save Failed');
                }
            });


        }
    };

    let viewmodel = supplier_view_model == undefined ? {supplierTitles: ko.observableArray()} : supplier_view_model;
    self.displayName = ko.computed(function () {
        // console.log('computed');
        let title = viewmodel.supplierTitles()[self.supplierTitle()] == undefined ? '' : (ko.utils.arrayFirst(viewmodel.supplierTitles(), function (title) {
            return title.id == self.supplierTitle();
        })).title;
        return title + '. ' + self.firstName() + ' ' + self.middleName() + ' ' + self.lastName();

    });
}

function PhoneNumber(phoneNumber) {
    const self = this;

    self.id = ko.observable(phoneNumber.id);
    self.phoneNumberTypeId = ko.observable(phoneNumber.phoneNumberTypeId);
    self.countryCode = ko.observable(phoneNumber.countryCode);
    self.areaCode = ko.observable(phoneNumber.areaCode);
    self.subscriberNumber = ko.observable(phoneNumber.subscriberNumber);
    self.extension = ko.observable(phoneNumber.extension);
    self.notes = ko.observable(phoneNumber.notes);
}


function EmailAddress(emailAddress) {
    const self = this;

    self.id = ko.observable(emailAddress.id);
    self.emailAddressTypeId = ko.observable(emailAddress.emailAddressTypeId);
    self.emailAddress = ko.observable(emailAddress.emailAddress);
}


function CountryCode(countryCode) {
    const self = this;

    self.id = countryCode.id;
    self.country = countryCode.country;
    self.code = countryCode.code;

    self.displayName = ko.computed(function () {
        let country = '';
        //this is to make sure the select is not over wide
        if (self.country.length > 10) {
            country = self.country.substring(0, 11);
        }
        else {
            country = self.country;
        }
        return country + ' (' + self.code + ')';
    });
}

ko.applyBindings(supplier_view_model);
const suppliersTableId = 'datatable_suppliers';
const suppliersButtonFunc = '$(\'#add_Supplier_modal\').modal(\'show\');';
const suppliersDomParams = 'lfBrtip';
const suppliersContentName = 'Supplier';
const suppliersDatatableAjaxRoute = '/suppliers/requests/getAllSuppliers/datatablesEncode';
const suppliersColumns = [
    {'data': [null, '((row.supplierTitle) + ". " + (row.firstName.charAt(0).toUpperCase() + row.firstName.slice(1))) + " " + ((row.middleName.charAt(0).toUpperCase() + row.middleName.slice(1))) + " " +((row.lastName.charAt(0).toUpperCase() + row.lastName.slice(1)))']},
    {'data': [null, '(row.phoneNumbers.length > 0 ? (row.phoneNumbers[0].countryCodeLiteral+ \'-\' + row.phoneNumbers[0].areaCode + \'-\' + row.phoneNumbers[0].subscriberNumber + \'/\' + row.phoneNumbers[0].extension):"")']},
    {'data': ['supplierCompany', 'false']}
];

configureDatatable(suppliersTableId, suppliersButtonFunc,{}, suppliersDomParams, suppliersContentName, suppliersDatatableAjaxRoute, suppliersColumns);

$(document).ready(function () {
    let table = $('#datatable_suppliers').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_suppliers tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_suppliers tbody').on('click', 'tr', function () {
        supplier_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        supplier_view_model.currentSupplier(new Supplier(data));
        $('#edit_Supplier_modal').modal('show');
    });

    //this allows for a custom message in case the user enters an invalid password

});
