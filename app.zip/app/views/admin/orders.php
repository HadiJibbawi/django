<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 22/02/21
 * Time: 5:03 PM
 */
?>

<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-around">

        <div class="col-10">
            <div id="orders_table_container" class="col-12">
                <?php
//                $table_columns = ['Customer', 'ProductType', "Status"];
                $table_columns = ['Order Number','Customer','Placement Date','Due Date'];
                $table_properties = ["tableId" => "datatable_orders", "title" => 'Orders', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

