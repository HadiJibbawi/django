<?php

class Agent
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllAgents()
    {
        $this->db->query('SELECT a.id AS id,a.first_name AS firstName,a.middle_name AS middleName, a.last_name AS lastName, a.address AS address,at.title AS agentTitle,a.job as agentJobId,aj.title as agentJob,at.id AS agentTitleId,ag.title AS agentGroup,ag.id AS agentGroupId,ac.name AS agentCompany,ac.id AS agentCompanyId FROM agents a LEFT JOIN agent_titles at ON a.title = at.id LEFT JOIN agent_groups ag ON a.agent_group = ag.id LEFT JOIN agent_companies ac ON a.company = ac.id left join agent_jobs aj on a.job = aj.id');
        $agents = $this->db->resultSet();
        foreach ($agents as $agent) {
            $agent->phoneNumbers = $this->getAgentPhoneNumbers($agent->id);
            $agent->emailAddresses = $this->getAgentEmailAddresses($agent->id);
        }
        return $agents;
    }

    public function getAllPhoneNumberCountryCodes()
    {
        $this->db->query('SELECT id,country,code FROM phone_number_country_codes');
        $phoneNumberCountryCodes = $this->db->resultSet();
        return $phoneNumberCountryCodes;
    }

    public function getAgentPhoneNumberTypes()
    {
        $this->db->query('SELECT id,type FROM agent_phone_number_types');
        $phoneNumberTypes = $this->db->resultSet();
        return $phoneNumberTypes;
    }

    public function getAgentEmailAddressTypes()
    {
        $this->db->query('SELECT id,type FROM agent_email_address_types');
        $emailAddressTypes = $this->db->resultSet();
        return $emailAddressTypes;
    }

    public function getAgentTitles()
    {
        $this->db->query('SELECT id,title,description FROM agent_titles');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getAgentGroups()
    {
        $this->db->query('SELECT id,title,description FROM agent_groups');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getAgentJobs()
    {
        $this->db->query('SELECT id,title,description FROM agent_jobs');
        $jobs = $this->db->resultSet();
        return $jobs;
    }

    public function getAgentCompanies()
    {
        $this->db->query('SELECT id,name,address,business_type FROM agent_companies');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getAgentPhoneNumbers($agentId)
    {
        $this->db->query('SELECT apn.id AS id, apnt.type AS phoneNumberType,apnt.id AS phoneNumberTypeId,apn.area_code AS areaCode,apn.country_code AS countryCode,pncc.code as countryCodeLiteral,apn.subscriber_number AS subscriberNumber,apn.extension AS extension,apn.notes AS notes FROM `agent_phone_numbers` apn LEFT JOIN agent_phone_number_types apnt ON apn.type = apnt.id left join phone_number_country_codes pncc on apn.country_code = pncc.id WHERE apn.agent_id = :agentId');
        $this->db->bind(':agentId', $agentId);
        $agentPhoneNumbers = $this->db->resultSet();
        return $agentPhoneNumbers;
    }

    public function getAgentEmailAddresses($agentId)
    {
        $this->db->query('SELECT cea.id AS id, ceat.type AS emailAddressType,ceat.id AS emailAddressTypeId,cea.address AS emailAddress FROM `agent_email_addresses` cea LEFT JOIN agent_email_address_types ceat ON cea.type = ceat.id WHERE cea.agent_id = :agentId');
        $this->db->bind(':agentId', $agentId);
        $agentEmailAddresses = $this->db->resultSet();
        return $agentEmailAddresses;
    }

    public function addAgent($agent)
    {
        $firstName = $agent['firstName'];
        $middleName = $agent['middleName'];
        $lastName = $agent['lastName'];
        $title = $agent['agentTitle'];
        $address = $agent['address'];
        $agentGroup = $agent ['agentGroup'];
        $agentCompany = $agent['agentCompany'];
        $agentJob = $agent['agentJob'];
        $this->db->query('INSERT INTO `agents` (title, first_name, middle_name, last_name, company,job, agent_group, address) VALUES (:title, :firstName, :middleName, :lastName, :agentCompany, :agentJob, :agentGroup, :address)');
        $this->db->bind(':firstName', $firstName);
        $this->db->bind(':middleName', $middleName);
        $this->db->bind(':lastName', $lastName);
        $this->db->bind(':title', $title);
        $this->db->bind(':agentJob', $agentJob);
        $this->db->bind(':address', $address);
        $this->db->bind(':agentGroup', $agentGroup);
        $this->db->bind(':agentCompany', $agentCompany);
        return $this->db->execute();
    }

    public function addPhoneNumberType($phoneNumberType)
    {
        $this->db->query('INSERT INTO `agent_phone_number_types` (type) VALUES (:type)');
        $this->db->bind(':type', $phoneNumberType);
        return $this->db->execute();
    }

    public function addEmailAddressType($emailAddressType)
    {
        $this->db->query('INSERT INTO `agent_email_address_types` (type) VALUES (:type)');
        $this->db->bind(':type', $emailAddressType);
        return $this->db->execute();
    }

    public function updateAgent($agent)
    {

        $table = 'agents';
        $columns = $agent;
        $primaryKeyName = 'id';
        $primaryKeyValue = $agent['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updatePhoneNumber($phoneNumber)
    {

        $table = 'agent_phone_numbers';
        $columns = $phoneNumber;
        $primaryKeyName = 'id';
        $primaryKeyValue = $phoneNumber['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updateEmailAddress($emailAddress)
    {

        $table = 'agent_email_addresses';
        $columns = $emailAddress;
        $primaryKeyName = 'id';
        $primaryKeyValue = $emailAddress['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function addAgentPhoneNumber($agentId,$phoneNumber){
        $table = 'agent_phone_numbers';
        $columns = $phoneNumber;
        $columns['agent_id'] = $agentId;
        return $this->db->insertIntoTable($table,$columns);
    }

    public function addAgentEmailAddress($agentId,$emailAddress){
        $table = 'agent_email_addresses';
        $columns = $emailAddress;
        $columns['agent_id'] = $agentId;
        return $this->db->insertIntoTable($table,$columns);
    }
    public function deleteAgentPhoneNumber($phoneNumberId){
        $this->db->query('delete from agent_phone_numbers WHERE id = :phoneNumberId');
        $this->db->bind(':phoneNumberId',$phoneNumberId);
        return $this->db->execute();
    }

    public function deleteAgent($id)
    {
        $this->db->query('DELETE FROM `agents` WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->execute();
        $this->db->query('delete from agent_phone_numbers WHERE agent_id = :agentId');
        $this->db->bind(':agentId', $id);
        $this->db->execute();
        $this->db->query('delete from agent_email_addresses WHERE agent_id = :agentId');
        $this->db->bind(':agentId', $id);
        return $this->db->execute();
        //todo check if agent corresponds to other things
    }

}