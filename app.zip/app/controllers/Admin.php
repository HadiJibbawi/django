<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:40 AM
 */

class Admin extends Controller
{
    private $productModel;
    private $userModel;

    public function __construct()
    {
        $this->productModel = $this->model('Product');
        $this->userModel = $this->model('User');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }


    public function Users()
    {
        $data = ['title' => 'Users', 'description' => 'User Management Page'];
        $template = [];
        $template['page_script'] = 'users';
        $this->view('admin/users', $data, $template);
    }

    public function Settings($page = 'products')
    {
        $data = ['title' => 'Settings', 'description' => 'site settings panel'];
        $template = [];
        $template['page_script'] = 'settings';
        $this->view('admin/settings', $data, $template);
    }

    public function products()
    {
//        $products = $this->productModel->getAllProducts();
        $data = ['title' => 'Products', 'description' => 'Page for products overview', 'currency' => 'L.L'];
        $template = [];
        $template['page_script'] = 'products';
        $this->view('admin/products', $data, $template);
    }

    public function customers()
    {
        $data = ['title' => 'Customers', 'description' => 'Page for Customer Management'];
        $template = [];
        $template['page_script'] = 'customers';
        $this->view('admin/customers', $data, $template);
    }

    public function product($id = null, $tab = 'details')
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        else {
            $product = $this->productModel->getProduct($id);
            $discountTypes = $this->productModel->getAllDiscountTypes();
            $data = ['title' => ucfirst($product->title) . ' Product Page', 'description' => 'Page for Product Details', 'currency' => 'L.L', 'discountTypes' => $discountTypes, 'product' => $product, 'tab' => $tab];
            $template = [];
            $template['page_script'] = 'product';
            $this->view('admin/product', $data, $template);
        }
    }

    public function getProductItems($productId)
    {
        //get product items and items options data
//        $productOptions = $this->productModel->getAllProductOptions($productId);
//        $productOptionTypes = $this->productModel->getAllOptionTypes();
//        $genericProductOptions = $this->productModel->getGenericProductOptions();

    }


    //    public function productType($id = null, $tab = 'details')
    public function productType($id = null, $tab = 'details')
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        else {
            $productType = $this->productModel->getProductType($id);
            $data = ['title' => ucfirst($productType->title) . ' Page', 'description' => 'Page for Product Details', 'productType' => $productType];
            $template = [];
            $template['page_script'] = 'product_type';
            $this->view('admin/product_type', $data, $template);
        }
    }

    //this is for testing todo remove
    public function Testing($id = null, $tab = 'details')
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        else {
            $productType = $this->productModel->getProductType($id);
            $data = ['title' => ucfirst($productType->title) . ' Page', 'description' => 'Page for Product Details', 'productType' => $productType];
            $template = [];
            $template['page_script'] = 'testing';
            $this->view('admin/testing', $data, $template);
        }
    }

    private function getProductTypeFields($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $fields = $this->productModel->getProductTypeFields($id);
        return $fields;

    }

    private function getProductTypeProcesses($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $processes = $this->productModel->getProductTypeProcesses($id);
        return $processes;

    }


    public function getAllProductOptions()
    {

    }


// this was private but changed it to test issues
    public function addImage($image, $imageTypeId = 2, $productId)
    {

        /*
         * image types and their respective Ids
         * cover : 1
         * product : 2
         * chart 3
         */
        if (isset($image["type"])) {
            $imageValidationResponse = $this->validateImage($image);
            if ($imageValidationResponse['response']) {
                //set the variables needed
                $productImagesDirectory = FILEROOT . 'img\\products\\';
                $directory = $productImagesDirectory . $productId;
                if (!file_exists($directory)) {
                    mkdir($directory);
                }
                $imageDirectory = $directory . '\\';
                $imageExtension = $imageValidationResponse['extension'];
                $imageDetails = [];
                $imageDetails['name'] = $image['name'];
                $imageDetails['imageTypeId'] = $imageTypeId;
                $imageDetails['productId'] = $productId;
                $newImageId = $this->productModel->addImage($imageDetails);
                $newImageName = $newImageId . '.' . $imageExtension;
                $isUploaded = $this->uploadImage($image, $imageDirectory, $newImageName);
                if ($isUploaded) {
                    $imageUrl = URLROOT . '/public/img/products/' . $productId . '/' . $newImageId . '.' . $imageExtension;
                    $imageUrlChangeSuccess = $this->productModel->updateImageURL($newImageId, $imageUrl);
                    if ($imageUrlChangeSuccess) {
                        return $imageUrl;
                    }
                    else {
                        return 'Image URL Change Failed';
                    }
                }
                else {
                    return 'Upload Failed';
                }
            }
            else {
                return $imageValidationResponse['err_msg'];
            }
        }
        else {
            return '***Invalid Request***';
        }
    }

    private function validateImage($image)
    {
        $response = ['response' => '', 'err_msg' => 'none'];
        $validextensions = array("jpeg", "jpg", "png");

        //this explodes the name by the . so that we get the extension of the file
        $temporary = explode(".", $image["name"]);
        $file_extension = end($temporary);
        $file_extension = strtolower($file_extension);
        //check for valid file types
        if ((($image["type"] == "image/png") || ($image["type"] == "image/jpg") || ($image["type"] == "image/jpeg")
            ) && ($image["size"] < 10000000)//Approx. 1MB files can be uploaded.
            && in_array($file_extension, $validextensions)) {

            //check if image has any errors
            if ($image["error"] > 0) {
                $response['response'] = false;
                $response['err_msg'] = "Error Code: " . $image["error"];
            }

            //this means image is validated
            else {
                $response['response'] = true;
                $response['extension'] = $file_extension;
            }
        }
        else {
            $response['response'] = false;
            if ($image["error"] > 0) {
                $response['err_msg'] = "Error Code: " . $image["error"];
            }
            $response['response'] = '***Invalid file Size or Type***';
        }
        return $response;

    }

    public function uploadImage($image, $directory, $newName)
    {
        $filename = $newName;
        $sourcePath = $image['tmp_name']; // Storing source path of the file in a variable
//        $sourcePath = str_replace('\\','/',$sourcePath);
        $targetPath = $directory . $filename; // Target path where file is to be stored
        $uploadSuccess = move_uploaded_file($sourcePath, $targetPath);
        if ($uploadSuccess) {
            return true;
        } // Moving Uploaded file
        else {
            return false;
        }
    }

    private function getUsers()
    {
        $allUsers = $this->userModel->getAllUsers();
        return $allUsers;
    }

    private function getUserRoles()
    {
        $allRoles = $this->userModel->getUserRoles();
        return $allRoles;
    }

    private function addProduct($product)
    {
        $result = $this->productModel->addProduct($product);
        echo $result;
    }

    private function addUser($user)
    {
        $result = $this->userModel->addUser($user);
        echo $result;
    }

    private function addProductType($productType)
    {
        $result = $this->productModel->addProductType($productType);
        echo $result;
    }

    private function addProductTypeField($field)
    {
        $result = $this->productModel->addProductTypeField($field);
        echo $result;
    }

    private function addProductTypeProcessType($processType)
    {
        $result = $this->productModel->addProductTypeProcessType($processType);
        echo $result;
    }

    private function addOption($product)
    {
        $result = $this->productModel->addProduct($product);
        echo $result;
    }

    private function deleteProduct($id)
    {
        $result = $this->productModel->deleteProduct($id);
        echo $result;
    }

    private function deleteProcessType($id)
    {
        $result = $this->productModel->deleteProcessType($id);
        echo $result;
    }

    private function deleteUser($id)
    {
        $result = $this->userModel->deleteUser($id);
        echo $result;
    }

    private function deleteProductType($id)
    {
        $result = $this->productModel->deleteProductType($id);
        echo $result;
    }

    private function updateUser($user)
    {
        if (isset($user['userName'])) {
            $user['user_name'] = $user['userName'];
            unset($user['userName']);
        }
        if (isset($user['roleId'])) {
            $user['role'] = $user['roleId'];
            unset($user['roleId']);
        }
        if (isset($user['password'])) {
            $user['password'] = hash('md5', $user['password']);
            unset($user['userName']);
        }
        echo $this->userModel->updateUser($user);
//        var_dump(key($user));
    }

    private function updateProductType($productType)
    {
        echo $this->productModel->updateProductType($productType);
    }

    private function updateProcessType($processType)
    {
        echo $this->productModel->updateProcessType($processType);
    }

    private function updateProductTypeField($field)
    {
        echo $this->productModel->updateProductTypeField($field);
    }

    private function deleteField($ids)
    {
        $result = $this->productModel->deleteField($ids);
        echo $result;
    }

    private function saveFieldValues($values)
    {
        $result =  $this->productModel->saveFieldValues($values);
        echo $result;
    }
    private function getFieldValues($fieldId)
    {
        $result =  $this->productModel->getFieldValues($fieldId);
        return $result;
    }

    public function testapi($test_type)
    {

        //echo $this->encode_json(func_get_args());
        // this would get me the whole parameter array passed to this
        // function, (although php doesn't mind more parameters than needed
//        $num = $number * 2;
//        $return_val = ['number' => $num];
//        echo $this->encode_json($return_val);
//        echo 'pages';
        echo $test_type;
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            echo print_r($_POST['data']);
        }
    }

    public function requests($request)
    {
        switch ($request) {
            case 'get_users':
                echo $this->encode_json(['data' => $this->getUsers()]);
                break;
            case 'getUserRoles':
                echo $this->encode_json($this->getUserRoles());
                break;
            case 'addUser':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addUser($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->users();
                }
                break;
            case 'deleteUser':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->deleteUser($_POST['id']);
                }
                else {
                    flash('delete_user_failed', 'User deletion failed', 'alert alert-danger');
                    $this->users();
                }
                break;
            case 'deleteProductType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->deleteProductType($_POST['id']);
                }
                else {
                    flash('delete_product_type_failed', 'Product Type deletion failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'updateUser':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//                    var_dump($_POST);
                    $this->updateUser($_POST);
                }
                else {
                    flash('update_user_failed', 'User update failed', 'alert alert-danger');
                    $this->users();
                }
                break;
            case 'updateProductType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateProductType($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'updateProcessType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateProcessType($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'updateProductTypeField':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateProductTypeField($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'getAllProductsDatatables':
                echo $this->encode_json(['data' => $this->productModel->getAllProducts()]);
                break;
            case 'getAllProducts':
                echo $this->encode_json($this->productModel->getAllProducts());
                break;
            case 'getProductTypes':
                echo $this->encode_json(['data' => $this->productModel->getAllProductTypes()]);
                break;
            case 'getProductTypeFields':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json(['data' => $this->getProductTypeFields($id)]);
                    break;
                }
            case 'getProductTypeProcesses':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json(['data' => $this->getProductTypeProcesses($id)]);
                    break;
                }
            case 'getFieldsDataTypes':
                echo $this->encode_json($this->productModel->getFieldsDataTypes());
                break;
            case 'saveFieldValues':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->saveFieldValues($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'getFieldValues':
                if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                    echo $this->encode_json($this->getFieldValues($_GET['fieldId']));
                }
                else {
                    $this->products();
                }
                break;
            case 'getFieldsTypes':
                echo $this->encode_json($this->productModel->getFieldsTypes());
                break;
            case 'addProductTypeField':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addProductTypeField($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'addProductType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addProductType($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'addProductTypeProcessType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addProductTypeProcessType($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'getGenericProductOptions':
                echo $this->encode_json(['data' => $this->productModel->getGenericProductOptions()]);
                break;
            case 'getGenericProductOptionValues':

                $params = func_get_args();
                if (isset($params[1])) {
                    $optionId = $params[1];
                    echo $this->encode_json(['data' => $this->productModel->getGenericProductOptionValues($optionId)]);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    echo 'Invalid Parameters : need Option ID';
                }
                break;
            case 'getProductOptionValues':

                $params = func_get_args();
                if (isset($params[1])) {
                    $optionId = $params[1];
                    echo $this->encode_json(['data' => $this->productModel->getProductOptionValues($optionId)]);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    echo 'Invalid Parameters : need Option ID';
                }
                break;
            case 'getProductOptions':
                $params = func_get_args();
                if (isset($params[1])) {
                    $product_id = $params[1];
                    echo $this->encode_json(['data' => $this->productModel->getProductOptions($product_id)]);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    echo 'Invalid Parameters : need Product ID';
                }
                break;
            case 'getProductItems':
                $params = func_get_args();
                if (isset($params[1])) {
                    $productId = $params[1];
                    $productItems = $this->productModel->getProductItems($productId);
                    echo $this->encode_json(['data' => $productItems]);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    echo 'Invalid Parameters : need Product ID';
                }
                break;
            case 'getProductOptionTypes':
                echo $this->encode_json($this->productModel->getProductOptionTypes());
                break;
            case 'deleteProduct':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->deleteProduct($_POST['id']);
                }
                else {
                    flash('delete_product_failed', 'Product deletion failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'deleteField':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->deleteField($_POST);
                }
                else {
                    flash('delete_field_failed', 'Field deletion failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'deleteProcessType':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->deleteProcessType($_POST);
                }
                else {
                    flash('delete_Process_Type_failed', 'Process Type deletion failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'addProduct':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addProduct($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            //todo : finish this
            case 'addOption':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->addOption($_POST, 'product');
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'uploadImages':
                if ($_SERVER['REQUEST_METHOD'] == 'FILES')
                    $this->uploadImages($_FILES);
                break;
            case 'addImage':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    if ($_POST['imageTypeId']) {
                        $imageTypeId = $_POST['imageTypeId'];
                    }
                    else {
                        //set as product image
                        $imageTypeId = 2;
                    }
                    $productId = $_POST['productId'];
                    echo $this->addImage($_FILES['image'], $imageTypeId, $productId);
                }
                break;
            case 'addProductItem':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->addProductItem($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    // $this->products();
                    echo 'Invalid Parameters submitted to addProductItem';

                }
                break;
            case 'deleteProductItem':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->deleteProductItem($_POST);
                    //echo $this->encode_json($this->productModel->deleteProductItem($_POST));

                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    // $this->products();
                    echo 'Invalid Parameters submitted to deleteProductItem';

                }
                break;
            case 'addOptionValue':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $params = func_get_args();
                    $type = $params[1];
                    if ($type == 'generic') {
                        echo $this->productModel->addOptionValue($_POST, 'generic');
                    }
                    else {
                        echo $this->productModel->addOptionValue($_POST, 'product');
                    }
                }
                else {
                    echo 'Invalid Parameters submitted to addOptionValue';
                }
                break;
            case 'addGenericOption':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->addOption($_POST, 'generic');
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->Settings('products');
                }
                break;
            case 'deleteGenericOption':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->deleteOption($_POST['id'], 'true');
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->Settings('products');
                }
                break;
            case 'deleteGenericOptionValue':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->deleteOptionValue($_POST['id'], 'true');
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
//                    $this->Settings('products');
                    echo 'Invalid Parameters';
                }
                break;
            case 'deleteOptionValue':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->deleteOptionValue($_POST['id'], 'false');
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
//                    $this->Settings('products');
                    echo 'Invalid Parameters';
                }
                break;
            case 'submitGenericOptionEdit':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->submitOptionEdit($_POST, 'true');
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->Settings('products');
                }
                break;
            case 'saveItemOptionChanges':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->saveItemOptionChanges($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    echo 'invalid params';
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>