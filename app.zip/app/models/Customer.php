<?php

class Customer
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllCustomers()
    {
        $this->db->query('SELECT c.id AS id,c.first_name AS firstName,c.middle_name AS middleName, c.last_name AS lastName, c.delivery_address AS deliveryAddress,ct.title AS customerTitle,ct.id AS customerTitleId,cg.title AS customerGroup,cg.id AS customerGroupId,cc.name AS customerCompany,cc.id AS customerCompanyId FROM customers c LEFT JOIN customer_titles ct ON c.title = ct.id LEFT JOIN customer_groups cg ON c.customer_group = cg.id LEFT JOIN customer_companies cc ON c.company = cc.id ');
        $customers = $this->db->resultSet();
        foreach ($customers as $customer) {
            $customer->phoneNumbers = $this->getCustomerPhoneNumbers($customer->id);
            $customer->emailAddresses = $this->getCustomerEmailAddresses($customer->id);
        }
        return $customers;
    }

    public function getAllPhoneNumberCountryCodes()
    {
        $this->db->query('SELECT id,country,code FROM phone_number_country_codes');
        $phoneNumberCountryCodes = $this->db->resultSet();
        return $phoneNumberCountryCodes;
    }

    public function getCustomerPhoneNumberTypes()
    {
        $this->db->query('SELECT id,type FROM customer_phone_number_types');
        $phoneNumberTypes = $this->db->resultSet();
        return $phoneNumberTypes;
    }

    public function getCustomerEmailAddressTypes()
    {
        $this->db->query('SELECT id,type FROM customer_email_address_types');
        $emailAddressTypes = $this->db->resultSet();
        return $emailAddressTypes;
    }

    public function getCustomerTitles()
    {
        $this->db->query('SELECT id,title,description FROM customer_titles');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getCustomerGroups()
    {
        $this->db->query('SELECT id,title,description FROM customer_groups');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getCustomerCompanies()
    {
        $this->db->query('SELECT id,name,address,business_type FROM customer_companies');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getCustomerPhoneNumbers($customerId)
    {
        $this->db->query('SELECT cpn.id AS id, cpnt.type AS phoneNumberType,cpnt.id AS phoneNumberTypeId,cpn.area_code AS areaCode,cpn.country_code AS countryCode,pncc.code as countryCodeLiteral,cpn.subscriber_number AS subscriberNumber,cpn.extension AS extension,cpn.notes AS notes FROM `customer_phone_numbers` cpn LEFT JOIN customer_phone_number_types cpnt ON cpn.type = cpnt.id left join phone_number_country_codes pncc on cpn.country_code = pncc.id WHERE cpn.customer_id = :customerId');
        $this->db->bind(':customerId', $customerId);
        $customerPhoneNumbers = $this->db->resultSet();
        return $customerPhoneNumbers;
    }

    public function getCustomerEmailAddresses($customerId)
    {
        $this->db->query('SELECT cea.id AS id, ceat.type AS emailAddressType,ceat.id AS emailAddressTypeId,cea.address AS emailAddress FROM `customer_email_addresses` cea LEFT JOIN customer_email_address_types ceat ON cea.type = ceat.id WHERE cea.customer_id = :customerId');
        $this->db->bind(':customerId', $customerId);
        $customerEmailAddresses = $this->db->resultSet();
        return $customerEmailAddresses;
    }

    public function addCustomer($customer)
    {
        $firstName = $customer['firstName'];
        $middleName = $customer['middleName'];
        $lastName = $customer['lastName'];
        $title = $customer['customerTitle'];
        $deliveryAddress = $customer['deliveryAddress'];
        $customerGroup = $customer ['customerGroup'];
        $customerCompany = $customer['customerCompany'];
        $this->db->query('INSERT INTO `customers` (title, first_name, middle_name, last_name, company, customer_group, delivery_address) VALUES (:title, :firstName, :middleName, :lastName, :customerCompany, :customerGroup, :delivery_address)');
        $this->db->bind(':firstName', $firstName);
        $this->db->bind(':middleName', $middleName);
        $this->db->bind(':lastName', $lastName);
        $this->db->bind(':title', $title);
        $this->db->bind(':delivery_address', $deliveryAddress);
        $this->db->bind(':customerGroup', $customerGroup);
        $this->db->bind(':customerCompany', $customerCompany);
        return $this->db->execute();
    }

    public function addPhoneNumberType($phoneNumberType)
    {
        $this->db->query('INSERT INTO `customer_phone_number_types` (type) VALUES (:type)');
        $this->db->bind(':type', $phoneNumberType);
        return $this->db->execute();
    }

    public function addEmailAddressType($emailAddressType)
    {
        $this->db->query('INSERT INTO `customer_email_address_types` (type) VALUES (:type)');
        $this->db->bind(':type', $emailAddressType);
        return $this->db->execute();
    }

    public function updateCustomer($customer)
    {

        $table = 'customers';
        $columns = $customer;
        $primaryKeyName = 'id';
        $primaryKeyValue = $customer['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updatePhoneNumber($phoneNumber)
    {

        $table = 'customer_phone_numbers';
        $columns = $phoneNumber;
        $primaryKeyName = 'id';
        $primaryKeyValue = $phoneNumber['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updateEmailAddress($emailAddress)
    {

        $table = 'customer_email_addresses';
        $columns = $emailAddress;
        $primaryKeyName = 'id';
        $primaryKeyValue = $emailAddress['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function addCustomerPhoneNumber($customerId,$phoneNumber){
        $table = 'customer_phone_numbers';
        $columns = $phoneNumber;
        $columns['customer_id'] = $customerId;
        return $this->db->insertIntoTable($table,$columns);
    }

    public function addCustomerEmailAddress($customerId,$emailAddress){
        $table = 'customer_email_addresses';
        $columns = $emailAddress;
        $columns['customer_id'] = $customerId;
        return $this->db->insertIntoTable($table,$columns);
    }
    public function deleteCustomerPhoneNumber($phoneNumberId){
        $this->db->query('delete from customer_phone_numbers WHERE id = :phoneNumberId');
        $this->db->bind(':phoneNumberId',$phoneNumberId);
        return $this->db->execute();
    }

    public function deleteCustomer($id)
    {
        $this->db->query('DELETE FROM `customers` WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->execute();
        $this->db->query('delete from customer_phone_numbers WHERE customer_id = :customerId');
        $this->db->bind(':customerId', $id);
        $this->db->execute();
        $this->db->query('delete from customer_email_addresses WHERE customer_id = :customerId');
        $this->db->bind(':customerId', $id);
        return $this->db->execute();
        //todo check if customer corresponds to other things
    }

}