</div>
<footer id="JMVC-footer" class="footer mt-auto">
    <div class="container mr-3">
        <span class="float-md-right d-block d-md-inline-block">Copyright  © 2020 <a class="text-bold-800 grey darken-2" href="http://jaafarnasrallah.com" target="_blank">Jaafar Nasrallah </a>, All rights reserved. </span>
    </div>
</footer>

<script src="<?php echo URLROOT; ?>/public/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/knockout-3.5.1.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/datatables/datatables.min.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/datatables/dataTables.buttons.min.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/toastr.min.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/main.js"></script>
<script src="<?php echo URLROOT; ?>/public/js/sweetalert2@11.js"></script>

<?php
if (isset($template['page_script'])) {
    if (!empty($template['page_script'])) {
        echo '<script src="' . URLROOT . '/public/js/pages/' . $template['page_script'] . '.js"></script>';
    }
}
?>

</body>
</html>