<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 05/03/21
 * Time: 6:16 PM
 */
?>

<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-around">
        <!--        --><?php
        //        $pane_properties = [];
        //        $pane_properties['emptyValueCheck'] = '$root.currentSupplier().name != \'\'';
        //        $pane_properties['formName'] = 'editCurrentSupplierForm';
        //        $pane_properties['title'] = '$root.currentSupplier().name';
        //        $pane_properties['resetFunction'] = '$root.resetCurrentSupplier';
        //        $pane_properties['submitFunction'] = '$root.submitEditSupplier';
        //        $values = [
        //            ['title' => 'name', 'name' => 'name', 'value' => '$root.currentSupplier().name', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
        //            ['title' => 'phoneNumber', 'name' => 'phoneNumber', 'value' => '$root.currentSupplier().phoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'secondaryPhoneNumber', 'name' => 'secondaryPhoneNumber', 'value' => '$root.currentSupplier().secondaryPhoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'emailAddress', 'name' => 'emailAddress', 'value' => '$root.currentSupplier().emailAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'deliveryAddress', 'name' => 'deliveryAddress', 'value' => '$root.currentSupplier().deliveryAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'DELETE', 'name' => 'delete','buttonClass'=>'btn btn-danger w-50', 'type' => 'button','enable'=>'true','buttonClick'=>'$root.deleteCurrentSupplier', 'enableHandle' => '$root.currentSupplier().enableDelete', 'required' => 'false']
        //
        //        ];
        //        $pane_properties['values'] = $values;
        //        include(APPROOT . '/views/partials/_small_object_details_pane.php');;
        //        ?>

        <div class="col-md-8 col-lg-8 col-sm-12">
            <div id="suppliers_table_container" class="col-12">
                <?php
                $table_columns = ['Full Name', 'Phone Number', "Company"];
                $table_properties = ["tableId" => "datatable_suppliers", "title" => 'Suppliers', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

<!--
firstName
middleName
lastName
title
deliveryAddress
supplierGroup
supplierCompany
-->

<?php
$pane_properties = [];
$pane_properties['formName'] = 'addSupplierForm';
$pane_properties['title'] = 'Supplier';
$pane_properties['modalTitle'] = 'Add Supplier';
$pane_properties['itemName'] = 'Supplier';
$values = [
    ['title' => 'First Name',
        'name' => 'firstName',
        'value' => '$root.newSupplier().firstName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Middle Name',
        'name' => 'middleName',
        'value' => '$root.newSupplier().middleName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Last Name',
        'name' => 'lastName',
        'value' => '$root.newSupplier().lastName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.newSupplier().supplierTitle',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierTitles',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Title',
        'required' => 'true'],

    ['title' => 'Delivery Address',
        'name' => 'address',
        'value' => '$root.newSupplier().address',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Job',
        'name' => 'supplierJob',
        'value' => '$root.newSupplier().supplierJob',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierJobs',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Job',
        'required' => 'false'],

    ['title' => 'Group',
        'name' => 'supplierGroup',
        'value' => '$root.newSupplier().supplierGroup',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierGroups',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Group',
        'required' => 'false'],

    ['title' => 'Company',
        'name' => 'supplierCompany',
        'value' => '$root.newSupplier().supplierCompany',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierCompanies',
        'caption' => 'Choose Company',
        'optionsValue' => 'id',
        'optionsText' => 'name',
        'required' => 'false'],


];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');;
?>






<?php
$pane_properties = [];
$pane_properties['formName'] = 'editCurrentSupplierForm';
$pane_properties['title'] = '$root.currentSupplier().firstName()';
$pane_properties['modalTitle'] = '$root.currentSupplier().displayName()';
$pane_properties['itemName'] = 'Supplier';
$pane_properties['modalSizeClass'] = 'modal-xl';
$pane_properties['emptyValueCheck'] = '$root.currentSupplier().firstName != \'\'';
$pane_properties['formName'] = 'editCurrentSupplierForm';
$pane_properties['resetFunction'] = '$root.resetCurrentSupplier';
$pane_properties['submitFunction'] = '$root.submitEditSupplier';
//can set $pane_properties['modalId'] or else it will be edit_modalitem_modal
$values = [
    ['title' => 'First Name',
        'name' => 'firstName',
        'value' => '$root.currentSupplier().firstName',
        'type' => 'text', 'enable' => 'false',
        'required' => 'true'
    ],
    ['title' => 'Middle Name',
        'name' => 'middleName',
        'value' => '$root.currentSupplier().middleName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Last Name',
        'name' => 'lastName',
        'value' => '$root.currentSupplier().lastName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.currentSupplier().supplierTitle',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierTitles',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Title',
        'required' => 'true'],

    ['title' => 'Delivery Address',
        'name' => 'address',
        'value' => '$root.currentSupplier().address',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Job',
        'name' => 'supplierJob',
        'value' => '$root.currentSupplier().supplierJob',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierJobs',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Job',
        'required' => 'false'],

    ['title' => 'Group',
        'name' => 'supplierGroup',
        'value' => '$root.currentSupplier().supplierGroup',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierGroups',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Group',
        'required' => 'false'],

    ['title' => 'Company',
        'name' => 'supplierCompany',
        'value' => '$root.currentSupplier().supplierCompany',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.supplierCompanies',
        'caption' => 'Choose Company',
        'optionsValue' => 'id',
        'optionsText' => 'name',
        'required' => 'false'],
    ['title' => 'Phone Numbers',
        'name' => 'phoneNumbers',
        'buttonClass' => 'btn btn-bdesign-primary w-80 product-type-field-values-button',
        'type' => 'button',
        'noNewRow' => 'true',
        'colSize' => 'col-6',
        'enable' => 'false',
        'buttonClick' => '$root.showSupplierPhoneNumbersModal',
//        'attributes' => 'data-bs-target="#supplierPhoneNumbersModal" data-bs-toggle="modal" data-bs-dismiss="modal"',
//        'enableHandle' => '$root.currentField().isBound()',
        'required' => 'false'],
    ['title' => 'Email Addresses',
        'name' => 'emailAddresses',
        'buttonClass' => 'btn btn-bdesign-primary w-80 product-type-field-values-button',
        'oldRow' => 'true',
        'colSize' => 'col-6',
        'type' => 'button',
        'enable' => 'false',
        'buttonClick' => '$root.showSupplierEmailAddressesModal',
//        'attributes' => 'data-bs-target="#supplierPhoneNumbersModal" data-bs-toggle="modal" data-bs-dismiss="modal"',
//        'enableHandle' => '$root.currentField().isBound()',
        'required' => 'false'],
    ['title' => 'DELETE',
        'name' => 'delete',
        'buttonClass' => 'btn btn-danger w-25',
        'type' => 'button',
        'enable' => 'true',
        'buttonClick' => '$root.deleteCurrentSupplier',
        'enableHandle' => '$root.currentSupplier().enableDelete',
        'required' => 'false']

];
$pane_properties['values'] = $values;
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_object_details_modal.php');;
?>

<!--Phone Numbers Modal-->
<div id="supplierPhoneNumbersModal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="supplierPhoneNumbersLabel">Phone Numbers</h5>
                <button type="button" class="close" data-bind="click:$root.hideSupplierPhoneNumbersModal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <!--ko if : $root.currentSupplier().firstName != ''-->
                    <div class="row justify-content-around">
                        <div class="col-12">
                            <form id="supplierPhoneNumbersForm">
                                <table class="table-hover">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th></th>
                                        <th>Country Code</th>
                                        <th></th>
                                        <th>Area Code</th>
                                        <th></th>
                                        <th>Subscriber Number</th>
                                        <th></th>
                                        <th>Extension</th>
                                    </tr>
                                    </thead>
                                    <tbody style="user-select: none;" data-bind="foreach : {data : $root.currentSupplier().phoneNumbers, includeDestroyed: false }">
                                    <tr>
                                        <td>
                                            <!--                                        <input type="text" class="form-control" data-bind="textInput:$data.countryCode">-->
                                            <select class="form-control-sm" data-bind="options:$root.supplierPhoneNumberTypes,value:$data.phoneNumberTypeId,optionsValue:'id',optionsText:'type'"></select>
                                        </td>
                                        <td>
                                            <button class="btn-info btn-sm" data-bind="click:$root.addSupplierPhoneNumberType"><span class="fa fa-plus"></span></button>
                                        </td>
                                        <td>
                                            <select class="form-control-sm" data-bind="options:$root.phoneNumberCountryCodes,value:$data.countryCode,optionsValue:'id',optionsText:'displayName'"></select>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input style="min-width: 3rem;" type="text" class="form-control" data-bind="textInput:$data.areaCode" required>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input class="form-control" data-bind="textInput:$data.subscriberNumber" required>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input class="form-control" data-bind="textInput:$data.extension">
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bind="click:$root.currentSupplier().removePhoneNumber">
                                                X
                                            </button>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>
                                            <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentSupplier().addPhoneNumber">
                                                Add Number
                                            </button>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentSupplier().saveSupplierPhoneNumbers">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>

<!--Email Addresses Modal-->
<div id="supplierEmailAddressesModal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="supplierEmailAddressesLabel">Email Addresses</h5>
                <button type="button" class="close" data-bind="click:$root.hideSupplierEmailAddressesModal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <!--ko if : $root.currentSupplier().firstName != ''-->
                    <div class="row justify-content-around">
                        <div class="col-12">
                            <form id="supplierEmailAddressesForm">
                                <table class="table-hover">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>addresses</th>
                                    </tr>
                                    </thead>
                                    <tbody style="user-select: none;" data-bind="foreach : {data : $root.currentSupplier().emailAddresses, includeDestroyed: false }">
                                    <tr>
                                        <td>
                                            <select class="form-control-sm" data-bind="options:$root.supplierEmailAddressTypes,value:$data.emailAddressTypeId,optionsValue:'id',optionsText:'type'"></select>
                                            <button class="btn-info btn-sm" data-bind="click:$root.addSupplierEmailAddressType"><span class="fa fa-plus"></span></button>
                                        </td>
                                        <td style="width: 10%;">

                                        </td>
                                        <td>
                                            <input class="form-control" type="email" data-bind="textInput:$data.emailAddress" required>
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bind="click:$root.currentSupplier().removeEmailAddress">
                                                X
                                            </button>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>
                                            <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentSupplier().addEmailAddress">
                                                Add Address
                                            </button>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentSupplier().saveSupplierEmailAddresses">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>