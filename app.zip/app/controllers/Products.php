<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:40 AM
 */

class Products extends Controller
{
    private $productModel;

    public function __construct()
    {
        $this->productModel = $this->model('Product');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function products()
    {
//        $products = $this->productModel->getAllProducts();
        $data = ['title' => 'Products', 'description' => 'Page for products overview', 'currency' => 'L.L'];
        $template = [];
        $template['page_script'] = 'products';
        $this->view('admin/products', $data, $template);
    }

    public function categories()
    {
//        $products = $this->productModel->getAllProducts();
        $data = ['title' => 'Categories', 'description' => 'Page for Categories overview', 'currency' => 'L.L'];
        $template = [];
        $template['page_script'] = 'categories';
        $this->view('admin/categories', $data, $template);
    }


    public function product($id = null, $tab = 'details')
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        else {
            $product = $this->productModel->getProduct($id);
            $data = ['title' => ucfirst($product->title) . ' Product Page', 'description' => 'Page for Product Details', 'currency' => 'L.L', 'product' => $product, 'tab' => $tab];
            $template = [];
            $template['page_script'] = 'product';
            $this->view('admin/product', $data, $template);
        }
    }

    private function addProduct($product)
    {
        $productPrice = $product['price'];
        unset($product['price']);
        $productId = $this->productModel->addProduct($product);
        return $this->productModel->addProductPrice($productId, $productPrice);
    }

    private function updateProduct($product)
    {
        if (isset($product['price'])) {
            $productPrice = $product['price'];
            unset($product['price']);
            $this->productModel->updateProductPrice($product['id'], $productPrice);
        }

        return $this->productModel->updateProduct($product);
    }

    private function addCategory($category)
    {
        $parentCategory = $this->productModel->getProductCategory($category['parent']);
        $newTier = intval($parentCategory->tier) + 1;
        $category['tier'] = $newTier;
        return $this->productModel->addCategory($category);
    }

    private function deleteProduct($id)
    {
        return $this->productModel->deleteProduct($id['id']);
    }

    private function addProductField($field)
    {
        $result = $this->productModel->addProductField($field);
        echo $result;
    }

    private function updateProductField($field)
    {
        echo $this->productModel->updateProductField($field);
    }

    private function getProductFields($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $fields = $this->productModel->getProductTypeFields($id);
        return $fields;

    }

    private function getProductProcesses($id = null)
    {
//        var_dump(func_get_args());
        if ($id == null) {
            die('invalid parameters');
        }
        $processes = $this->productModel->getProductProcesses($id);
        return $processes;

    }

    private function deleteField($ids)
    {
        $result = $this->productModel->deleteField($ids);
        echo $result;
    }

    private function saveFieldValues($values)
    {
        $result = $this->productModel->saveFieldValues($values);
        echo $result;
    }

    private function getFieldValues($fieldId)
    {
        $result = $this->productModel->getFieldValues($fieldId);
        return $result;
    }
    private function addProductProcess($processType)
    {
        $result = $this->productModel->addProductProcess($processType);
        echo $result;
    }
    private function deleteProcess($id)
    {
        $result = $this->productModel->deleteProcess($id);
        echo $result;
    }
    private function updateProcess($processType)
    {
        echo $this->productModel->updateProcessType($processType);
    }
    public function requests($request)
    {
        switch ($request) {
            case 'getAllProducts':
                echo $this->encode_json(['data' => $this->productModel->getAllProducts()]);
                break;
            case 'getAllProductCategories':
                echo self::encode_json($this->productModel->getAllProductCategories());
                break;
            case 'getProductCategories':

                if (isset(func_get_args()[1])) {
                    if (func_get_args()[1] == 'datatablesEncode') {
                        if (isset(func_get_args()[2])) {
                            $parentId = func_get_args()[2];
                        }
                        else {
                            $parentId = 1;
                        }
                        echo self::datatables_encode($this->productModel->getProductCategories($parentId));
                    }
                    else {
                        $parentId = func_get_args()[1];
                        echo self::encode_json($this->productModel->getProductCategories($parentId));
                    }
                }
                else {
                    if (isset(func_get_args()[1])) {
                        $parentId = func_get_args()[1];
                    }
                    else {
                        $parentId = 1;
                    }
                    echo self::encode_json($this->productModel->getProductCategories($parentId));

                }
                break;
            case 'getProductPrice':
                if (isset($_GET)) {
                    echo self::encode_json($this->productModel->getProductPrice($_GET['productId']));
                }
                else {
                    echo 'invalid parameters';
                }
                break;
            case 'addProductProcess':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addProductProcess($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'addProduct':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addProduct($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addCategory':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addCategory($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'deleteProduct':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->deleteProduct($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'deleteCategory':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->productModel->deleteCategory($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'deleteProcess':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->deleteProcess($_POST);
                }
                else {
                    flash('delete_Process_Type_failed', 'Process Type deletion failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            case 'updateProduct':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->updateProduct($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'updateProcess':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateProcess($_POST);
                }
                else {
                    $this->products();
                }
                break;

            case 'getProductFields':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json(['data' => $this->productModel->getProductFields($id)]);
                    break;
                }
            case 'updateProductField':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateProductField($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'getProductProcesses':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    echo $this->encode_json(['data' => $this->getProductProcesses($id)]);
                    break;
                }
            case 'getFieldsDataTypes':
                echo $this->encode_json($this->productModel->getFieldsDataTypes());
                break;
            case 'saveFieldValues':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->saveFieldValues($_POST);
                }
                else {
                    $this->products();
                }
                break;
            case 'getFieldValues':
                if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                    echo $this->encode_json($this->getFieldValues($_GET['fieldId']));
                }
                else {
                    $this->products();
                }
                break;
            case 'getFieldsTypes':
                echo $this->encode_json($this->productModel->getFieldsTypes());
                break;
            case 'addProductField':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->addProductField($_POST);
                }
                else {
                    //flash('add_product_failed', 'Product addition failed', 'alert alert-danger');
                    $this->products();
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>