from django.contrib import admin
from django.urls import path
from django.conf.urls import url, include
from home import views
from tracker import views
#from django.views.generic import TemplateView
import home, tracker


urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^$',home.views.index, name='index'),
    url(r'^special/', views.special, name='special'),
    url(r'^home/', include('home.urls')),
    url(r'^logout/$', views.user_logout, name="logout"),
    url(r'^tracker/', include('tracker.urls')),
]