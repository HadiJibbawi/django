<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 05/03/21
 * Time: 6:16 PM
 */
?>

<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-around">
        <!--        --><?php
        //        $pane_properties = [];
        //        $pane_properties['emptyValueCheck'] = '$root.currentAgent().name != \'\'';
        //        $pane_properties['formName'] = 'editCurrentAgentForm';
        //        $pane_properties['title'] = '$root.currentAgent().name';
        //        $pane_properties['resetFunction'] = '$root.resetCurrentAgent';
        //        $pane_properties['submitFunction'] = '$root.submitEditAgent';
        //        $values = [
        //            ['title' => 'name', 'name' => 'name', 'value' => '$root.currentAgent().name', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
        //            ['title' => 'phoneNumber', 'name' => 'phoneNumber', 'value' => '$root.currentAgent().phoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'secondaryPhoneNumber', 'name' => 'secondaryPhoneNumber', 'value' => '$root.currentAgent().secondaryPhoneNumber', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'emailAddress', 'name' => 'emailAddress', 'value' => '$root.currentAgent().emailAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'deliveryAddress', 'name' => 'deliveryAddress', 'value' => '$root.currentAgent().deliveryAddress', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
        //            ['title' => 'DELETE', 'name' => 'delete','buttonClass'=>'btn btn-danger w-50', 'type' => 'button','enable'=>'true','buttonClick'=>'$root.deleteCurrentAgent', 'enableHandle' => '$root.currentAgent().enableDelete', 'required' => 'false']
        //
        //        ];
        //        $pane_properties['values'] = $values;
        //        include(APPROOT . '/views/partials/_small_object_details_pane.php');;
        //        ?>

        <div class="col-md-8 col-lg-8 col-sm-12">
            <div id="agents_table_container" class="col-12">
                <?php
                $table_columns = ['Full Name', 'Phone Number', "Company"];
                $table_properties = ["tableId" => "datatable_agents", "title" => 'Agents', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

<!--
firstName
middleName
lastName
title
deliveryAddress
agentGroup
agentCompany
-->

<?php
$pane_properties = [];
$pane_properties['formName'] = 'addAgentForm';
$pane_properties['title'] = 'Agent';
$pane_properties['modalTitle'] = 'Add Agent';
$pane_properties['itemName'] = 'Agent';
$values = [
    ['title' => 'First Name',
        'name' => 'firstName',
        'value' => '$root.newAgent().firstName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Middle Name',
        'name' => 'middleName',
        'value' => '$root.newAgent().middleName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Last Name',
        'name' => 'lastName',
        'value' => '$root.newAgent().lastName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.newAgent().agentTitle',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentTitles',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Title',
        'required' => 'true'],

    ['title' => 'Delivery Address',
        'name' => 'address',
        'value' => '$root.newAgent().address',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Job',
        'name' => 'agentJob',
        'value' => '$root.newAgent().agentJob',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentJobs',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Job',
        'required' => 'false'],

    ['title' => 'Group',
        'name' => 'agentGroup',
        'value' => '$root.newAgent().agentGroup',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentGroups',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Group',
        'required' => 'false'],

    ['title' => 'Company',
        'name' => 'agentCompany',
        'value' => '$root.newAgent().agentCompany',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentCompanies',
        'caption' => 'Choose Company',
        'optionsValue' => 'id',
        'optionsText' => 'name',
        'required' => 'false'],


];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');;
?>






<?php
$pane_properties = [];
$pane_properties['formName'] = 'editCurrentAgentForm';
$pane_properties['title'] = '$root.currentAgent().firstName()';
$pane_properties['modalTitle'] = '$root.currentAgent().displayName()';
$pane_properties['itemName'] = 'Agent';
$pane_properties['modalSizeClass'] = 'modal-xl';
$pane_properties['emptyValueCheck'] = '$root.currentAgent().firstName != \'\'';
$pane_properties['formName'] = 'editCurrentAgentForm';
$pane_properties['resetFunction'] = '$root.resetCurrentAgent';
$pane_properties['submitFunction'] = '$root.submitEditAgent';
//can set $pane_properties['modalId'] or else it will be edit_modalitem_modal
$values = [
    ['title' => 'First Name',
        'name' => 'firstName',
        'value' => '$root.currentAgent().firstName',
        'type' => 'text', 'enable' => 'false',
        'required' => 'true'
    ],
    ['title' => 'Middle Name',
        'name' => 'middleName',
        'value' => '$root.currentAgent().middleName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Last Name',
        'name' => 'lastName',
        'value' => '$root.currentAgent().lastName',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.currentAgent().agentTitle',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentTitles',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Title',
        'required' => 'true'],

    ['title' => 'Delivery Address',
        'name' => 'address',
        'value' => '$root.currentAgent().address',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Job',
        'name' => 'agentJob',
        'value' => '$root.currentAgent().agentJob',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentJobs',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Job',
        'required' => 'false'],

    ['title' => 'Group',
        'name' => 'agentGroup',
        'value' => '$root.currentAgent().agentGroup',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentGroups',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Group',
        'required' => 'false'],

    ['title' => 'Company',
        'name' => 'agentCompany',
        'value' => '$root.currentAgent().agentCompany',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.agentCompanies',
        'caption' => 'Choose Company',
        'optionsValue' => 'id',
        'optionsText' => 'name',
        'required' => 'false'],
    ['title' => 'Phone Numbers',
        'name' => 'phoneNumbers',
        'buttonClass' => 'btn btn-bdesign-primary w-80 product-type-field-values-button',
        'type' => 'button',
        'noNewRow' => 'true',
        'colSize' => 'col-6',
        'enable' => 'false',
        'buttonClick' => '$root.showAgentPhoneNumbersModal',
//        'attributes' => 'data-bs-target="#agentPhoneNumbersModal" data-bs-toggle="modal" data-bs-dismiss="modal"',
//        'enableHandle' => '$root.currentField().isBound()',
        'required' => 'false'],
    ['title' => 'Email Addresses',
        'name' => 'emailAddresses',
        'buttonClass' => 'btn btn-bdesign-primary w-80 product-type-field-values-button',
        'oldRow' => 'true',
        'colSize' => 'col-6',
        'type' => 'button',
        'enable' => 'false',
        'buttonClick' => '$root.showAgentEmailAddressesModal',
//        'attributes' => 'data-bs-target="#agentPhoneNumbersModal" data-bs-toggle="modal" data-bs-dismiss="modal"',
//        'enableHandle' => '$root.currentField().isBound()',
        'required' => 'false'],
    ['title' => 'DELETE',
        'name' => 'delete',
        'buttonClass' => 'btn btn-danger w-25',
        'type' => 'button',
        'enable' => 'true',
        'buttonClick' => '$root.deleteCurrentAgent',
        'enableHandle' => '$root.currentAgent().enableDelete',
        'required' => 'false']

];
$pane_properties['values'] = $values;
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_object_details_modal.php');;
?>

<!--Phone Numbers Modal-->
<div id="agentPhoneNumbersModal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="agentPhoneNumbersLabel">Phone Numbers</h5>
                <button type="button" class="close" data-bind="click:$root.hideAgentPhoneNumbersModal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <!--ko if : $root.currentAgent().firstName != ''-->
                    <div class="row justify-content-around">
                        <div class="col-12">
                            <form id="agentPhoneNumbersForm">
                                <table class="table-hover">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th></th>
                                        <th>Country Code</th>
                                        <th></th>
                                        <th>Area Code</th>
                                        <th></th>
                                        <th>Subscriber Number</th>
                                        <th></th>
                                        <th>Extension</th>
                                    </tr>
                                    </thead>
                                    <tbody style="user-select: none;" data-bind="foreach : {data : $root.currentAgent().phoneNumbers, includeDestroyed: false }">
                                    <tr>
                                        <td>
                                            <!--                                        <input type="text" class="form-control" data-bind="textInput:$data.countryCode">-->
                                            <select class="form-control-sm" data-bind="options:$root.agentPhoneNumberTypes,value:$data.phoneNumberTypeId,optionsValue:'id',optionsText:'type'"></select>
                                        </td>
                                        <td>
                                            <button class="btn-info btn-sm" data-bind="click:$root.addAgentPhoneNumberType"><span class="fa fa-plus"></span></button>
                                        </td>
                                        <td>
                                            <select class="form-control-sm" data-bind="options:$root.phoneNumberCountryCodes,value:$data.countryCode,optionsValue:'id',optionsText:'displayName'"></select>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input style="min-width: 3rem;" type="text" class="form-control" data-bind="textInput:$data.areaCode" required>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input class="form-control" data-bind="textInput:$data.subscriberNumber" required>
                                        </td>
                                        <td>
                                            <span> - </span>
                                        </td>
                                        <td>
                                            <input class="form-control" data-bind="textInput:$data.extension">
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bind="click:$root.currentAgent().removePhoneNumber">
                                                X
                                            </button>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>
                                            <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentAgent().addPhoneNumber">
                                                Add Number
                                            </button>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentAgent().saveAgentPhoneNumbers">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>

<!--Email Addresses Modal-->
<div id="agentEmailAddressesModal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="agentEmailAddressesLabel">Email Addresses</h5>
                <button type="button" class="close" data-bind="click:$root.hideAgentEmailAddressesModal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <!--ko if : $root.currentAgent().firstName != ''-->
                    <div class="row justify-content-around">
                        <div class="col-12">
                            <form id="agentEmailAddressesForm">
                                <table class="table-hover">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>addresses</th>
                                    </tr>
                                    </thead>
                                    <tbody style="user-select: none;" data-bind="foreach : {data : $root.currentAgent().emailAddresses, includeDestroyed: false }">
                                    <tr>
                                        <td>
                                            <select class="form-control-sm" data-bind="options:$root.agentEmailAddressTypes,value:$data.emailAddressTypeId,optionsValue:'id',optionsText:'type'"></select>
                                            <button class="btn-info btn-sm" data-bind="click:$root.addAgentEmailAddressType"><span class="fa fa-plus"></span></button>
                                        </td>
                                        <td style="width: 10%;">

                                        </td>
                                        <td>
                                            <input class="form-control" type="email" data-bind="textInput:$data.emailAddress" required>
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bind="click:$root.currentAgent().removeEmailAddress">
                                                X
                                            </button>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>
                                            <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentAgent().addEmailAddress">
                                                Add Address
                                            </button>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentAgent().saveAgentEmailAddresses">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>