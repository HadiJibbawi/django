<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 09/05/20
 * Time: 12:57 AM
 */
?>

<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row">

        <div class="col-3 mt-5 ml-5">
            <div class="card shadow" style="height: 100%;">
                <div class="card-body">
                    <!--ko if : $root.productTitle().title != '' -->
                    <form id="editCurrentproductTypeForm">
                        <h3 style="height: 3rem;" id="current_title" class="m-3" data-bind="text :$root.currentUser().name.charAt(0).toUpperCase() + $root.currentUser().name.slice(1)"></h3>


                        <!--ko if : $root.currentUser().userName != '' -->
                        <span style="font-size: 1rem;font-weight: bold;margin-top: 10rem">Username :</span>
                        <input data-bind="textInput : $root.currentUser().userName" class="form-control mb-4">
                        <!-- /ko -->


                        <!--ko if : $root.currentUser().userName != '' -->
                        <span style="font-size: 1rem;font-weight: bold;">Name :</span>
                        <input data-bind="textInput :  $root.currentUser().name" class="form-control mb-4">
                        <!-- /ko -->


                        <!--ko if : $root.currentUser().userName != '' -->
                        <span style="font-size: 1rem;font-weight: bold">Role :</span>
                        <select class="form-control mb-4" name="category" id="current_user_role" data-bind="options : $root.userRoles,value:$root.currentUser().roleId,optionsValue : 'id',optionsText:'name',optionsCaption:'Choose Role'"></select>
                        <!--                            <span data-bind="text : $root.currentUser().order" class="mt-2"></span>-->
                        <!-- /ko -->
                        <div class="row">
                            <div class="col-6">
                                <!--ko if : $root.currentUser().userName != '' -->
                                <label for="currentUserPassword" style="font-size: 1rem;font-weight: bold">Password :</label>
                                <div>
                                    <label for="changeUserPasswordCheck" style="font-size: 1rem;font-weight: bold;">Reset :</label>
                                    <input id="changeUserPasswordCheck" type="checkbox" data-bind="checked: $root.currentUser().changePass">
                                </div>
                                <input id="currentUserPassword" type="password" data-bind="textInput:$root.currentUser().password,enable:$root.currentUser().changePass()" class="passwordcheck form-control mb-4 " required>
                                <!-- /ko -->
                            </div>
                            <div class="col-6">
                                <!--ko if : $root.currentUser().userName != '' -->
                                <label for="deleteCurrentUser" style="font-size: 1rem;font-weight: bold">DELETE :</label>
                                <div>
                                    <label for="deleteCurrentUserCheck" style="font-size: 1rem;font-weight: bold;">Enable :</label>
                                    <input id="deleteCurrentUserCheck" type="checkbox" data-bind="checked: $root.currentUser().changePass">
                                </div>
                                <button type="button" class="btn btn-danger" id="submitEditUser" data-bind="click:$root.deleteCurrentUser,enable:$root.currentUser().changePass()">Delete</button>
                                <!-- /ko -->
                            </div>
                        </div>
                        <div class="row justify-content-around">
                            <div class="col-4 d-flex justify-content-start">
                                <button type="button" class="btn btn-secondary" id="clearEditUser" data-bind="click:$root.clearCurrentUserEdits">Clear</button>
                            </div>
                            <div class="col-4"></div>
                            <div class="col-4 d-flex justify-content-end ">
                                <button type="button" class="btn btn-success" id="submitEditUser" data-bind="click:$root.submitCurrentUserEdits">Submit</button>
                            </div>

                        </div>
                    </form>
                    <!-- /ko -->
                </div>
            </div>
        </div>
        <div class="col-8">
            <div id="users_table_container" class="col-11">
                <?php
                $table_columns = ['Username', 'Name', "Role"];
                $table_properties = ["tableId" => "datatable_users", "title" => 'Users', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

<!--Add User Modal-->
<div id="new_user_modal" class="modal show" style="z-index: 1110;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="new_user_modal_label">New User</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addUserForm" autocomplete="off">
                    <div class="form-group">
                        <label for="new_user_username">User Name</label>
                        <input id="new_user_username" autocomplete="new-password" name="username" data-bind="textInput :  $root.newUserUsername,attr : {'placeholder' : 'UserName'}" class="form-control" type="text" required/>
                        <label for="new_user_name">Name</label>
                        <input id="new_user_name" autocomplete="new-password" name="name" data-bind="textInput :  $root.newUserName,attr : {'placeholder' : 'Name'}" class="form-control" type="text" required/>
                        <label for="new_user_password">Password</label>
                        <input id="new_user_password" autocomplete="new-password" name="password" pattern=".{0}|.{8,}" data-bind="textInput :  $root.newUserPassword,attr : {'placeholder' : 'Password should be 8 or more characters'}" class="form-control passwordcheck" type="password" required/>
                        <label for="new_user_role">Role</label>
                        <select class="form-control" name="category" id="new_user_role" data-bind="options : $root.userRoles,value:$root.newUserRoleId,optionsValue : 'id',optionsText:'name',optionsCaption:'Choose Role'" required></select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewUserModal">Clear</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button id="save_new_user_btn" type="button" data-bind="click:$root.addUser" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>