<?php

class User
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllUsers()
    {
        $this->db->query('SELECT u.id,u.user_name AS userName, u.name, u.role AS roleId, r.name AS roleName FROM `users` u LEFT JOIN `roles` r ON u.role = r.id');
        $users = $this->db->resultSet();
        return $users;
    }

    public function getUserRoles()
    {
        $this->db->query('SELECT id,name,description FROM `roles`');
        $roles = $this->db->resultSet();
        return $roles;
    }

    public function addUser($user)
    {
        $userName = $user['userName'];
        $name = $user['name'];
        $roleId = $user['roleId'];
        $password = hash('md5', $user['tempPassword']);
        $this->db->query('INSERT INTO users (id,user_name, name,password, role) VALUES (NULL,:userName,:name,:password,:role)');
        $this->db->bind(':userName', $userName);
        $this->db->bind(':name', $name);
        $this->db->bind(':password', $password);
        $this->db->bind(':role', $roleId);

        // Execute
        if ($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    }

    public function deleteUser($id)
    {
        $this->db->query('DELETE FROM `users` WHERE id = :id');
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function updateTable($table,$columns,$primaryKeyName,$primaryKeyValue)
    {

//        $params = ['table'=>'mytable','columns'=>[["user_name" => "newusername"], ["name" => "newname"]]];
        if (sizeof($columns) > 0) {
            $query = "UPDATE " . $table . ' SET ';

            foreach ($columns as $key => $value) {
                $query .= '`' . $key . '` = \'' . $value . '\' , ';
            }
            $query =  substr($query, 0, -2);
            $query .= 'WHERE `'. $primaryKeyName .'` = :primaryKeyValue';

            $this->db->query($query);
            $this->db->bind(':primaryKeyValue',$primaryKeyValue);
            // Execute
            if ($this->db->execute()) {
                return true;
            }
            else {
                return false;
            }

        }
        else {
            return 'empty columns';
        }
    }

    public function updateUser($user)
    {

        $table = 'users';
        $columns = $user;
        $primaryKeyName = 'id';
        $primaryKeyValue = $user['id'];

        return $this->updateTable($table,$columns,$primaryKeyName,$primaryKeyValue);
        //$this->db->query('UPDATE `users` SET `user_name` = :username,`name` = :name,`role` = :roleId,`password` = :password');
    }

    // Find user by name
    public function findUserByName($name)
    {
        $this->db->query('SELECT * FROM users WHERE name = :name');
        $this->db->bind(':name', $name);

        $row = $this->db->single();

        // Check row
        if ($this->db->rowCount() > 0) {
            return $row->date_created;
        }
        else {
            return false;
        }
    }

    //register employee car
    public function registerCar($name, $isEven)
    {
        $this->db->query('INSERT INTO users (id, name, is_even) VALUES (NULL,:name,:is_even)');
        $this->db->bind(':name', $name);
        $this->db->bind(':is_even', $isEven);

        // Execute
        if ($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    }

    // Find if admin exists
    public function SearchAdminByUsername($credentials)
    {
//        $this->db->query('SELECT id FROM privileges WHERE privilege=\'admin\'');
//        $admin_privilege_id = $this->db->single()->id;

        $this->db->query('SELECT id FROM users WHERE user_name = :username');
        $this->db->bind(':username', $credentials['username']);
//        $this->db->bind(':privilege', 2);

        $row = $this->db->single();

        // Check row
        if ($this->db->rowCount() > 0) {
            return $row;
        }
        else {
            return false;
        }
    }

    // validate admin credentials
    public function verifyAdminLogin($credentials)
    {
        $this->db->query('SELECT id,user_name as userName FROM users WHERE user_name = :username && password = :password');
        $this->db->bind(':username', $credentials['username']);
        $this->db->bind(':password', hash('md5', $credentials['password']));

        $row = $this->db->single();

        // Check row
        if ($this->db->rowCount() > 0) {
            return $row;
        }
        else {
            return false;
        }
    }

    // get all employees
    public function getAllEmployees()
    {
        $this->db->query('SELECT `e`.`id`,`e`.`name` AS name,`u`.`name` AS unit,`c`.`value` AS car FROM `employees` e LEFT JOIN `units` u ON e.`unit` = u.`id` LEFT JOIN `car_status` c ON e.`car_plate` = c.id ORDER BY e.`unit`;');
        $users = $this->db->resultSet();
        return $users;
    }

}