<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 08/05/21
 * Time: 5:11 AM
 */
?>


    <div class="container-fluid" style="margin-bottom: 5rem">
        <div class="row justify-content-around">

            <div class="col-12">
                <div id="categories_table_container" class="col-12">
                    <?php
                    $table_columns = ['Title', 'Description', "Tier","Details"];
                    $table_properties = ["tableId" => "datatable_categories", "title" => 'Categories', 'title-size' => 'h3'];
                    include(APPROOT . '/views/partials/_datatable_full_generic.php');
                    ?>
                </div>
            </div>
        </div>
    </div>


<?php
$pane_properties = [];
$pane_properties['formName'] = 'addCategoryForm';
$pane_properties['title'] = 'Category';
$pane_properties['modalTitle'] = 'Add Category';
$pane_properties['itemName'] = 'Category';
$values = [
    ['title' => 'title',
        'name' => 'title',
        'value' => '$root.newCategory().title',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Description',
        'name' => 'description',
        'value' => '$root.newCategory().description',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Parent',
        'name' => 'parent',
        'value' => '$root.newCategory().parent',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.productCategories',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Parent',
        'required' => 'false']

];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');
?>

<?php
$pane_properties = [];
$pane_properties['formName'] = 'editCurrentCategoryForm';
$pane_properties['title'] = '$root.currentCategory().title()';
$pane_properties['modalTitle'] = '$root.currentCategory().title()';
$pane_properties['itemName'] = 'Category';
$pane_properties['modalSizeClass'] = 'modal-xl';
$pane_properties['emptyValueCheck'] = '$root.currentCategory().id() != \'\'';
$pane_properties['formName'] = 'editCurrentCategoryForm';
$pane_properties['resetFunction'] = '$root.resetCurrentCategory';
$pane_properties['submitFunction'] = '$root.submitEditCategory';


$values = [
    ['title' => 'title',
        'name' => 'title',
        'value' => '$root.currentCategory().title',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Description',
        'name' => 'description',
        'value' => '$root.currentCategory().description',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Parent',
        'name' => 'parent',
        'value' => '$root.currentCategory().parent',
        'type' => 'select',
        'enable' => 'false',
        'options' => '$root.productCategories',
        'optionsValue' => 'id',
        'optionsText' => 'title',
        'caption' => 'Choose Parent',
        'required' => 'false']
//    ,
//    ['title' => 'DELETE',
//        'name' => 'delete',
//        'buttonClass' => 'btn btn-danger w-50',
//        'type' => 'button',
//        'enable' => 'true',
//        'buttonClick' => '$root.deleteCurrentCategory',
//        'enableHandle' => '$root.currentCategory().enableDelete',
//        'required' => 'false']

];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_object_details_modal.php');
?>