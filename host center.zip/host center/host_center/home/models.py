from django.db import models
from django.contrib.auth.models import User


class Division(models.Model):
    division_name = models.CharField(max_length=200)
    def __str__(self):
        return self.division_name
        
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    work_number = models.IntegerField()
    gender = models.CharField(max_length=6)
    division = models.ForeignKey(Division,on_delete=models.CASCADE)
    extension = models.IntegerField()
    def __str__(self):
        return self.user.username
 






