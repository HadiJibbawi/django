
<?php //check http://eighthourday.com/studio for inspiration ?>
<div class="container">
    <div class="row">
        <h1 class="display-3"><?php echo $data['title'] ?></h1>
    </div>
        <div class="row">
            <div class="col-6">
        <p class="lead"><?php echo $data['description'] ?></p>
                <p class="lead">Version :<strong><?php echo APPVERSION ?></strong> </p>
            </div>
            <div class="col-6">
                <img src=<?php echo URLROOT . "/img/favicon.ico"?> alt="violet_fashion_logo">
            </div>
    </div>
</div>