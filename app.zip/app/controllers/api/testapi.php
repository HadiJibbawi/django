<?php

class Testapi extends Controller
{
    public function __construct()
    {
        echo 'i\'m in test';

    }
    public function testdapi()
    {
        echo 'i\'m in test method';
    }
}