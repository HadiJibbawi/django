const product_view_model = new productViewModel();
const productId = document.querySelector('#productId').value;
const fieldDataTypeIds = {
    'text': 1,
    'number': 2,
    'date': 3,
    'file': 4

};
const fieldTypeIds = {
    'free': 1,
    'bound': 2
};


function productViewModel() {
    const self = this;

    self.currentFieldRow = ko.observable();
    self.currentProcessRow = ko.observable();

    //-----------------------------PROCESSES TAB AREA--------------------------------------

    self.newProcessTypeTitle = ko.observable();
    self.newProcessTypeDescription = ko.observable('');
    self.newProcessTypeSequence = ko.observable();

    self.currentProcessType = ko.observable({'title': ''});


    self.clearNewProductProcessModal = function () {
        self.newProcessTypeTitle(undefined);
        self.newProcessTypeDescription(undefined);
        self.newProcessTypeSequence(undefined);
    };

    self.deleteCurrentProcessType = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentProcessType().title);
        if (confirmDelete) {
            let deleteRoute = ['products', 'requests', 'deleteProcess'];
            postData(deleteRoute, {
                'processTypeId': self.currentProcessType().id
            }, function (response) {
                if (response == '1') {
                    toastr.success('Process Type Deleted');
                    self.currentProcessType({'title': ''});
                    $('#datatable_processes').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Process Type Deletion Failed');
                }
            });
        }
    };

    self.resetCurrentProcessType = function () {
        let table = $('#datatable_processes').DataTable();
        let data = ko.toJS(table.row(self.currentProcessRow()).data());
        data['enableDelete'] = ko.observable(false);
        product_view_model.currentProcessType(data);
    };

    self.addProductProcess = function () {
        let addProcessTypeForm = $('#addProcessTypeForm');

        if (!addProcessTypeForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addProcessTypeForm).click().remove();
        }
        else {
            let route = ['products', 'requests', 'addProductProcess'];
            let processType = {};
            processType.title = self.newProcessTypeTitle();
            processType.description = self.newProcessTypeDescription();
            processType.sequence = self.newProcessTypeSequence();
            processType.productId = productId;
            postData(route, processType, function (result) {
                if (result == '1') {
                    toastr.success('Process Type Added Successfully');
                    self.clearNewProductProcessModal();
                    let table = $('#datatable_processes').DataTable();
                    table.ajax.reload();
                }
                else {
                    toastr.warning('Process Type Addition Failed');
                }
            });

            $('#add_ProductProcess_modal').modal('hide');

        }
    };

    self.submitEditProcessType = function () {

        let editCurrentProcessTypeForm = $('#editCurrentProcessTypeForm');

        if (!editCurrentProcessTypeForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentProcessTypeForm).click().remove();
        }
        else {

            let route = ['products', 'requests', 'updateProcess'];
            let table = $('#datatable_processes').DataTable();
            let processType = {};
            const originalProcessType = ko.toJS(table.row(self.currentProcessRow()).data());
            const currentProcessType = ko.toJS(self.currentProcessType);
            console.log(originalProcessType);
            console.log(currentProcessType);
            for (const prop in originalProcessType) {
                if (originalProcessType[prop] != currentProcessType[prop]) {
                    processType[prop] = currentProcessType[prop];
                }
            }
            if ($.isEmptyObject(processType)) {
                alert('No changes have been made');
                return;
            }
            processType['id'] = currentProcessType.id;
            processType['productId'] = productId;
            postData(route, processType, function (result) {
                if (result == '1') {
                    toastr.success('Process Type Edited Successfully');
                    let table = $('#datatable_processes').DataTable();
                    table.ajax.reload();
                    self.currentProcessType({'title': ''});
                }
                else {
                    toastr.warning('Process Type Edit Failed');
                }
            });

        }
    };

    //-----------------------------FIELD TAB AREA--------------------------------------
    self.currentField = ko.observable({'title': ''});

    self.newFieldTitle = ko.observable();
    self.newFieldDescription = ko.observable('');
    self.newFieldType = ko.observable();
    self.newFieldDataType = ko.observable();
    self.newFieldEnableType = ko.observable(true);

    self.newFieldDataType.subscribe(function (value) {
        if (value == fieldDataTypeIds['date'] || value == fieldDataTypeIds['file'] ){
            self.newFieldType(fieldTypeIds['free']);
            self.newFieldEnableType(false);
        }
        else{
            self.newFieldEnableType(true);
        }
    });

    self.addProductField = function () {
        let addFieldForm = $('#addCurrentFieldForm');

        if (!addFieldForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addFieldForm).click().remove();
        }
        else {
            let route = ['products', 'requests', 'addProductField'];
            let field = {};
            field.title = self.newFieldTitle();
            field.description = self.newFieldDescription();
            field.typeId = self.newFieldType();
            field.dataTypeId = self.newFieldDataType();
            field.productId = productId;
            postData(route, field, function (result) {
                if (result == '1') {
                    toastr.success('Field Added Successfully');
                    self.clearNewProductFieldModal();
                    let table = $('#datatable_fields').DataTable();
                    table.ajax.reload();
                }
                else {
                    toastr.warning('Field Addition Failed');
                }
            });

            $('#add_ProductField_modal').modal('hide');

        }
    };

    self.clearNewProductFieldModal = function () {
        self.newFieldTitle(undefined);
        self.newFieldDescription(undefined);
        self.newFieldType(undefined);
        self.newFieldDataType(undefined);
    };

    self.deleteCurrentField = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentField().title);
        if (confirmDelete) {
            let deleteRoute = ['admin', 'requests', 'deleteField'];
            postData(deleteRoute, {
                'productFieldId': self.currentField().id,
                'fieldId': self.currentField().fieldId
            }, function (response) {
                if (response == '1') {
                    toastr.success('Field Deleted');
                    self.currentField({'title': ''});
                    $('#datatable_fields').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Field Deletion Failed');
                }
            });
        }
    };

    self.resetCurrentField = function () {
        let table = $('#datatable_fields').DataTable();
        let data = ko.toJS(table.row(self.currentFieldRow()).data());
        product_view_model.currentField(new ProductField(data));
    };

    self.showFieldValuesModal = function () {
        $('#fieldValuesModal').modal('show')
    };

    self.submitEditField = function () {

        let editCurrentFieldForm = $('#editCurrentFieldForm');

        if (!editCurrentFieldForm [0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentFieldForm).click().remove();
        }
        else {

            let route = ['products', 'requests', 'updateProductField'];
            let table = $('#datatable_fields').DataTable();
            let field = {};
            const originalField = ko.toJS(table.row(self.currentFieldRow()).data());
            const currentField = ko.toJS(self.currentField);
            console.log(originalField);
            console.log(currentField);
            for (const prop in originalField) {
                if (originalField[prop] != currentField[prop]) {
                    field[prop] = currentField[prop];
                }
            }
            if ($.isEmptyObject(field)) {
                alert('No changes have been made');
                return;
            }
            field['id'] = currentField.fieldId;
            postData(route, field, function (result) {
                if (result == '1') {
                    toastr.success('Field Edited Successfully');
                    let table = $('#datatable_fields').DataTable();
                    table.ajax.reload();
                    self.currentField({'title': ''});
                }
                else {
                    toastr.warning('Field Edit Failed');
                }
            });

        }
    };


    self.fieldDataTypes = ko.observable();
    self.fieldTypes = ko.observable();

    self.getFieldDataTypes = function () {
        fetchDataJson(['admin', 'requests', 'getFieldsDataTypes'], '', function (data) {
            self.fieldDataTypes(data);
        });
    };
    self.getFieldTypes = function () {
        fetchDataJson(['admin', 'requests', 'getFieldsTypes'], '', function (data) {
            self.fieldTypes(data);
        });
    };
    self.getFieldTypes();
    self.getFieldDataTypes();


}


function ProductField(product) {
    const self = this;

    self.id = product.id;
    self.title = product.title;
    self.description = product.description;
    self.fieldId = product.fieldId
    self.fieldTypeId = ko.observable(product.fieldTypeId);
    self.fieldType = product.fieldType;
    self.fieldDataType = product.fieldDataType;
    self.fieldDataTypeId = ko.observable(product.fieldDataTypeId);
    self.enableDelete = ko.observable(false);
    self.isBound = ko.computed(function () {
        return self.fieldTypeId() == fieldTypeIds['bound'];
    });

    self.values = ko.observableArray([]);

    self.addValue = function () {
        self.values.push(new ProductFieldValue({'id': '0', 'value': ''}));
    };
    self.removeValue = function (value) {
        self.values.destroy(value);
    };
    self.saveValues = function () {
        let route = ['products', 'requests', 'saveFieldValues'];
        let data = {};
        data['fieldId'] = product_view_model.currentField().fieldId;
        data['values'] = ko.toJS(self.values());
        console.log(data);
        postData(route, data, function (result) {
            if (result == '1') {
                toastr.success('values Saved Successfully');
                $('#fieldValuesModal').modal('hide');
            }
            else {
                toastr.warning('Values Save Failed');
            }
        });
    };

    self.getValues = function () {
        let route = ['products', 'requests', 'getFieldValues'];
        let data = {'fieldId': self.fieldId};
        fetchDataJson(route, data, function (fieldValues) {
            self.values([]);
            $.each(fieldValues, function (index, value) {
                self.values.push(new ProductFieldValue({'id': value['id'], 'value': value['value']}));
            });
        });
    };
    self.getValues();

}

function ProductFieldValue(field) {
    const self = this;

    self.id = field.id;
    self.value = ko.observable(field.value);
}

console.log(productId);

ko.applyBindings(product_view_model);


const productFieldsTableId = 'datatable_fields';
const productFieldsButtonFunc = '$(\'#add_ProductField_modal\').modal(\'show\');';
const productFieldsDomParams = 'lfBrtip';
const productFieldsContentName = 'Fields';
const productFieldsDatatableAjaxRoute = '/products/requests/getProductFields/' + productId;
const productFieldsColumns = [
    {'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']},
    {'data': ['description', 'false']},
    {'data': ['fieldDataType', 'false']},
    {'data': ['fieldType', 'false']}
];

configureDatatable(productFieldsTableId, productFieldsButtonFunc,{}, productFieldsDomParams, productFieldsContentName, productFieldsDatatableAjaxRoute, productFieldsColumns);

const productProcessesTableId = 'datatable_processes';
const productProcessesButtonFunc = '$(\'#add_ProductProcess_modal\').modal(\'show\');';
const productProcessesDomParams = 'lfBrtip';
const productProcessesContentName = 'Processes';
const productProcessesDatatableAjaxRoute = '/products/requests/getProductProcesses/' + productId;
const productProcessesColumns = [
    {'data': ['sequence', 'false']},
    {'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']},
    {'data': ['description', 'false']}
];

configureDatatable(productProcessesTableId, productProcessesButtonFunc,{}, productProcessesDomParams, productProcessesContentName, productProcessesDatatableAjaxRoute, productProcessesColumns, undefined, {
    'columnIndex': 0,
    'order': 'asc'
});

$(document).ready(function () {
    let table = $('#datatable_fields').DataTable();
    let tableProccesses = $('#datatable_processes').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_fields tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_fields tbody').on('click', 'tr', function () {
        product_view_model.currentFieldRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        data['fieldDataTypeId'] = data['fieldDataTypeId'];
        data['fieldTypeId'] = data['fieldTypeId'];
        product_view_model.currentField(new ProductField(data));
        // console.log(product_view_model.currentField());

    });
    // make all table row show pointers on hover
    $.each($('#datatable_processes tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_processes tbody').on('click', 'tr', function () {
        product_view_model.currentProcessRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(tableProccesses.row(this).data());
        data['enableDelete'] = ko.observable(false);
        product_view_model.currentProcessType(data);
        console.log(product_view_model.currentField());

    });

    //this allows for a custom message in case the product enters an invalid password

});


