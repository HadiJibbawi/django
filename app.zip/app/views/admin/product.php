<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 29/04/20
 * Time: 2:40 PM
 */
?>
<input id="productId" type="text" hidden disabled value="<?php echo $data['product']->id; ?>"/>


<div class="container-fluid" style="margin: 5rem 0">
    <div class="card">
        <div class="card-body">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" id="productTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="fields-tab" data-bs-toggle="tab" data-bs-target="#fields" type="button" role="tab" aria-controls="fields" aria-selected="true">Fields</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="processes-tab" data-bs-toggle="tab" data-bs-target="#processes" type="button" role="tab" aria-controls="processes" aria-selected="false">Processes</button>
                </li>

            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane" id="fields" role="tabpanel" aria-labelledby="fields-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="container-fluid" style="margin-bottom: 5rem">
                                <div class="row justify-content-around">

                                    <?php
                                    $pane_properties = [];
                                    $pane_properties['emptyValueCheck'] = '$root.currentField().title != \'\'';
                                    $pane_properties['formName'] = 'editCurrentFieldForm';
                                    $pane_properties['title'] = '$root.currentField().title';
                                    $pane_properties['resetFunction'] = '$root.resetCurrentField';
                                    $pane_properties['submitFunction'] = '$root.submitEditField';
                                    $values = [
                                        ['title' => 'title',
                                            'name' => 'title',
                                            'value' => '$root.currentField().title',
                                            'type' => 'text',
                                            'enable' => 'false',
                                            'required' => 'true'],

                                        ['title' => 'description',
                                            'name' => 'description',
                                            'value' => '$root.currentField().description',
                                            'type' => 'text',
                                            'enable' => 'false',
                                            'required' => 'false'],

                                        ['title' => 'dataType',
                                            'name' => 'dataType',
                                            'value' => '$root.currentField().fieldDataTypeId',
                                            'caption' => 'Choose Data Type',
                                            'type' => 'select',
                                            'enable' => 'false',
                                            'options' => '$root.fieldDataTypes',
                                            'optionsValue' => 'id',
                                            'optionsText' => 'type',
                                            'required' => 'false'],

                                        ['title' => 'fieldType',
                                            'name' => 'fieldType',
                                            'value' => '$root.currentField().fieldTypeId',
                                            'caption' => 'Choose Type',
                                            'type' => 'select',
                                            'enable' => 'false',
                                            'options' => '$root.fieldTypes',
                                            'optionsValue' => 'id',
                                            'optionsText' => 'type',
                                            'required' => 'false'],

                                        ['title' => 'DELETE',
                                            'name' => 'delete',
                                            'noNewRow' => 'true',
                                            'colSize' => 'col-6',
                                            'buttonClass' => 'btn btn-danger w-100',
                                            'type' => 'button',
                                            'enable' => 'true',
                                            'buttonClick' => '$root.deleteCurrentField',
                                            'enableHandle' => '$root.currentField().enableDelete',
                                            'required' => 'true'],

                                        ['title' => 'Values',
                                            'name' => 'values',
                                            'oldRow' => 'true',
                                            'colSize' => 'col-6',
                                            'buttonClass' => 'btn btn-bdesign-primary w-100 product-type-field-values-button',
                                            'type' => 'button',
                                            'enable' => 'false',
                                            'buttonClick' => '$root.showFieldValuesModal',
                                            'enableHandle' => '$root.currentField().isBound()',
                                            'required' => 'false']

                                    ];
                                    $pane_properties['values'] = $values;
                                    include(APPROOT . '/views/partials/_small_object_details_pane.php');;
                                    ?>


                                    <div class="col-8">
                                        <div id="products_table_container" class="col-12">
                                            <?php
                                            $table_columns = ['Title',
 'Description', "Data Type", "Type"];
                                            $table_properties = ["tableId" => "datatable_fields", "title" => 'Product Type Fields', 'title-size' => 'h3'];
                                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane active" id="processes" role="tabpanel" aria-labelledby="processes-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="container-fluid" style="margin-bottom: 5rem">
                                <div class="row justify-content-around">

                                    <?php
                                    $pane_properties = [];
                                    $pane_properties['emptyValueCheck'] = '$root.currentProcessType().title != \'\'';
                                    $pane_properties['formName'] = 'editCurrentProcessTypeForm';
                                    $pane_properties['title'] = '$root.currentProcessType().title';
                                    $pane_properties['resetFunction'] = '$root.resetCurrentProcessType';
                                    $pane_properties['submitFunction'] = '$root.submitEditProcessType';
                                    $values = [
                                        ['title' => 'title', 'name' => 'title', 'value' => '$root.currentProcessType().title', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
                                        ['title' => 'description', 'name' => 'description', 'value' => '$root.currentProcessType().description', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
                                        ['title' => 'sequence', 'name' => 'sequence', 'value' => '$root.currentProcessType().sequence', 'type' => 'number', 'enable' => 'false', 'required' => 'false'],
                                        ['title' => 'DELETE', 'name' => 'delete', 'colSize' => 'col-6', 'buttonClass' => 'btn btn-danger w-100', 'type' => 'button', 'enable' => 'true', 'buttonClick' => '$root.deleteCurrentProcessType', 'enableHandle' => '$root.currentProcessType().enableDelete', 'required' => 'true']

                                    ];
                                    $pane_properties['values'] = $values;
                                    include(APPROOT . '/views/partials/_small_object_details_pane.php');;
                                    ?>


                                    <div class="col-8">
                                        <div id="products_table_container" class="col-12">
                                            <?php
                                            $table_columns = ['Sequence', 'Title', "Description"];
                                            $table_properties = ["tableId" => "datatable_processes", "title" => 'Product Type Processes', 'title-size' => 'h3'];
                                            include(APPROOT . '/views/partials/_datatable_full_generic.php');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
$pane_properties = [];
$pane_properties['formName'] = 'addCurrentFieldForm';
$pane_properties['title'] = 'Field';
$pane_properties['modalTitle'] = 'Add Field';
$pane_properties['itemName'] = 'ProductField';
$values = [
    ['title' => 'title', 'name' => 'title', 'value' => '$root.newFieldTitle', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
    ['title' => 'description', 'name' => 'description', 'value' => '$root.newFieldDescription', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
    ['title' => 'dataType', 'name' => 'dataType', 'value' => '$root.newFieldDataType', 'caption' => 'Choose Data Type', 'type' => 'select', 'enable' => 'false', 'options' => '$root.fieldDataTypes', 'optionsValue' => 'id', 'optionsText' => 'type', 'required' => 'true'],
    ['title' => 'fieldType', 'name' => 'fieldType', 'value' => '$root.newFieldType', 'caption' => 'Choose Type', 'type' => 'select', 'enable' => 'false', 'options' => '$root.fieldTypes', 'optionsValue' => 'id', 'optionsText' => 'type', 'required' => 'true','enableHandle'=>'$root.newFieldEnableType']
];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');;
?>


<?php
$pane_properties = [];
$pane_properties['formName'] = 'addProcessTypeForm';
$pane_properties['title'] = 'Process';
$pane_properties['modalTitle'] = 'Add Process';
$pane_properties['itemName'] = 'ProductProcess';
$values = [
    ['title' => 'title', 'name' => 'title', 'value' => '$root.newProcessTypeTitle', 'type' => 'text', 'enable' => 'false', 'required' => 'true'],
    ['title' => 'description', 'name' => 'description', 'value' => '$root.newProcessTypeDescription', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
    ['title' => 'sequence', 'name' => 'sequence', 'value' => '$root.newProcessTypeSequence', 'caption' => 'Choose Sequence', 'type' => 'number', 'enable' => 'false', 'required' => 'true'],
];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');;

?>


<!--Field Values Modal-->
<div id="fieldValuesModal" class="modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="fieldValuesModalLabel">Values</h5>
                <button type="button" class="close" data-bs-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <!--ko if : $root.currentField().title != ''-->
                    <!--ko if : $root.currentField().isBound() -->
                    <div class="row justify-content-around">
                        <div class="col-6">
                            <table class="table-hover">
                                <thead>
                                <tr>
                                    <th>Value</th>
                                </tr>
                                </thead>
                                <tbody data-bind="foreach : {data : $root.currentField().values, includeDestroyed: false }">
                                <tr>
                                    <td>
                                        <input class="form-control" data-bind="textInput:$data.value,attr:{'type':$root.currentField().fieldDataType},enable:( $data.id == '0')">
                                    </td>
                                    <td>
                                        <button class="btn btn-danger btn-sm" data-bind="click:$root.currentField().removeValue">
                                            X
                                        </button>
                                    </td>
                                </tr>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <td>
                                        <button class="btn btn-bdesign-primary btn-sm" data-bind="click:$root.currentField().addValue">
                                            Add Value
                                        </button>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /ko -->
                    <!-- /ko -->
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success " data-bind="click:$root.currentField().saveValues">
                        Save
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
