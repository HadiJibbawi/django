const orders_view_model = new ordersViewModel();

function ordersViewModel() {
    const self = this;

    self.currentOrder = ko.observable({'id': ''});


}

ko.applyBindings(orders_view_model);


const ordersTableId = 'datatable_orders';
const ordersButtonFunc = '$(\'#new_product_type_modal\').modal(\'show\');';
const ordersContentName = 'Order';
const ordersDomParams = 'lfrtip';
const ordersDatatableAjaxRoute = '/sales/requests/getOrders';
// const ordersColumns = [{'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']}, {'data': ['description', 'false']}, {'defaultContent': '<button  onclick="openGenericItemDetails(this)" class="btn btn-bdesign-primary btn-sm"> Details <span class="fa fa-share-square"> </span></button>'}];
const ordersColumns = [
    {'data': ['id', 'false']},
    {'data': [null, '((row.customerTitle) + ". " + (row.customerFirstName.charAt(0).toUpperCase() + row.customerFirstName.slice(1))) + " " + ((row.customerMiddleName.charAt(0).toUpperCase() + row.customerMiddleName.slice(1))) + " " +((row.customerLastName.charAt(0).toUpperCase() + row.customerLastName.slice(1)))']},
    {'data': ['placementDate', 'data.split(" ")[0]']},
    {'data': ['dueDate', 'data.split(" ")[0]']}
];
const columnsSorting = [];
columnsSorting['columnIndex'] = 0;
columnsSorting['order'] = 'desc';
// {'data': ['description', 'false']}];
// {'data': ['id', 'new String(\'<button  onclick="products_view_model.openProductTypePage(\' + data + \')" class="btn btn-bdesign-primary btn-sm"> Details <span class="fa fa-share-square"> </span></button>\')']}];
// const ordersColumns = [{'data': ['productName', 'false']},{'data': ['name', 'false']}];

configureDatatable(ordersTableId, ordersButtonFunc,{}, ordersDomParams, ordersContentName, ordersDatatableAjaxRoute, ordersColumns,10,columnsSorting);

$(document).ready(function () {
    let table = $('#datatable_orders').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_orders tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_orders tbody').on('click', 'tr', function () {
        // orders_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        data['enableDelete'] = ko.observable(false);
        orders_view_model.currentOrder(data);
        console.log(orders_view_model.currentOrder());
        // window.location.href = "http://jaafar:8888/bdesign/operations/workshop/"+data.orderId;
        window.location.href = RootFolderUrl + "/sales/order/"+data.id;

    });

    //this allows for a custom message in case the product enters an invalid password

});



// $table_columns = ['Customer', 'ProductType', "Status"];
// $table_properties = ["tableId" => "datatable_orders", "title" => 'Orders', 'title-size' => 'h3'];