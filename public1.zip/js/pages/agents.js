//id
//name
//phone_number
//secondary_phone_number
//email_address
//delivery_address
//date_created
let agent_view_model;
agent_view_model = new AgentViewModel();

function AgentViewModel() {
    const self = this;

    self.currentRow = ko.observable();
    self.currentAgent = ko.observable({'firstName': ''});

    self.newAgent = ko.observable(new Agent());

    self.agents = ko.observableArray([]);
    self.agentTitles = ko.observableArray([]);
    self.agentJobs = ko.observableArray([]);
    self.agentGroups = ko.observableArray([]);
    self.agentCompanies = ko.observableArray([]);
    self.agentPhoneNumberTypes = ko.observableArray([]);
    self.agentEmailAddressTypes = ko.observableArray([]);
    self.phoneNumberCountryCodes = ko.observableArray([]);


    self.showAgentPhoneNumbersModal = function () {
        $('#agentPhoneNumbersModal').modal('show');
    };
    self.addAgentEmailAddressType = function () {
        let newType = prompt('please enter new email address type');
        let route = ['agents', 'requests', 'addEmailAddressType'];
        postData(route,{data:newType},function (response) {
            if (response == '1') {
                toastr.success('type added');
                self.getAgentEmailAddressTypes();
            }
        })
    };
    self.addAgentPhoneNumberType = function () {
        let newType = prompt('please enter new phone number type');
        let route = ['agents', 'requests', 'addPhoneNumberType'];
        postData(route,{data:newType},function (response) {
            if (response == '1') {
                toastr.success('type added');
                self.getAgentPhoneNumberTypes();
            }
        })
    };
    self.hideAgentPhoneNumbersModal = function () {
        $('#agentPhoneNumbersModal').modal('hide');
    };
    self.showAgentEmailAddressesModal = function () {
        $('#agentEmailAddressesModal').modal('show');
    };
    self.hideAgentEmailAddressesModal = function () {
        $('#agentEmailAddressesModal').modal('hide');
    };
    self.getPhoneNumberCountryCodes = function () {
        let route = ['agents', 'requests', 'getAllPhoneNumberCountryCodes'];
        fetchDataJson(route, {}, function (phoneNumberCountryCodes) {
            $.each(phoneNumberCountryCodes, function (index, code) {
                self.phoneNumberCountryCodes.push(new CountryCode(code));
            });
        });
    };
    self.getPhoneNumberCountryCodes();
    self.getAgentPhoneNumberTypes = function () {
        let route = ['agents', 'requests', 'getAgentPhoneNumberTypes'];
        fetchDataJson(route, {}, function (AgentPhoneNumberTypes) {
            self.agentPhoneNumberTypes(AgentPhoneNumberTypes);
        });
    };

    self.getAgentPhoneNumberTypes();
    self.getAgentJobs = function () {
        let route = ['agents', 'requests', 'getAgentJobs'];
        fetchDataJson(route, {}, function (agentJobs) {
            self.agentJobs(agentJobs);
        });
    };

    self.getAgentJobs();
    self.getAgentEmailAddressTypes = function () {
        let route = ['agents', 'requests', 'getAgentEmailAddressTypes'];
        fetchDataJson(route, {}, function (AgentEmailAddressTypes) {
            self.agentEmailAddressTypes(AgentEmailAddressTypes);
        });
    };
    self.getAgentEmailAddressTypes();

    self.getAgentTitles = function () {
        let route = ['agents', 'requests', 'getAgentTitles'];
        fetchDataJson(route, {}, function (titles) {
            self.agentTitles(titles);
        });
    };
    self.getAgentTitles();

    self.getAgentGroups = function () {
        let route = ['agents', 'requests', 'getAgentGroups'];
        fetchDataJson(route, {}, function (groups) {
            self.agentGroups(groups);
        });
    };
    self.getAgentGroups();

    self.getAgentCompanies = function () {
        let route = ['agents', 'requests', 'getAgentCompanies'];
        fetchDataJson(route, {}, function (companies) {
            self.agentCompanies(companies);
        });
    };
    self.getAgentCompanies();

    self.clearNewAgentModal = function () {
        self.newAgent({});
    };

    self.addAgent = function () {
        let addAgentForm = $('#addAgentForm');

        if (!addAgentForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addAgentForm).click().remove();
        }
        else {
            let route = ['agents', 'requests', 'addAgent'];
            let agent = {};
            agent.firstName = self.newAgent().firstName();
            agent.middleName = self.newAgent().middleName();
            agent.lastName = self.newAgent().lastName();
            agent.agentTitle = self.newAgent().agentTitle();
            agent.address = self.newAgent().address();
            agent.agentJob = self.newAgent().agentJob();
            agent.agentGroup = self.newAgent().agentGroup() == undefined ? 0 : self.newAgent().agentGroup();
            agent.agentCompany = self.newAgent().agentCompany() == undefined ? 0 : self.newAgent().agentCompany();
            postData(route, agent, function (result) {
                if (result == '1') {
                    toastr.success('Agent Added Successfully');
                    self.clearNewAgentModal();
                    $('#datatable_agents').DataTable().ajax.reload();

                }
                else {
                    toastr.warning('Agent Addition Failed');
                }
            });

            $('#add_Agent_modal').modal('hide');

        }
    };

    self.deleteCurrentAgent = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentAgent().displayName());
        if (confirmDelete) {
            let deleteRoute = ['agents', 'requests', 'deleteAgent'];
            postData(deleteRoute, {'id': self.currentAgent().id}, function (response) {
                if (response == '1') {
                    toastr.success('Agent Deleted');
                    $('#edit_Agent_modal').modal('hide');
                    self.currentAgent({'firstName': ''});
                    $('#datatable_agents').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Agent Deletion Failed');
                }
            });
        }
    };

    self.resetCurrentAgent = function () {
        let table = $('#datatable_agents').DataTable();
        let data = ko.toJS(table.row(self.currentRow()).data());
        agent_view_model.currentAgent(new Agent(data));
    };

    self.submitEditAgent = function () {

        let editCurrentAgentForm = $('#editCurrentAgentForm');

        if (!editCurrentAgentForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentAgentForm).click().remove();
        }
        else {
            let route = ['agents', 'requests', 'updateAgent'];
            let table = $('#datatable_agents').DataTable();
            let agent = {};
            const originalAgent = ko.toJS(table.row(self.currentRow()).data());
            const currentAgent = ko.toJS(self.currentAgent);
            console.log(originalAgent);
            console.log(currentAgent);

            for (const prop in originalAgent) {
                if (prop != 'emailAddresses' && prop != 'phoneNumbers' && prop != 'agentGroupId' && prop != 'agentCompanyId' && prop != 'agentTitleId') {
                    if (originalAgent[prop] != currentAgent[prop]) {
                        agent[prop] = currentAgent[prop];
                    }
                }
            }

            if ($.isEmptyObject(agent)) {
                alert('No changes have been made');
                return;
            }
            agent['id'] = originalAgent.id;
            postData(route, agent, function (result) {
                if (result == '1') {
                    toastr.success('Agent Edited Successfully');
                    let table = $('#datatable_agents').DataTable();
                    table.ajax.reload();
                }
                else {
                    toastr.warning('Agent Edit Failed');
                }
            });
        }
    };


}

function Agent(agent) {

    const self = this;

    self.setAgentPhoneNumbers = function () {
        let phoneNumbers = ko.observableArray([]);
        $.each(agent.phoneNumbers, function (index, phoneNumber) {
            phoneNumbers.push(new PhoneNumber(phoneNumber))
        });
        return phoneNumbers;
    };
    self.setAgentEmailAddresses = function () {
        let emailAddresses = ko.observableArray([]);
        $.each(agent.emailAddresses, function (index, emailAddress) {
            emailAddresses.push(new EmailAddress(emailAddress))
        });
        return emailAddresses;
    };

    self.id = agent == undefined ? ko.observable('') : ko.observable(agent.id);
    self.firstName = agent == undefined ? ko.observable('') : ko.observable(agent.firstName);
    self.middleName = agent == undefined ? ko.observable('') : ko.observable(agent.middleName);
    self.lastName = agent == undefined ? ko.observable('') : ko.observable(agent.lastName);
    self.agentTitle = agent == undefined ? ko.observable('') : ko.observable(agent.agentTitleId);
    self.address = agent == undefined ? ko.observable('') : ko.observable(agent.address);
    self.agentGroup = agent == undefined ? ko.observable('') : ko.observable(agent.agentGroupId);
    self.agentCompany = agent == undefined ? ko.observable('') : ko.observable(agent.agentCompanyId);
    self.agentJob = agent == undefined ? ko.observable('') : ko.observable(agent.agentJobId);

    self.phoneNumbers = agent == undefined ? ko.observableArray() : self.setAgentPhoneNumbers();
    self.emailAddresses = agent == undefined ? ko.observableArray() : self.setAgentEmailAddresses();
    self.enableDelete = ko.observable(false);

    self.addPhoneNumber = function () {
        //122 is the id for lebanon
        self.phoneNumbers.push(new PhoneNumber({'id': '0', 'countryCode': 122}));
    };
    self.removePhoneNumber = function (phoneNumber) {
        let confirmDelete = confirm('are you sure you want to delete this phone number?');
        if (confirmDelete) {
            self.phoneNumbers.destroy(phoneNumber);
        }
    };
    self.addEmailAddress = function () {
        //122 is the id for lebanon
        self.emailAddresses.push(new EmailAddress({'id':'0'}));
    };
    self.removeEmailAddress = function (emailAddress) {
        let confirmDelete = confirm('are you sure you want to delete this email address?');
        if (confirmDelete) {
            self.emailAddresses.destroy(emailAddress);
        }
    };

    self.saveAgentPhoneNumbers = function () {
        let savePhoneNumbersForm = $('#agentPhoneNumbersForm');

        if (!savePhoneNumbersForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(savePhoneNumbersForm).click().remove();
        }
        else {
            let route = ['agents', 'requests', 'submitAgentPhoneNumbers'];
            let phoneNumbers = [];
            let table = $('#datatable_agents').DataTable();
            let currentPhoneNumbers = ko.toJS(self.phoneNumbers);
            $.each(currentPhoneNumbers, function (index, phoneNumber) {
                let tempPhoneNumber = {};
                if (phoneNumber.id != 0) {
                    const originalAgent = ko.toJS(table.row(agent_view_model.currentRow()).data());
                    let originalPhoneNumber = ko.utils.arrayFirst(originalAgent.phoneNumbers, function (originalNumber) {
                        return originalNumber.id == phoneNumber.id;
                    });
                    for (const prop in phoneNumber) {

                        if (originalPhoneNumber[prop] != phoneNumber[prop]) {
                            if (tempPhoneNumber.id == undefined) {
                                tempPhoneNumber.id = phoneNumber.id;
                            }
                            tempPhoneNumber[prop] = phoneNumber[prop];
                        }
                    }
                }
                else {
                    tempPhoneNumber = phoneNumber;
                }
                phoneNumbers.push(tempPhoneNumber);
            });

            postData(route, {'agentId': self.id(), 'data': phoneNumbers}, function (result) {
                if (result == '1') {
                    toastr.success('Phone Numbers saved Added Successfully');
                    $('#datatable_agents').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Phone Numbers save Failed');
                }
            });
        }
    };
    self.saveAgentEmailAddresses = function () {
        let saveEmailAddressesForm = $('#agentEmailAddressesForm');

        if (!saveEmailAddressesForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(saveEmailAddressesForm).click().remove();
        }
        else {
            let route = ['agents', 'requests', 'submitAgentEmailAddresses'];
            let emailAddresses = [];
            let table = $('#datatable_agents').DataTable();
            let currentEmailAddresses = ko.toJS(self.emailAddresses);
            $.each(currentEmailAddresses, function (index, emailAddress) {
                let tempEmailAddress = {};
                if (emailAddress.id != 0) {
                    const originalAgent = ko.toJS(table.row(agent_view_model.currentRow()).data());
                    let originalEmailAddress = ko.utils.arrayFirst(originalAgent.emailAddresses, function (originalAddress) {
                        return originalAddress.id == emailAddress.id;
                    });
                    for (const prop in emailAddress) {

                        if (originalEmailAddress[prop] != emailAddress[prop]) {
                            if (tempEmailAddress.id == undefined) {
                                tempEmailAddress.id = emailAddress.id;
                            }
                            tempEmailAddress[prop] = emailAddress[prop];
                        }
                    }
                }
                else {
                    tempEmailAddress = emailAddress;
                }
                emailAddresses.push(tempEmailAddress);
            });

            postData(route, {'agentId': self.id(), 'data': emailAddresses}, function (result) {
                if (result == '1') {
                    toastr.success('Email Addresses saved Added Successfully');
                    $('#datatable_agents').DataTable().ajax.reload();
                }
                else {
                    toastr.warning('Email Addresses save Failed');
                }
            });


        }
    };

    let viewmodel = agent_view_model == undefined ? {agentTitles: ko.observableArray()} : agent_view_model;
    self.displayName = ko.computed(function () {
        // console.log('computed');
        let title = viewmodel.agentTitles()[self.agentTitle()] == undefined ? '' : (ko.utils.arrayFirst(viewmodel.agentTitles(), function (title) {
            return title.id == self.agentTitle();
        })).title;
        return title + '. ' + self.firstName() + ' ' + self.middleName() + ' ' + self.lastName();

    });
}

function PhoneNumber(phoneNumber) {
    const self = this;

    self.id = ko.observable(phoneNumber.id);
    self.phoneNumberTypeId = ko.observable(phoneNumber.phoneNumberTypeId);
    self.countryCode = ko.observable(phoneNumber.countryCode);
    self.areaCode = ko.observable(phoneNumber.areaCode);
    self.subscriberNumber = ko.observable(phoneNumber.subscriberNumber);
    self.extension = ko.observable(phoneNumber.extension);
    self.notes = ko.observable(phoneNumber.notes);
}


function EmailAddress(emailAddress) {
    const self = this;

    self.id = ko.observable(emailAddress.id);
    self.emailAddressTypeId = ko.observable(emailAddress.emailAddressTypeId);
    self.emailAddress = ko.observable(emailAddress.emailAddress);
}


function CountryCode(countryCode) {
    const self = this;

    self.id = countryCode.id;
    self.country = countryCode.country;
    self.code = countryCode.code;

    self.displayName = ko.computed(function () {
        let country = '';
        //this is to make sure the select is not over wide
        if (self.country.length > 10) {
            country = self.country.substring(0, 11);
        }
        else {
            country = self.country;
        }
        return country + ' (' + self.code + ')';
    });
}

ko.applyBindings(agent_view_model);
const agentsTableId = 'datatable_agents';
const agentsButtonFunc = '$(\'#add_Agent_modal\').modal(\'show\');';
const agentsDomParams = 'lfBrtip';
const agentsContentName = 'Agent';
const agentsDatatableAjaxRoute = '/agents/requests/getAllAgents/datatablesEncode';
const agentsColumns = [
    {'data': [null, '((row.agentTitle) + ". " + (row.firstName.charAt(0).toUpperCase() + row.firstName.slice(1))) + " " + ((row.middleName.charAt(0).toUpperCase() + row.middleName.slice(1))) + " " +((row.lastName.charAt(0).toUpperCase() + row.lastName.slice(1)))']},
    {'data': [null, '(row.phoneNumbers.length > 0 ? (row.phoneNumbers[0].countryCodeLiteral+ \'-\' + row.phoneNumbers[0].areaCode + \'-\' + row.phoneNumbers[0].subscriberNumber + \'/\' + row.phoneNumbers[0].extension):"")']},
    {'data': ['agentCompany', 'false']}
];

configureDatatable(agentsTableId, agentsButtonFunc,{}, agentsDomParams, agentsContentName, agentsDatatableAjaxRoute, agentsColumns);

$(document).ready(function () {
    let table = $('#datatable_agents').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_agents tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_agents tbody').on('click', 'tr', function () {
        agent_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        agent_view_model.currentAgent(new Agent(data));
        $('#edit_Agent_modal').modal('show');
    });

    //this allows for a custom message in case the user enters an invalid password

});
