<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 05/04/20
 * Time: 10:27 PM
 */

session_start();

// Flash message helper
// EXAMPLE - flash('register_success', 'You are now registered');
// DISPLAY IN VIEW - echo flash('register_success');
function flash($name = '', $message = '', $class = 'alert alert-success',$type = 'permanent')
{
    if (!empty($name)) {
        if (!empty($message)) {
            if (!empty($_SESSION[$name])) {
                unset($_SESSION[$name]);
            }

            if (!empty($_SESSION[$name . '_class'])) {
                unset($_SESSION[$name . '_class']);
            }

            $_SESSION[$name] = $message;
            $_SESSION[$name . '_class'] = $class;
        }
        elseif (empty($message) && !empty($_SESSION[$name])) {
            $class = !empty($_SESSION[$name . '_class']) ? $_SESSION[$name . '_class'] : '';
            if ($type === 'permanent'){
                echo '<div class="' . $class . '" id="msg-flash">' . $_SESSION[$name] . '</div>';
            }
            elseif ($type === 'temporary'){
                echo '<div class="' . $class . '" id="msg-flash">' . $_SESSION[$name] . '<span style="float: right;cursor: pointer;" class="fa fa-times" onclick="this.parentElement.remove()"></span></div>';
            }
            unset($_SESSION[$name]);
            unset($_SESSION[$name . '_class']);
        }
    }
}
