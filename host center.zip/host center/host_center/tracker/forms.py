from django import forms
from home.models import UserProfile, Division
from tracker.models import Schedule, Actual_Schedule
from django.contrib.auth.models import User

class ScheduleForm(forms.ModelForm):
    class Meta():
        model = Schedule
        fields = ('user', 'work_day', 'start_time', 'end_time', 'weekend')
        
class ActualScheduleForm(forms.ModelForm):
    class Meta():
        model = Actual_Schedule
        fields = ('schedule_date', 'schedule_day', 'entrance_time', 'exit_time', 'is_holiday', 'reason')