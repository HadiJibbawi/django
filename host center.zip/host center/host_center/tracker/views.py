
from django.shortcuts import render, redirect
from tracker.forms import ScheduleForm, ActualScheduleForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.shortcuts import render
from home.models import UserProfile, User
from tracker.models import Schedule, Actual_Schedule
from django.contrib.sessions.backends.base import SessionBase
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
import datetime

# Create your views here.

def index(request):
    username = request.user.username
    user = request.user
    user_profile = UserProfile.objects.get(user=user)
    schedule = None
    count = 0
    schedule = Schedule.objects.filter(user=user)

    count = schedule.count()
    days = []
    
    if count == 0:
        schedule = None
        
    if schedule:
        if not schedule.filter(work_day='Monday').exists():
            days.append('Monday')
        if not schedule.filter(work_day='Tuesday').exists():
            days.append('Tuesday')
        if not schedule.filter(work_day='Wednesday').exists():
            days.append('Wednesday')
        if not schedule.filter(work_day='Thursday').exists():
            days.append('Thursday')
        if not schedule.filter(work_day='Friday').exists():
            days.append('Friday') 
    else:
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
            
    return render(request, 'tracker/profile.html', {'user':user,
                                                     'user_profile':user_profile,
                                                     'schedule':schedule,
                                                     'count':count,
                                                     'days':days})
    
@login_required
def special(request):
    return HttpResponse("You are logged in!")

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))    
    

def actual_schedule(request):
    user = request.user
    actual_schedule = Actual_Schedule.objects.filter(user=user).order_by('-schedule_date')
    count1 = 0
    count1 = actual_schedule.count
    today_schedule = None
    if count1 == 0:
        actual_schedule = None
    return render(request, 'tracker/actual_schedule.html', {'user':user,
                                                     'count1':count1,
                                                     'today_schedule':today_schedule,
                                                     'actual_schedule':actual_schedule})    

def add_today(request):
    registered = False
    if request.method == 'POST':
        user = request.user
        schedule_date = request.POST.get('schedule_date')
        dt= datetime.datetime.strptime(schedule_date, "%Y-%m-%d")
        schedule_day=dt.today().strftime("%A")
        entrance_time = request.POST.get('entrance_time')
        exit_time = request.POST.get('exit_time')
        is_holiday = request.POST.get('is_holiday')
        reason = request.POST.get('reason')

        try:
            get_schedule = Actual_Schedule.objects.get(user=user,schedule_date=schedule_date)
        except ObjectDoesNotExist:
            actual_schedule = Actual_Schedule(user=request.user, schedule_date=schedule_date,schedule_day=schedule_day, entrance_time=entrance_time, exit_time=exit_time, is_holiday=is_holiday, reason=reason)
            actual_schedule.save()
            registered = True
            return HttpResponseRedirect(reverse('tracker:actual_schedule')) 
        get_schedule.entrance_time = entrance_time
        get_schedule.exit_time = exit_time
        get_schedule.is_holiday = is_holiday
        get_schedule.reason = reason
        get_schedule.save()
        registered = True    
    return HttpResponseRedirect(reverse('tracker:actual_schedule'))  
    
      
    
    
def register(request):
    registered = False
    if request.method == 'POST':
        schedule_form = ScheduleForm(data=request.POST)
        day = request.POST.get('work_day')
        start_time = request.POST.get('start_time')
        end_time = request.POST.get('end_time')
        weekend = request.POST.get('weekend')
        try: 
            schedule = Schedule(user=request.user, work_day=day, start_time=start_time, end_time=end_time, weekend=weekend)
            schedule.save()
            registered = True
        except:
            print(schedule_form.errors)
    else:
        schedule_form = ScheduleForm()
        
    return HttpResponseRedirect(reverse('tracker:index'))  
   
def edit_schedule(request):
    work_day = request.POST.get('work_day')
    start_time = request.POST.get('start_time')
    end_time = request.POST.get('end_time')
    weekend = request.POST.get('weekend')
    user = request.user
    schedule = Schedule.objects.get(user=user,work_day=work_day)
    if start_time:
        schedule.start_time = start_time
    if end_time:    
        schedule.end_time = end_time
    if weekend:    
        schedule.weekend = weekend
    schedule.save()
    return HttpResponseRedirect(reverse('tracker:index'))  
    
def reports(request):
    user = request.user
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    nb_holidays = 1
    nb_vaccation = nb_sickness = nb_official = nb_covid19 = nb_unspecified = 0
    nb_holidays = Actual_Schedule.objects.filter(user=user,is_holiday=1).count()
    if nb_holidays == 0:
        nb_total = 1
    else:
        nb_total = nb_holidays
        
    nb_vaccation = actual_schedule.filter(is_holiday=1,reason='Vaccation').count()
    nb_sickness = actual_schedule.filter(is_holiday=1,reason='Sickness').count()
    nb_official = actual_schedule.filter(is_holiday=1,reason='Official').count()
    nb_covid19 = actual_schedule.filter(is_holiday=1,reason='COVID-19').count()
    nb_unspecified = actual_schedule.filter(is_holiday=1,reason='Unspecified').count()
    p_vaccation = (nb_vaccation/nb_total)*100
    p_sickness =(nb_sickness/nb_total)*100
    p_official = (nb_official/nb_total)*100
    p_covid19 = (nb_covid19/nb_total)*100
    p_unspecified = (nb_unspecified/nb_total)*100
    start_mon = start_tue = start_wed = start_thu = start_fri = None
    end_mon = end_tue = end_wed = end_thu = end_fri = None
    for sd in schedule:
        if sd.work_day == 'Monday':
            start_mon = sd.start_time
        if sd.work_day == 'Tuesday':
            start_tue = sd.start_time
        if sd.work_day == 'Wednesday':
            start_wed = sd.start_time
        if sd.work_day == 'Thursday':
            start_thu = sd.start_time
        if sd.work_day == 'Friday':
            start_fri = sd.start_time 
        if sd.work_day == 'Monday':
            end_mon = sd.end_time
        if sd.work_day == 'Tuesday':
            end_tue = sd.end_time
        if sd.work_day == 'Wednesday':
            end_wed = sd.end_time
        if sd.work_day == 'Thursday':
            end_thu = sd.end_time
        if sd.work_day == 'Friday':
            end_fri = sd.end_time 
    return render(request, 'tracker/reports.html',{'nb_holidays':nb_holidays,'nb_vaccation':nb_vaccation,'nb_sickness':nb_sickness,
                                                   'nb_official':nb_official,'nb_covid19':nb_covid19,'nb_unspecified':nb_unspecified,
                                                   'p_vaccation':p_vaccation,'p_sickness':p_sickness,'p_official':p_official,
                                                   'p_covid19':p_covid19,'p_unspecified':p_unspecified, 'start_mon':start_mon
                                                    }) 