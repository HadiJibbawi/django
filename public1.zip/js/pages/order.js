const fieldDataTypeIds = {
    'text': 1,
    'number': 2,
    'date': 3,
    'file': 4

};
const fieldTypeIds = {
    'free': 1,
    'bound': 2
};
const productTypes = {
    'standard': 1,
    'custom': 2
};
const processStatusList = {
    'inProgress': '1',
    'Done': '2'
};
$("#addCustomer").attr("href", RootFolderUrl + '/customers/customers');
const OrderId = document.querySelector('#OrderNumber').value;
const order_view_model = new OrderViewModel();

// postData(['sales','salesItemFile'])

function OrderViewModel() {

    const self = this;


    self.currentItemProduct = ko.observable(new Item());
    self.currentOrderItem = ko.observable(new Item());
    self.originalOrder = {};
    self.items = ko.observableArray([]);
    self.totalPrice = ko.computed(function () {
        let total = 0;
        $.each(self.items(), function (index, item) {
            if (item._destroy != true) {
                total += (parseInt(item.price()) * parseInt(item.quantity()));
            }
        });
        return numberWithCommas(total);
    });
    self.products = ko.observableArray([]);
    self.customers = ko.observableArray([]);
    self.currentProduct = ko.observable();
    self.order = new Order({'id': '0', 'customer': {}});
    self.currentProductFields = ko.observableArray();
    self.netPrice = ko.computed(function () {
        let total = 0;
        $.each(self.items(), function (index, item) {
            if (item._destroy != true) {
                total += (parseInt(item.price()) * parseInt(item.quantity()));
            }
        });
        let net = parseInt(total - parseInt(self.order.discount()));
        if (net < 0 || isNaN(net) || self.order.discount() < 0) {
            self.order.discount(0);
            if (net < 0) {
                self.order.discount(total);
            }
            net = parseInt(total) - parseInt(self.order.discount());
        }
        return numberWithCommas(net);
    });

    self.getOrderDetails = function () {
        let route = ['sales', 'requests', 'getOrder'];
        fetchDataJson(route, {'orderId': OrderId}, function (data) {
            self.originalOrder = data;
            let tempCustomer = ko.utils.arrayFirst(order_view_model.customers(), function (customer) {
                return customer.id == data.customerId;
            });
            self.order.customer(tempCustomer);
            self.order.dateDue(data.dueDate);
            self.order.datePlaced(data.placementDate);
            console.log(data);
            $.each(data.salesOrderItems, function (index, value) {
                value.isNew = false;
                value.title = value.product.title;
                let newItem = new Item(value);
                // console.log(ko.toJS(newItem));
                $.each(data.salesOrderItems[index], function (key, value) {
                    if (key == 'salesItemValues') {
                        $.each(value, function (index, value) {
                            let newField = new Field(value);
                            newItem.fields.push(newField);
                        });
                    }
                    else {
                        // console.log(key + ' : ' + value);
                    }
                });
                self.items.push(newItem);

            });
            self.order.discount(data.discount);
        })
    };
    self.setSaleItem = function (item) {
        self.currentOrderItem(item);
        $('#editItemModal').modal('show');
    };

    self.clearNewOrder = function () {
        let currentProduct = self.currentProduct();
        self.currentProduct(undefined);
        self.currentProduct(currentProduct);
        self.order.customer(undefined);
    };

    self.clearNewCustomerModal = function () {
        self.newCustomerName(undefined);
        self.newCustomerPhoneNumber('');
        self.newCustomerSecondaryPhoneNumber('');
        self.newCustomerEmailAddress('');
        self.newCustomerDeliveryAddress('');
    };

    self.addCustomer = function () {
        let addCustomerForm = $('#addCustomerForm');

        if (!addCustomerForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addCustomerForm).click().remove();
        }
        else {
            let route = ['sales', 'requests', 'addCustomer'];
            let customer = {};
            customer.name = self.newCustomerName();
            customer.phoneNumber = self.newCustomerPhoneNumber();
            customer.secondaryPhoneNumber = self.newCustomerSecondaryPhoneNumber();
            customer.emailAddress = self.newCustomerEmailAddress();
            customer.deliveryAddress = self.newCustomerDeliveryAddress();
            postData(route, customer, function (result) {
                if (result == '1') {
                    toastr.success('Customer Added Successfully');
                    self.clearNewCustomerModal();
                    self.getAllCustomers();
                }
                else {
                    toastr.warning('Customer Addition Failed');
                }
            });

            $('#add_Customer_modal').modal('hide');

        }
    };

    self.submitNewOrder = function () {

        let newOrderForm = $('#newOrderForm');

        if (!newOrderForm [0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(newOrderForm).click().remove();
        }
        else {
            if (self.items().length == 0) {
                swal.fire('Empty Cart', 'Please add items before submitting', 'warning');
                return;
            }
            orderData = {};
            if (self.order.customer().id != self.originalOrder.customerId) {
                orderData.customerId = self.order.customer().id;
                self.originalOrder.customerId = self.order.customer().id;
            }
            if (self.order.dateDue() != self.originalOrder.dueDate) {
                orderData.dueDate = self.order.dateDue();
                self.originalOrder.dueDate = self.order.dateDue();
            }
            if (self.order.datePlaced() != self.originalOrder.placementDate) {
                orderData.placementDate = self.order.datePlaced();
                self.originalOrder.placementDate = self.order.datePlaced();
            }
            if (self.order.discount() != self.originalOrder.discount) {
                orderData.discount = self.order.discount();
                self.originalOrder.discount = self.order.discount();
            }
            if (orderData != {}) {
                orderData.id = self.originalOrder.id;
                let route = ['sales', 'requests', 'updateOrder'];
                postData(route, orderData, function (result) {
                    console.log(result);
                });
            }
            $.each(self.items(), function (index, item) {
                if (item.isNew) {
                    let itemData = {};
                    itemData.productId = item.productId();
                    itemData.productType = item.productType();
                    itemData.orderId = OrderId;
                    itemData.quantity = item.quantity();
                    itemData.price = item.price();
                    itemData.priceCurrencyId = item.priceCurrencyId();
                    let itemRoute = ['sales', 'requests', 'addItem'];
                    postData(itemRoute, itemData, function (itemId) {
                        console.log(itemId);
                        let data = [];
                        console.log(ko.toJS(item));
                        $.each(item.fields(), function (index, field) {
                            let fieldValue = {};
                            let fieldId = field.fieldId;
                            fieldValue['fieldId'] = fieldId;
                            if (field.fieldDataTypeId == fieldDataTypeIds['text'] || field.fieldDataTypeId == fieldDataTypeIds['number']) {
                                if (field.fieldTypeId == fieldTypeIds['bound']) {
                                    fieldValue['fieldValue'] = field.valueId();
                                    fieldValue['fieldType'] = field.fieldTypeId;
                                    data.push(fieldValue);
                                }
                                else {
                                    fieldValue['fieldValue'] = field.valueValue();
                                    fieldValue['fieldType'] = field.fieldTypeId;
                                    data.push(fieldValue);
                                }
                            }
                            else if (field.fieldDataTypeId == fieldDataTypeIds['date']) {
                                fieldValue['fieldValue'] = field.valueValue();
                                fieldValue['fieldType'] = field.fieldTypeId;
                                data.push(fieldValue);
                            }
                            else {
                                let fileInput = document.querySelector('#productField' + field.id);
                                //get current file from list of files
                                // const currentFile = fileInput.files[0];
                                const currentFile = field.file();
                                if (currentFile != null && currentFile != undefined) {
                                    //this event fires one the image has been loaded
                                    uploadFile(currentFile, RootFolderUrl + '/sales/requests/uploadFile', fieldTypeIds['free'], fieldId, itemId, function (result) {
                                        fieldValue['fieldValue'] = result;
                                        fieldValue['fieldType'] = fieldTypeIds['bound'];
                                        let itemFields = {};
                                        let newData = [];
                                        newData.push(fieldValue);
                                        itemFields['itemFieldValues'] = newData;
                                        itemFields['itemId'] = itemId;
                                        let route = ['sales', 'requests', 'submitOrder'];
                                        postData(route, itemFields, function (result) {
                                            // console.log(result);
                                        });
                                    });
                                }
                            }

                        });
                        // console.log(data);
                        let itemFields = {};
                        itemFields['itemId'] = itemId;
                        itemFields['itemFieldValues'] = data;
                        let route = ['sales', 'requests', 'submitOrder'];
                        postData(route, itemFields, function (result) {
                            Swal.fire({
                                title: 'Order updated',
                                text: 'Order ID: ' + self.originalOrder.id,
                                icon: 'success',
                                confirmButtonText: 'Back to orders'
                            }).then((result) => {
                                if (result.isConfirmed || !result.isConfirmed) {
                                    window.location.href = appRootFolderName + '/orders';
                                }
                            })
                        });
                    });
                }
                else{
                    let itemData = {};
                    itemData.id = item.id();
                    itemData.quantity = item.quantity();
                    let route = ['sales','requests','updateItemQuantity'];
                    postData(route,itemData,function (result) {
                       console.log(result);
                    });
                }
            });
        }
    };

    self.addItem = function () {
        let newItemForm = $('#newItemForm');

        if (!newItemForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(newItemForm).click().remove();
        }
        else {
            // console.log(ko.toJS(self.currentItemProduct()));'
            $.each(self.currentItemProduct().fields(), function (index, field) {
                if (field.fieldDataTypeId == fieldDataTypeIds['file']) {
                    let fileInput = document.querySelector('#productField' + field.fieldId);
                    //get current file from list of files
                    field.file = ko.observable(fileInput.files[0]);

                }
            });
            self.items.push(self.currentItemProduct());
            $('#addItemModal').modal('hide');
        }


    };
    self.getProducts = function () {
        let route = ['sales', 'requests', 'getAllProducts'];
        fetchDataJson(route, {}, function (products) {
            self.products(products);
        });
    };
    self.getProducts();
    self.getAllCustomers = function () {
        self.customers([]);
        let route = ['customers', 'requests', 'getAllCustomers'];
        fetchDataJson(route, {}, function (customers) {
            // self.customers(customers);
            // console.log(customers);
            $.each(customers, function (index, customer) {
                let newCustomer = {};
                newCustomer.id = customer.id;
                newCustomer.name = customer.customerTitle + '. ' + customer.firstName + ' ' + customer.lastName;
                self.customers.push(new Customer(newCustomer));
            });
            self.getOrderDetails();
        });
    };
    self.getAllCustomers();

}

function Order(order) {

    const self = this;


    self.id = order.id;
    self.customer = ko.observable(order.customer);
    self.dateDue = ko.observable();
    self.datePlaced = ko.observable();
    self.discount = ko.observable(0);

    self.setDates = function () {
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        mm = mm > 9 ? mm : '0' + mm;
        dd = dd > 9 ? dd : '0' + dd;
        let yyyy = today.getFullYear();
        let placedDate = yyyy + '-' + mm + '-' + dd;
        // console.log(today.getDate() + 12);
        today.setDate(today.getDate() + 7);
        dd = today.getDate();
        mm = today.getMonth() + 1;
        mm = mm > 9 ? mm : '0' + mm;
        dd = dd > 9 ? dd : '0' + dd;
        yyyy = today.getFullYear();
        let dueDate = yyyy + '-' + mm + '-' + dd;
        self.dateDue(dueDate);
        self.datePlaced(placedDate);
    };
    self.setDates();
}

function Item(item) {
    const self = this;

    self.id = item == undefined ? ko.observable('') : ko.observable(item.salesItemId);
    self.productId = item == undefined ? ko.observable('') : ko.observable(item.id);
    self.productType = item == undefined ? ko.observable('') : ko.observable(productTypes['standard']);
    self.title = item == undefined ? ko.observable('') : ko.observable(item.title);
    self.quantity = item == undefined ? ko.observable(1) : item.quantity == undefined ?ko.observable(1) :ko.observable(item.quantity);
    self.fields = ko.observableArray([]);
    self.processes = ko.observableArray([]);
    self.price = item == undefined ? ko.observable(0) : item.price == undefined ? ko.observable(0) : ko.observable(item.price);
    self.priceCurrencyId = item == undefined ? ko.observable(1) : item.price == undefined ? ko.observable(0) : ko.observable(item.priceCurrencyId);

    self.isNew = item == undefined ? true : item.isNew == undefined ? true : false;
    self.hasChanged = self.isNew ? ko.observable(true) : ko.observable(false);

    self.Uprice = ko.computed(function () {
        return numberWithCommas(self.price());
    });
    self.Bprice = ko.computed(function () {
        return numberWithCommas(parseInt(self.price()) * parseInt(self.quantity()));
    });

    self.updateItem = function () {
        //check if item is a new item ( if it is new, then no need to update )
        if (!self.isNew) {
            $.each(self.fields(), function (index, field) {
                if (field.isChanged()) {
                    // console.log(field);
                    // return;
                    let data = [];
                    let fieldValue = {};
                    let fieldId = field.fieldId;
                    fieldValue['fieldId'] = fieldId;
                    fieldValue['salesItemValueId'] = field.salesItemValueId;
                    if (field.fieldDataTypeId == fieldDataTypeIds['text'] || field.fieldDataTypeId == fieldDataTypeIds['number']) {
                        if (field.fieldTypeId == fieldTypeIds['bound']) {
                            fieldValue['fieldValue'] = field.valueId();
                            fieldValue['fieldType'] = field.fieldTypeId;
                            data.push(fieldValue);
                        }
                        else {
                            fieldValue['fieldValue'] = field.valueValue();
                            fieldValue['fieldType'] = field.fieldTypeId;
                            data.push(fieldValue);
                        }
                    }
                    else if (field.fieldDataTypeId == fieldDataTypeIds['date']) {
                        fieldValue['fieldValue'] = field.valueValue();
                        fieldValue['fieldType'] = field.fieldTypeId;
                        data.push(fieldValue);
                    }
                    else {
                        let fileInput = document.querySelector('#productField' + field.id);
                        //get current file from list of files
                        // const currentFile = fileInput.files[0];
                        const currentFile = field.file();
                        if (currentFile != null && currentFile != undefined) {
                            //this event fires one the image has been loaded
                            let currentImageFieldValueId = field.valueId();
                            replaceFile(currentFile, RootFolderUrl + '/sales/requests/replaceFile', fieldTypeIds['free'], fieldId, self.id(), currentImageFieldValueId, function (result) {
                                // field.valueValue();
                                console.log(result);
                                field.updateFileValues();
                            });
                        }
                    }

                    // console.log(data);
                    let itemFields = {};
                    itemFields['itemId'] = self.id();
                    itemFields['itemFieldValues'] = data;
                    let route = ['sales', 'requests', 'editOrderItem'];
                    postData(route, itemFields, function (result) {
                        if (result == 1) {
                            field.isChanged(false);
                            // Swal.fire({
                            //     title: 'Order successful',
                            //     text: 'Order ID: ' + orderId,
                            //     icon: 'success',
                            //     confirmButtonText: 'New Order'
                            // }).then((result) => {
                            //     if (result.isConfirmed || !result.isConfirmed) {
                            //         window.location.reload(true);
                            //     }
                            // })
                            toastr.success('item upgraded', 'Success')
                        }
                    });

                }
            });
        }

    };

    self.updateProcesses = function () {
        let x = {
            true: 'green',
            false: 'red'
        };
        let processes = [];
        $.each(self.processes(), function (index, process) {
            console.log(`%c ${process.id},${process.title}  : ${process.status()}`, 'color: ' + x[process.status()]);
            let tempProcess = {};
            tempProcess['salesItemProcessId'] = process.id;
            tempProcess['processStatus'] = process.status();
            processes.push(tempProcess);
        });
        let route = ['sales', 'requests', 'updateItemProcesses'];
        postData(route, {'processes':processes}, function (result) {
            if (result == 1) {
                toastr.success('Updated!', 'Process Status Updated');
            }
            else{
                toastr.warning('Failed!', 'Process Status Update Failed');
            }
        })
    };

    self.getFields = function () {
        // console.log(currentProductId);
        let route = ['sales', 'requests', 'getProductFieldsWithValues', self.productId()];
        fetchDataJson(route, {}, function (fields) {
            self.fields([]);
            $.each(fields, function (index, field) {
                self.fields.push(new Field(field));
            });
            // self.order.fields(fields);
            // console.log(fields);
        });
    };
    self.getProcesses = function () {
        // console.log(currentProductId);
        let route = ['sales', 'requests', 'getSaleItemProcesses', self.id()];
        fetchDataJson(route, {}, function (processes) {
            self.processes([]);
            $.each(processes, function (index, process) {
                self.processes.push(new Process(process));
            });
            // self.order.fields(fields);
            // console.log(fields);
        });
    };
    self.getProcesses();
    self.getProductPrice = function () {
        let route = ['products', 'requests', 'getProductPrice'];
        fetchDataJson(route, {'productId': self.productId()}, function (price) {
            self.price(price.price);
            self.priceCurrencyId(price.currencyId);
        })
    };
    if (self.isNew == true) {
        self.getProductPrice();
        self.getFields();
    }
    else {

    }


}

function Field(field) {

    const self = this;

    self.salesItemValueId = field.salesItemValueId; // needed
    self.title = field.title || field.fieldTitle; // ok
    self.description = field.description == undefined ? '' : field.description; // no
    self.fieldDataType = field.fieldDataType; // ok
    self.fieldDataTypeId = field.fieldDataTypeId; // ok
    self.fieldId = field.fieldId; // ok
    self.fieldType = field.fieldType; // ko
    self.fieldTypeId = field.fieldTypeId; // ok


    self.valueId = field.fieldValueId == undefined ? ko.observable(0) : ko.observable(field.fieldValueId);
    self.valueValue = ko.observable();

    self.isChanged = ko.observable(false);


    self.boundFieldValues = ko.observableArray([]);
    self.changeFile = function (file) {
        if (self.file != undefined) {
            self.file(file);
            self.valueValue(file.name);
        }
        else {
            self.file = ko.observable();
            self.file(file);
            self.valueValue(file.name);
        }
    };
    //this means if this is a new item being created
    if (field.salesItemValueId == undefined) {
        $.each(field.productFieldValues, function (index, fieldValue) {
            self.boundFieldValues.push(fieldValue);
        });
    }
    if (field.description == undefined && self.fieldTypeId == fieldTypeIds['bound']) {
        let route = ['sales', 'requests', 'getFieldValues', self.fieldId];
        fetchDataJson(route, {}, function (fieldValues) {
            $.each(fieldValues, function (index, fieldValue) {
                self.boundFieldValues.push(fieldValue);
            });
            self.subscribeToValues();
        });
    }
    else if (field.description == undefined && self.fieldTypeId == fieldTypeIds['free']) {
        let route = ['sales', 'requests', 'getFieldValues', self.fieldId];
        fetchDataJson(route, {}, function (fieldValues) {
            let valueValue = ko.utils.arrayFirst(fieldValues, function (fieldValue) {
                return fieldValue.id == self.valueId();
            });
            self.valueValue(valueValue.value);
            self.subscribeToValues();
        });
    }
    self.subscribeToValues = function () {
        self.valueValue.subscribe(function (value) {
            self.isChanged(true);
        });
        self.valueId.subscribe(function (value) {
            self.isChanged(true);
        });
    };

    self.updateFileValues = function () {
        let route = ['sales', 'requests', 'getFieldValues', self.fieldId];
        fetchDataJson(route, {}, function (fieldValues) {
            let valueValue = ko.utils.arrayFirst(fieldValues, function (fieldValue) {
                return fieldValue.id == self.valueId();
            });
            self.valueValue(valueValue.value);
            self.subscribeToValues();
        });
    }
}

function Process(process) {

    const self = this;

    self.id = process.id;
    self.title = process.title;
    self.description = process.description;
    self.cost = process.cost;
    self.sequence = process.sequence;
    self.status = ko.observable(process.status == processStatusList['Done']);


    self.isChanged = ko.observable(false);


}


// function FieldValue(fieldValue) {
//     const self = this;
//
//     self.id = fieldValue.id;
//     self.value= fieldValue.value;
//
// }

function Customer(customer) {

    const self = this;

    self.id = customer.id;
    self.name = customer.name;
}


const productsTableId = 'datatable_products';
const productsButtonFunc = '';
const productsContentName = 'Product';
const productsDomParams = 'lfrtip';
const productsDatatableAjaxRoute = '/products/requests/getAllProducts';
const productsColumns = [
    {'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']},
    {'data': ['code', 'false']},
    {'data': ['description', 'false']}];

configureDatatable(productsTableId, productsButtonFunc, {}, productsDomParams, productsContentName, productsDatatableAjaxRoute, productsColumns);


function IgnoreKeyboardScrolling(e) {
    if (!e) {
        e = window.event;
    }
    if (e.keyCode >= 37 && e.keyCode <= 40) // arrows
    {
        e.returnValue = false;
        e.cancel = true;
    }
}


function uploadFile(file, path, fieldTypeId, fieldId, itemId, callback) {
    let form = new FormData();
    form.append('file', file, file.name);
    form.append('fieldTypeId', fieldTypeId);
    form.append('itemId', itemId);
    form.append('fieldId', fieldId);

    $.ajax({
        url: path,
        data: form,
        type: 'POST',
        contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
        processData: false, // NEEDED, DON'T OMIT THIS
        success: function (result) {
            callback(result);
        }
    });
}

function replaceFile(file, path, fieldTypeId, fieldId, itemId, fileId, callback) {
    let form = new FormData();
    form.append('file', file, file.name);
    form.append('fieldTypeId', fieldTypeId);
    form.append('itemId', itemId);
    form.append('fieldId', fieldId);
    form.append('currentFileId', fileId);

    $.ajax({
        url: path,
        data: form,
        type: 'POST',
        contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
        processData: false, // NEEDED, DON'T OMIT THIS
        success: function (result) {
            callback(result);
        }
    });
}

ko.applyBindings(order_view_model);

$(document).ready(function () {
    let table = $('#datatable_products').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_products tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_products tbody').on('click', 'tr', function () {
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        order_view_model.currentItemProduct(new Item(data));
        // console.log(order_view_model.currentItemProduct());

    });

    //this allows for a custom message in case the product enters an invalid password

});

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}