const products_view_model = new productsViewModel();

function productsViewModel() {
    const self = this;

    self.newProduct = ko.observable(new Product());
    self.currentProduct = ko.observable(new Product());
    self.currentRow = ko.observable();
    self.productCategories = ko.observableArray([]);

    self.getProductCategories = function () {
        let route = ['products', 'requests', 'getProductCategories'];
        fetchDataJson(route, {}, function (categories) {
            self.productCategories(categories);
        });
    };
    self.getProductCategories();


    self.openProductPage = function (id) {
        window.location.href = appRootFolderName + '/products/product/' + id;
    };

    self.addProduct = function () {
        let addProductForm = $('#addProductForm');

        if (!addProductForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(addProductForm).click().remove();
        }
        else {
            let route = ['products', 'requests', 'addProduct'];
            let product = {};
            product.title = self.newProduct().title();
            product.code = self.newProduct().code();
            product.description = self.newProduct().description();
            product.price = self.newProduct().price();
            postData(route, product, function (result) {
                if (result == '1') {
                    toastr.success('Product Added Successfully');
                    self.clearNewProductModal();
                    let table = $('#datatable_products').DataTable();
                    table.ajax.reload();
                }
                else {
                    toastr.warning('Product Addition Failed');
                }
            });

            $('#add_Product_modal').modal('hide');

        }
    };

    self.clearNewProductModal = function () {
        self.newProduct(new Product());
    };

    self.deleteCurrentProduct = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentProduct().title());
        if (confirmDelete) {
            let deleteRoute = ['products', 'requests', 'deleteProduct'];
            postData(deleteRoute, {'id': self.currentProduct().id}, function (response) {
                if (response == '1') {
                    toastr.success('Product Type Deleted');
                    self.currentProduct(new Product());
                    $('#datatable_products').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Product Type Deletion Failed');
                }
            });
            $('#edit_Product_modal').modal('hide');

        }
    };

    self.submitEditProduct = function () {

        let editCurrentProductForm = $('#editCurrentProductForm');

        if (!editCurrentProductForm[0].checkValidity()) {
            $('<input type="submit">').hide().appendTo(editCurrentProductForm).click().remove();
        }
        else {

            let route = ['products', 'requests', 'updateProduct'];
            let table = $('#datatable_products').DataTable();
            let product = {};
            const originalProduct = ko.toJS(table.row(self.currentRow()).data());
            const currentProduct = ko.toJS(self.currentProduct);
            console.log(originalProduct);
            console.log(currentProduct);
            for (const prop in originalProduct) {
                if (originalProduct[prop] != currentProduct[prop]) {
                    product[prop] = currentProduct[prop];
                }
            }
            if (currentProduct['price'] != currentProduct['originalPrice']){
                product['price'] = currentProduct['price'];
            }
            if ($.isEmptyObject(product)) {
                alert('No changes have been made');
                return;
            }
            product['id'] = originalProduct.id;
            postData(route, product, function (result) {
                if (result == '1') {
                    toastr.success('Product Edited Successfully');
                    let table = $('#datatable_products').DataTable();
                    table.ajax.reload();
                    $('#edit_Product_modal').modal('hide');
                }
                else {
                    toastr.warning('Product Edit Failed');
                }
            });
        }
    };


    self.resetCurrentProduct = function () {
        let table = $('#datatable_products').DataTable();
        let data = ko.toJS(table.row(self.currentRow()).data());
        data['enableDelete'] = ko.observable(false);
        products_view_model.currentProduct(new Product(data));
    };

    self.deleteCurrentField = function () {
        let confirmDelete = confirm('are you sure you want to delete ' + self.currentField().title);
        if (confirmDelete) {
            let deleteRoute = ['admin', 'requests', 'deleteField'];
            postData(deleteRoute, {
                'productFieldId': self.currentField().id,
                'fieldId': self.currentField().fieldId
            }, function (response) {
                if (response == '1') {
                    toastr.success('Field Deleted');
                    self.currentField({'title': ''});
                    $('#datatable_fields').DataTable().ajax.reload();
                }
                else {
                    toastr.error('Field Deletion Failed');
                }
            });
        }
    };

}

function Product(product) {
    const self = this;

    self.id = product == undefined ? ko.observable('') : ko.observable(product.id);
    self.title = product == undefined ? ko.observable('') : ko.observable(product.title);
    self.code = product == undefined ? ko.observable('') : ko.observable(product.code);
    self.categoryId = product == undefined ? ko.observable('') : ko.observable(product.categoryId);
    self.description = product == undefined ? ko.observable('') : ko.observable(product.description);
    self.price = ko.observable(0);
    self.originalPrice = 0;

    self.getProductPrice = function () {
      let route = ['products','requests','getProductPrice'];
      fetchDataJson(route,{'productId':self.id()},function (price) {
          self.price(price.price);
          self.originalPrice = price.price;
      })
    };
    self.getProductPrice();

    self.enableDelete = ko.observable(false);

}

ko.applyBindings(products_view_model);


const productsTableId = 'datatable_products';
const productsButtonFunc = '$(\'#add_Product_modal\').modal(\'show\');';
const productsContentName = 'Product';
const productsDomParams = 'lfBrtip';
const productsDatatableAjaxRoute = '/products/requests/getAllProducts';
const productsColumns = [
    {'data': ['title', '(data.charAt(0).toUpperCase() + data.slice(1))']},
    {'data': ['description' , 'false']},
    {'data': ['id', 'new String(\'<button  onclick="products_view_model.openProductPage(\' + data + \')" class="btn btn-bdesign-primary btn-sm"> Details <span class="fa fa-share-square"> </span></button>\')']}];

configureDatatable(productsTableId, productsButtonFunc,{}, productsDomParams, productsContentName, productsDatatableAjaxRoute, productsColumns);

$(document).ready(function () {
    let table = $('#datatable_products').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_products tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_products tbody').on('click', 'tr', function () {
        products_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        data['enableDelete'] = ko.observable(false);
        products_view_model.currentProduct(new Product(data));
        $('#edit_Product_modal').modal('show');
        console.log(products_view_model.currentProduct());

    });

    //this allows for a custom message in case the product enters an invalid password

});
