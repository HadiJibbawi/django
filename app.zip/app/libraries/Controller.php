<?php
/*
 * Base Controller
 * Loads the models and views
 */

class Controller
{
    //Load model
    public function model($model)
    {
        //require model file
        require_once '../app/models/' . $model . '.php';

        //instantiate model
        return new $model;
    }

    //load view
    public function view($view, $data = [], $template = [])
    {
        //check for the view file
        if (file_exists('../app/views/' . $view . '.php')) {
            require_once APPROOT . '/views/inc/header.php';
            require_once APPROOT . '/views/' . $view . '.php';
            require_once APPROOT . '/views/inc/footer.php';
        }
        else {
            //view does not exist
            die('View Does not exist');
        }
    }

    public static function utf8ize($mixed)
    {
        if (is_array($mixed)) {
            foreach ($mixed as $key => $value) {
                $mixed[$key] = Controller::utf8ize($value);
            }
        }
        elseif (is_string($mixed)) {
            return mb_convert_encoding($mixed, "UTF-8", "UTF-8");
        }
        return $mixed;
    }

    public static function encode_json($mixed, $return = 0)
    {
        return json_encode(Controller::utf8ize($mixed), $return);
    }

    public static function datatables_encode($mixed, $return = 0)
    {
        $object = ['data' => $mixed];
        return json_encode(Controller::utf8ize($object), $return);

    }

    public static function underscoreToCamelCase($str)
    {
        $arr = preg_split("_", $str);
        $flag = true;
        $result = '';
        foreach ($arr as $subString) {
            if ($flag) {
                $result .= $subString;
                $flag = false;
                continue;
            }
            $subStr = ucfirst($subString);
            $result .= $subString;
        }
        return $result;
    }

    public static function camelCaseToUnderscore($str){
        $newStr = preg_replace_callback("/([A-Z])/",function ($matches){
            return'_' . strtolower($matches[0]);
        },$str);
        return $newStr;
    }
}