<?php

class Sale
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getOrders()
    {
        $this->db->query('SELECT so.`id`,so.`customer_id` AS customerId,c.first_name AS customerFirstName,ct.title AS customerTitle,c.middle_name AS customerMiddleName,c.last_name AS customerLastName,so.placement_date AS placementDate,so.due_date AS dueDate,so.discount,so.status FROM `sales_orders` so LEFT JOIN `customers` c ON so.customer_id = c.id LEFT JOIN customer_titles ct ON c.title = ct.id');
        $orders = $this->db->resultSet();
        foreach ($orders as $order) {
            $this->db->query('SELECT id AS salesItemId,product_id AS productId,product_type AS productType, quantity, status FROM sales_items WHERE sales_order_id = :salesOrderId');
            $this->db->bind(':salesOrderId', $order->id);
            $salesOrderItems = $this->db->resultSet();
            foreach ($salesOrderItems as $salesOrderItem) {
                $this->db->query('SELECT id,title,code,category FROM `products` WHERE id = :productId');
                $this->db->bind(':productId', $salesOrderItem->productId);
                $salesOrderItem->product = $this->db->single();
                $this->db->query('SELECT siv.id ,siv.field_value AS fieldValueId,f.id AS fieldId,f.title AS fieldTitle, f.field_type_id AS fieldTypeId, f.data_type_id AS fieldDataTypeId FROM `sales_item_values` siv LEFT JOIN `field_values` fv ON siv.field_value = fv.id LEFT JOIN `fields` f ON fv.field_id = f.id   WHERE siv.sale_item_id = :salesItemId');
                $this->db->bind(':salesItemId', $salesOrderItem->salesItemId);
                $salesOrderItem->salesItemValues = $this->db->resultSet();
            }
            $order->salesOrderItems = $salesOrderItems;
        }
        return $orders;
    }

    public function getOrder($id)
    {
        $this->db->query('SELECT so.`id`,so.`customer_id` AS customerId,c.first_name AS customerFirstName,ct.title AS customerTitle,c.middle_name AS customerMiddleName,c.last_name AS customerLastName,date(so.placement_date) AS placementDate,date(so.due_date) AS dueDate,so.discount,so.status FROM `sales_orders` so LEFT JOIN `customers` c ON so.customer_id = c.id LEFT JOIN customer_titles ct ON c.title = ct.id WHERE so.id = :id ');
        $this->db->bind(':id', $id);
        $order = $this->db->single();
        $this->db->query('SELECT id AS salesItemId,product_id AS productId,product_type AS productType, quantity,price,price_currency AS priceCurrencyId, status FROM sales_items WHERE sales_order_id = :salesOrderId');
        $this->db->bind(':salesOrderId', $id);
        $salesOrderItems = $this->db->resultSet();
        foreach ($salesOrderItems as $salesOrderItem) {
            $this->db->query('SELECT id,title,code,category FROM `products` WHERE id = :productId');
            $this->db->bind(':productId', $salesOrderItem->productId);
            $salesOrderItem->product = $this->db->single();
            $this->db->query('SELECT siv.id AS salesItemValueId ,siv.field_value AS fieldValueId,f.id AS fieldId,f.title AS fieldTitle, f.field_type_id AS fieldTypeId,ft.type AS fieldType,fdt.type AS fieldDataType, f.data_type_id AS fieldDataTypeId FROM `sales_item_values` siv LEFT JOIN `field_values` fv ON siv.field_value = fv.id LEFT JOIN `fields` f ON fv.field_id = f.id LEFT JOIN field_data_types fdt ON f.data_type_id = fdt.id LEFT JOIN field_types ft ON f.field_type_id = ft.id WHERE siv.sale_item_id = :salesItemId');
            $this->db->bind(':salesItemId', $salesOrderItem->salesItemId);
            $salesOrderItem->salesItemValues = $this->db->resultSet();
        }
        $order->salesOrderItems = $salesOrderItems;
        return $order;
    }

    public function getProductFieldsWithValues($productId)
    {
        $this->db->query('SELECT ptf.id,f.title,f.description,ptf.field_id AS fieldId,fdt.type AS fieldDataType,fdt.id AS fieldDataTypeId,ft.id AS fieldTypeId,ft.type AS fieldType FROM `product_fields` ptf LEFT JOIN `fields` f ON ptf.field_id = f.id LEFT JOIN `field_types` ft ON f.field_type_id = ft.id LEFT JOIN `field_data_types` fdt ON f.data_type_id = fdt.id WHERE ptf.product_id = :productId');
        $this->db->bind(':productId', $productId);
        $productFields = $this->db->resultSet();
        foreach ($productFields as $productField) {
            $this->db->query('SELECT id,value FROM `field_values` WHERE field_id = :fieldId');
            $this->db->bind(':fieldId', $productField->fieldId);
            $productFieldValues = $this->db->resultSet();
            $productField->productFieldValues = $productFieldValues;
        }
        return $productFields;
    }

    public function getSaleItemProcesses($saleItemId)
    {
        $this->db->query('SELECT sip.id as id,p.id AS processId,p.title,p.description,p.cost,p.sequence,sip.status FROM processes p LEFT JOIN sales_item_processes sip ON sip.process_id = p.id WHERE sip.sale_item_id = :saleItemId');
        $this->db->bind(':saleItemId', $saleItemId);
        $productProcesses = $this->db->resultSet();

        return $productProcesses;
    }

    public function getFieldValues($fieldId)
    {
        $this->db->query('SELECT id,value FROM `field_values` WHERE field_id = :fieldId');
        $this->db->bind(':fieldId', $fieldId);
        $fieldValues = $this->db->resultSet();
        return $fieldValues;
    }

    public function addOrder($customerId, $dateDue, $datePlaced, $discount)
    {

        $dateDueString = [];
        $dateDueString[0] = '';
        $dateDueString[1] = '';
        $datePlacedString = [];
        $datePlacedString[0] = '';
        $datePlacedString[1] = '';
        if ($dateDue != null) {
            $dateDueString[0] = ', `due_date`';
            $dateDueString[1] = ',:dateDue';
        }
        if ($datePlaced != null) {
            $datePlacedString[0] = ',`placement_date`';
            $datePlacedString[1] = ',:datePlaced';
        }
        $this->db->query('INSERT INTO `sales_orders` ( `customer_id`,`discount`' . $dateDueString[0] . $datePlacedString[0] . ') VALUES (:customerId,:discount' . $dateDueString[1] . $datePlacedString[1] . ')');
        $this->db->bind(':customerId', $customerId);
        $this->db->bind(':discount', $discount);
        if ($dateDue != null) {
            $this->db->bind(':dateDue', $dateDue);
        }
        if ($datePlaced != null) {
            $this->db->bind(':datePlaced', $datePlaced);

        }
        $this->db->execute();
        $orderId = $this->db->getLastInsertedId();
//        $getProcessesTypesQuery = 'SELECT id FROM process_types WHERE product_type_id = :productTypeId';
//        $this->db->query($getProcessesTypesQuery);
//        $this->db->bind(':productTypeId', $productTypeId);
//        $processTypes = $this->db->resultSet();
//        foreach ($processTypes as $processType) {
//            $this->db->query('INSERT INTO processes (process_id, order_id) VALUES (:processId,:orderId)');
//            $this->db->bind(':processId', $processType->id);
//            $this->db->bind(':orderId', $orderId);
//            $this->db->execute();
//        }
        return $orderId;
    }

    public function addItem($orderId, $productId, $productType, $quantity, $price, $priceCurrencyId)
    {


        $this->db->query('INSERT INTO `sales_items` ( `sales_order_id`,`product_id`,`product_type`,`quantity`,`price`,`price_currency`) VALUES (:orderId,:productId,:productType,:quantity,:price,:priceCurrency)');
        $this->db->bind(':orderId', $orderId);
        $this->db->bind(':productId', $productId);
        $this->db->bind(':productType', $productType);
        $this->db->bind(':quantity', $quantity);
        $this->db->bind(':price', $price);
        $this->db->bind(':priceCurrency', $priceCurrencyId);
        $this->db->execute();
        $itemId = $this->db->getLastInsertedId();
        return $itemId;
    }

    public function addItemProcesses($itemId, $productId)
    {
        //todo: add productType stuff
        $this->db->query('SELECT id FROM processes WHERE product_id = :productId');
        $this->db->bind(':productId', $productId);
        $results = $this->db->resultSet();
        foreach ($results as $result) {
            $this->db->query('INSERT INTO sales_item_processes(sale_item_id, process_id) VALUES (:itemId,:processId)');
            $this->db->bind(':itemId', $itemId);
            $this->db->bind(':processId', $result->id);
            $this->db->execute();
        }
        return 1;
    }

    public function updateItemProcess( $salesItemProcessId, $processStatus)
    {
    $this->db->query('update `sales_item_processes` set status = :status where id = :salesItemId');
    $this->db->bind(':status',$processStatus);
    $this->db->bind(':salesItemId',$salesItemProcessId);
    $this->db->bind(':status',$processStatus);
    $this->db->execute();
    }

    public function addFieldValue($fieldId, $fieldType, $fieldValue)
    {

        $this->db->query('INSERT INTO `field_values` (field_id,field_type, value) VALUES (:fieldId,:fieldType,:fieldValue);');
        $this->db->bind(':fieldId', $fieldId);
        $this->db->bind(':fieldType', $fieldType);
        $this->db->bind(':fieldValue', $fieldValue);
        $this->db->execute();
        return $this->db->getLastInsertedId();
    }

    public function addItemValue($itemId, $fieldValueId)
    {

        $this->db->query('INSERT INTO `sales_item_values` (sale_item_id,field_value) VALUES (:itemId,:fieldValueId);');
        $this->db->bind(':itemId', $itemId);
        $this->db->bind(':fieldValueId', $fieldValueId);
        return $this->db->execute();
    }

    public function addFile($fileDetails)
    {
        //name
        //fieldTypeId
        //orderId

        $salesItemId = $fileDetails['itemId'];
        $name = $fileDetails['name'];
        $fieldTypeId = $fileDetails['fieldTypeId'];
        $fieldId = $fileDetails['fieldId'];
        $this->db->query('INSERT INTO `field_values` (field_id, field_type, value) VALUES (:fieldId, :fieldTypeId, :name)');
        $this->db->bind(':name', $name);
        $this->db->bind(':fieldId', $fieldId);
        $this->db->bind(':fieldTypeId', $fieldTypeId);
        $this->db->execute();
        return $this->db->getLastInsertedId();
//        }
//        else {
//            return 'error : invalid option type';
//        }
    }

    public function updateFileURL($id, $url)
    {

        $this->db->query('UPDATE field_values SET value = :url WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->bind(':url', $url);
        return $this->db->execute();
    }

    public function updateOrder($orderDetails)
    {
        $table = 'sales_orders';
        $columns = $orderDetails;
        $primaryKeyName = 'id';
        $primaryKeyValue = $orderDetails['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updateItemQuantity($itemDetails)
    {
        $table = 'sales_items';
        $columns = $itemDetails;
        $primaryKeyName = 'id';
        $primaryKeyValue = $itemDetails['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updateSalesItemValue($salesItemValueId, $value, $type)
    {
        if ($type == 'free') {
            $query = 'SELECT field_value AS fieldValueId FROM sales_item_values WHERE id = :salesItemValueId';
            $this->db->query($query);
            $this->db->bind(':salesItemValueId', $salesItemValueId);
            $fieldValue = $this->db->single()->fieldValueId;
            $query = 'UPDATE field_values SET value = :fieldValue WHERE id = :fieldValueId';
            $this->db->query($query);
            $this->db->bind(':fieldValue', $value);
            $this->db->bind(':fieldValueId', $fieldValue);
            return $this->db->execute();
        }
        else {
            $query = 'UPDATE sales_item_values SET field_value = :fieldValue WHERE id = :salesItemValueId';
            $this->db->query($query);
            $this->db->bind(':fieldValue', $value);
            $this->db->bind(':salesItemValueId', $salesItemValueId);
            return $this->db->execute();

        }
    }


}