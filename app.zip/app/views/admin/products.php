<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 29/04/20
 * Time: 2:40 PM
 */
?>


<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-around">

        <div class="col-12">
            <div id="products_table_container" class="col-12">
                <?php
                $table_columns = ['Product ', 'Description', "Details"];
                $table_properties = ["tableId" => "datatable_products", "title" => 'Products', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

<?php
$pane_properties = [];
$pane_properties['formName'] = 'addProductForm';
$pane_properties['title'] = 'Product';
$pane_properties['modalTitle'] = 'Add Prouct';
$pane_properties['itemName'] = 'Product';
$values = [
    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.newProduct().title',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Code',
        'name' => 'code',
        'value' => '$root.newProduct().code',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Description',
        'name' => 'description',
        'value' => '$root.newProduct().description',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Price',
        'name' => 'price',
        'value' => '$root.newProduct().price',
        'type' => 'number',
        'enable' => 'false',
        'required' => 'false']


];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_add_item_modal.php');;
?>

<?php
$pane_properties = [];
$pane_properties['formName'] = 'editCurrentProductForm';
$pane_properties['title'] = '$root.currentProduct().title()';
$pane_properties['modalTitle'] = '$root.currentProduct().title()';
$pane_properties['itemName'] = 'Product';
$pane_properties['modalSizeClass'] = 'modal-xl';
$pane_properties['emptyValueCheck'] = '$root.currentProduct().id() != \'\'';
$pane_properties['formName'] = 'editCurrentProductForm';
$pane_properties['resetFunction'] = '$root.resetCurrentProduct';
$pane_properties['submitFunction'] = '$root.submitEditProduct';


$values = [
    ['title' => 'Title',
        'name' => 'title',
        'value' => '$root.currentProduct().title',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'true'],

    ['title' => 'Code',
        'name' => 'code',
        'value' => '$root.currentProduct().code',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Description',
        'name' => 'description',
        'value' => '$root.currentProduct().description',
        'type' => 'text',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'Price',
        'name' => 'price',
        'value' => '$root.currentProduct().price',
        'type' => 'number',
        'enable' => 'false',
        'required' => 'false'],

    ['title' => 'DELETE',
        'name' => 'delete',
        'buttonClass' => 'btn btn-danger w-50',
        'type' => 'button',
        'enable' => 'true',
        'buttonClick' => '$root.deleteCurrentProduct',
        'enableHandle' => '$root.currentProduct().enableDelete',
        'required' => 'false']

];
$pane_properties['values'] = $values;
include(APPROOT . '/views/partials/_object_details_modal.php');
?>

