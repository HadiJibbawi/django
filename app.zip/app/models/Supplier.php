<?php

class supplier
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllsuppliers()
    {
        $this->db->query('SELECT s.id AS id,s.first_name AS firstName,s.middle_name AS middleName, s.last_name AS lastName, s.address AS address,at.title AS supplierTitle,s.job as supplierJobId,sj.title as supplierJob,at.id AS supplierTitleId,sg.title AS supplierGroup,sg.id AS supplierGroupId,sc.name AS supplierCompany,sc.id AS supplierCompanyId FROM suppliers s LEFT JOIN supplier_titles at ON s.title = at.id LEFT JOIN supplier_groups sg ON s.supplier_group = sg.id LEFT JOIN supplier_companies sc ON s.company = sc.id left join supplier_jobs sj on s.job = sj.id');
        $suppliers = $this->db->resultSet();
        foreach ($suppliers as $supplier) {
            $supplier->phoneNumbers = $this->getsupplierPhoneNumbers($supplier->id);
            $supplier->emailAddresses = $this->getsupplierEmailAddresses($supplier->id);
        }
        return $suppliers;
    }

    public function getAllPhoneNumberCountryCodes()
    {
        $this->db->query('SELECT id,country,code FROM phone_number_country_codes');
        $phoneNumberCountryCodes = $this->db->resultSet();
        return $phoneNumberCountryCodes;
    }

    public function getsupplierPhoneNumberTypes()
    {
        $this->db->query('SELECT id,type FROM supplier_phone_number_types');
        $phoneNumberTypes = $this->db->resultSet();
        return $phoneNumberTypes;
    }

    public function getsupplierEmailAddressTypes()
    {
        $this->db->query('SELECT id,type FROM supplier_email_address_types');
        $emailAddressTypes = $this->db->resultSet();
        return $emailAddressTypes;
    }

    public function getsupplierTitles()
    {
        $this->db->query('SELECT id,title,description FROM supplier_titles');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getsupplierGroups()
    {
        $this->db->query('SELECT id,title,description FROM supplier_groups');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getsupplierJobs()
    {
        $this->db->query('SELECT id,title,description FROM supplier_jobs');
        $jobs = $this->db->resultSet();
        return $jobs;
    }

    public function getsupplierCompanies()
    {
        $this->db->query('SELECT id,name,address,business_type FROM supplier_companies');
        $titles = $this->db->resultSet();
        return $titles;
    }

    public function getsupplierPhoneNumbers($supplierId)
    {
        $this->db->query('SELECT apn.id AS id, apnt.type AS phoneNumberType,apnt.id AS phoneNumberTypeId,apn.area_code AS areaCode,apn.country_code AS countryCode,pncc.code as countryCodeLiteral,apn.subscriber_number AS subscriberNumber,apn.extension AS extension,apn.notes AS notes FROM `supplier_phone_numbers` apn LEFT JOIN supplier_phone_number_types apnt ON apn.type = apnt.id left join phone_number_country_codes pncc on apn.country_code = pncc.id WHERE apn.supplier_id = :supplierId');
        $this->db->bind(':supplierId', $supplierId);
        $supplierPhoneNumbers = $this->db->resultSet();
        return $supplierPhoneNumbers;
    }

    public function getsupplierEmailAddresses($supplierId)
    {
        $this->db->query('SELECT cea.id AS id, ceat.type AS emailAddressType,ceat.id AS emailAddressTypeId,cea.address AS emailAddress FROM `supplier_email_addresses` cea LEFT JOIN supplier_email_address_types ceat ON cea.type = ceat.id WHERE cea.supplier_id = :supplierId');
        $this->db->bind(':supplierId', $supplierId);
        $supplierEmailAddresses = $this->db->resultSet();
        return $supplierEmailAddresses;
    }

    public function addsupplier($supplier)
    {
        $firstName = $supplier['firstName'];
        $middleName = $supplier['middleName'];
        $lastName = $supplier['lastName'];
        $title = $supplier['supplierTitle'];
        $address = $supplier['address'];
        $supplierGroup = $supplier ['supplierGroup'];
        $supplierCompany = $supplier['supplierCompany'];
        $supplierJob = $supplier['supplierJob'];
        $this->db->query('INSERT INTO `suppliers` (title, first_name, middle_name, last_name, company,job, supplier_group, address) VALUES (:title, :firstName, :middleName, :lastName, :supplierCompany, :supplierJob, :supplierGroup, :address)');
        $this->db->bind(':firstName', $firstName);
        $this->db->bind(':middleName', $middleName);
        $this->db->bind(':lastName', $lastName);
        $this->db->bind(':title', $title);
        $this->db->bind(':supplierJob', $supplierJob);
        $this->db->bind(':address', $address);
        $this->db->bind(':supplierGroup', $supplierGroup);
        $this->db->bind(':supplierCompany', $supplierCompany);
        return $this->db->execute();
    }

    public function addPhoneNumberType($phoneNumberType)
    {
        $this->db->query('INSERT INTO `supplier_phone_number_types` (type) VALUES (:type)');
        $this->db->bind(':type', $phoneNumberType);
        return $this->db->execute();
    }

    public function addEmailAddressType($emailAddressType)
    {
        $this->db->query('INSERT INTO `supplier_email_address_types` (type) VALUES (:type)');
        $this->db->bind(':type', $emailAddressType);
        return $this->db->execute();
    }


    public function updatesupplier($supplier)
    {

        $table = 'suppliers';
        $columns = $supplier;
        $primaryKeyName = 'id';
        $primaryKeyValue = $supplier['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }


    public function updatePhoneNumber($phoneNumber)
    {

        $table = 'supplier_phone_numbers';
        $columns = $phoneNumber;
        $primaryKeyName = 'id';
        $primaryKeyValue = $phoneNumber['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function updateEmailAddress($emailAddress)
    {

        $table = 'supplier_email_addresses';
        $columns = $emailAddress;
        $primaryKeyName = 'id';
        $primaryKeyValue = $emailAddress['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }

    public function addsupplierPhoneNumber($supplierId,$phoneNumber){
        $table = 'supplier_phone_numbers';
        $columns = $phoneNumber;
        $columns['supplier_id'] = $supplierId;
        return $this->db->insertIntoTable($table,$columns);
    }

    public function addsupplierEmailAddress($supplierId,$emailAddress){
        $table = 'supplier_email_addresses';
        $columns = $emailAddress;
        $columns['supplier_id'] = $supplierId;
        return $this->db->insertIntoTable($table,$columns);
    }
    public function deletesupplierPhoneNumber($phoneNumberId){
        $this->db->query('delete from supplier_phone_numbers WHERE id = :phoneNumberId');
        $this->db->bind(':phoneNumberId',$phoneNumberId);
        return $this->db->execute();
    }

    public function deletesupplier($id)
    {
        $this->db->query('DELETE FROM `suppliers` WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->execute();
        $this->db->query('delete from supplier_phone_numbers WHERE supplier_id = :supplierId');
        $this->db->bind(':supplierId', $id);
        $this->db->execute();
        $this->db->query('delete from supplier_email_addresses WHERE supplier_id = :supplierId');
        $this->db->bind(':supplierId', $id);
        return $this->db->execute();
        //todo check if supplier corresponds to other things
    }

}