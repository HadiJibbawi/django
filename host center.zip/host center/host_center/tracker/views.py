
from django.shortcuts import render, redirect
from tracker.forms import ScheduleForm, ActualScheduleForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.shortcuts import render
from home.models import UserProfile, User
from tracker.models import Schedule, Actual_Schedule
from django.contrib.sessions.backends.base import SessionBase
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
import datetime

# Create your views here.

def index(request):
    username = request.user.username
    user = request.user
    user_profile = UserProfile.objects.get(user=user)
    schedule = None
    count = 0
    schedule = Schedule.objects.filter(user=user)

    count = schedule.count()
    days = []
    
    if count == 0:
        schedule = None
        
    if schedule:
        if not schedule.filter(work_day='Monday').exists():
            days.append('Monday')
        if not schedule.filter(work_day='Tuesday').exists():
            days.append('Tuesday')
        if not schedule.filter(work_day='Wednesday').exists():
            days.append('Wednesday')
        if not schedule.filter(work_day='Thursday').exists():
            days.append('Thursday')
        if not schedule.filter(work_day='Friday').exists():
            days.append('Friday') 
    else:
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
            
    return render(request, 'tracker/profile.html', {'user':user,
                                                     'user_profile':user_profile,
                                                     'schedule':schedule,
                                                     'count':count,
                                                     'days':days})
    
@login_required
def special(request):
    return HttpResponse("You are logged in!")

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))    
    

def actual_schedule(request):
    user = request.user
    actual_schedule = Actual_Schedule.objects.filter(user=user).order_by('-schedule_date')
    count1 = 0
    count1 = actual_schedule.count
    today_schedule = None
    if count1 == 0:
        actual_schedule = None
    return render(request, 'tracker/actual_schedule.html', {'user':user,
                                                     'count1':count1,
                                                     'today_schedule':today_schedule,
                                                     'actual_schedule':actual_schedule})    

def add_today(request):
    registered = False
    if request.method == 'POST':
        user = request.user
        schedule_date = request.POST.get('schedule_date')
        dt= datetime.datetime.strptime(schedule_date, "%Y-%m-%d")
        schedule_day=dt.strftime("%A")
        entrance_time = request.POST.get('entrance_time')
        exit_time = request.POST.get('exit_time')
        is_holiday = request.POST.get('is_holiday')
        reason = request.POST.get('reason')

        try:
            get_schedule = Actual_Schedule.objects.get(user=user,schedule_date=schedule_date)
        except ObjectDoesNotExist:
            actual_schedule = Actual_Schedule(user=request.user, schedule_date=schedule_date,schedule_day=schedule_day, entrance_time=entrance_time, exit_time=exit_time, is_holiday=is_holiday, reason=reason)
            actual_schedule.save()
            registered = True
            return HttpResponseRedirect(reverse('tracker:actual_schedule')) 
        get_schedule.entrance_time = entrance_time
        get_schedule.exit_time = exit_time
        get_schedule.is_holiday = is_holiday
        get_schedule.reason = reason
        get_schedule.save()
        registered = True    
    return HttpResponseRedirect(reverse('tracker:actual_schedule'))  
    
      
    
    
def register(request):
    registered = False
    if request.method == 'POST':
        schedule_form = ScheduleForm(data=request.POST)
        day = request.POST.get('work_day')
        start_time = request.POST.get('start_time')
        end_time = request.POST.get('end_time')
        weekend = request.POST.get('weekend')
        try: 
            schedule = Schedule(user=request.user, work_day=day, start_time=start_time, end_time=end_time, weekend=weekend)
            schedule.save()
            registered = True
        except:
            print(schedule_form.errors)
    else:
        schedule_form = ScheduleForm()
        
    return HttpResponseRedirect(reverse('tracker:index'))  
   
def edit_schedule(request):
    work_day = request.POST.get('work_day')
    start_time = request.POST.get('start_time')
    end_time = request.POST.get('end_time')
    weekend = request.POST.get('weekend')
    user = request.user
    schedule = Schedule.objects.get(user=user,work_day=work_day)
    if start_time:
        schedule.start_time = start_time
    if end_time:    
        schedule.end_time = end_time
    if weekend:    
        schedule.weekend = weekend
    schedule.save()
    return HttpResponseRedirect(reverse('tracker:index')) 
 ## help report view   
def late_days(user):
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    total_days_late = 0
    start_mon = start_tue = start_wed = start_thu = start_fri = None
    for sd in schedule:
        if sd.work_day == 'Monday':
            start_mon = sd.start_time
        if sd.work_day == 'Tuesday':
            start_tue = sd.start_time
        if sd.work_day == 'Wednesday':
            start_wed = sd.start_time
        if sd.work_day == 'Thursday':
            start_thu = sd.start_time
        if sd.work_day == 'Friday':
            start_fri = sd.start_time 
    if start_mon:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0).exists():    
            total_days_late = total_days_late +  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0,entrance_time__gt=start_mon).count()
    if start_tue:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0).exists():    
            total_days_late = total_days_late +  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0,entrance_time__gt=start_tue).count()
    if start_wed:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0).exists():    
            total_days_late = total_days_late +  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0,entrance_time__gt=start_wed).count()
    if start_thu:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0).exists():    
            total_days_late = total_days_late +  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0,entrance_time__gt=start_thu).count()   
    if start_fri:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0).exists():    
            total_days_late = total_days_late +  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0,entrance_time__gt=start_fri).count()  
    return total_days_late

## help report view   
def early_days(user):
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    total_days_early = 0
    end_mon = end_tue = end_wed = end_thu = end_fri = None
    for sd in schedule:
        if sd.work_day == 'Monday':
            end_mon = sd.end_time
        if sd.work_day == 'Tuesday':
            end_tue = sd.end_time
        if sd.work_day == 'Wednesday':
            end_wed = sd.end_time
        if sd.work_day == 'Thursday':
            end_thu = sd.end_time
        if sd.work_day == 'Friday':
            end_fri = sd.end_time 
    if end_mon:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0).exists():    
            total_days_early = total_days_early +  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0,exit_time__lt=end_mon).count()
    if end_tue:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0).exists():    
            total_days_early = total_days_early +  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0,exit_time__lt=end_tue).count()
    if end_wed:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0).exists():    
            total_days_early = total_days_early +  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0,exit_time__lt=end_wed).count()
    if end_thu:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0).exists():    
            total_days_early = total_days_early +  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0,exit_time__lt=end_thu).count()   
    if end_fri:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0).exists():    
            total_days_early = total_days_early +  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0,exit_time__lt=end_fri).count()  
    return total_days_early
def overtime_minutes(user):
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    total_extra_minutes = 0
    end_mon = end_tue = end_wed = end_thu = end_fri = None
    for sd in schedule:
        if sd.work_day == 'Monday':
            end_mon = sd.end_time
        if sd.work_day == 'Tuesday':
            end_tue = sd.end_time
        if sd.work_day == 'Wednesday':
            end_wed = sd.end_time
        if sd.work_day == 'Thursday':
            end_thu = sd.end_time
        if sd.work_day == 'Friday':
            end_fri = sd.end_time 
    if end_mon:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0,exit_time__gt=end_mon)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_mon)
                timeDifference = A - B
                total_extra_minutes = total_extra_minutes +  ( timeDifference.total_seconds() / 60)
    if end_tue:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0,exit_time__gt=end_tue)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_tue)
                timeDifference = A - B
                total_extra_minutes = total_extra_minutes +  ( timeDifference.total_seconds() / 60)
    if end_wed:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0,exit_time__gt=end_wed)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_wed)
                timeDifference = A - B
                total_extra_minutes = total_extra_minutes +  ( timeDifference.total_seconds() / 60)
    if end_thu:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0,exit_time__gt=end_thu)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_thu)
                timeDifference = A - B
                total_extra_minutes = total_extra_minutes +  ( timeDifference.total_seconds() / 60)
    if end_fri:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0,exit_time__gt=end_fri)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_fri)
                timeDifference = A - B
                total_extra_minutes = total_extra_minutes +  ( timeDifference.total_seconds() / 60)            
    return total_extra_minutes
def late_minutes(user):
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    total_late_minutes = 0
    start_mon = start_tue = start_wed = start_thu = start_fri = None
    for sd in schedule:
        if sd.work_day == 'Monday':
            start_mon = sd.start_time
        if sd.work_day == 'Tuesday':
            start_tue = sd.start_time
        if sd.work_day == 'Wednesday':
            start_wed = sd.start_time
        if sd.work_day == 'Thursday':
            start_thu = sd.start_time
        if sd.work_day == 'Friday':
            start_fri = sd.start_time 
    if start_mon:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0,entrance_time__gt=start_mon)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.entrance_time)
                B = datetime.datetime.combine(datetime.date.today(), start_mon)
                timeDifference = A - B
                total_late_minutes = total_late_minutes +  ( timeDifference.total_seconds() / 60)
    if start_tue:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0,entrance_time__gt=start_tue)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.entrance_time)
                B = datetime.datetime.combine(datetime.date.today(), start_tue)
                timeDifference = A - B
                total_late_minutes = total_late_minutes +  ( timeDifference.total_seconds() / 60)
    if start_wed:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0,entrance_time__gt=start_wed)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.entrance_time)
                B = datetime.datetime.combine(datetime.date.today(), start_wed)
                timeDifference = A - B
                total_late_minutes = total_late_minutes +  ( timeDifference.total_seconds() / 60)
    if start_thu:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0,entrance_time__gt=start_thu)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.entrance_time)
                B = datetime.datetime.combine(datetime.date.today(), start_thu)
                timeDifference = A - B
                total_late_minutes = total_late_minutes +  ( timeDifference.total_seconds() / 60)
    if start_fri:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0,entrance_time__gt=start_fri)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.entrance_time)
                B = datetime.datetime.combine(datetime.date.today(), start_fri)
                timeDifference = A - B
                total_late_minutes = total_late_minutes +  ( timeDifference.total_seconds() / 60)            
    return total_late_minutes
def early_exit_minutes(user):
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    total_early_exit_minutes = 0
    end_mon = end_tue = end_wed = end_thu = end_fri = None
    for sd in schedule:
        if sd.work_day == 'Monday':
            end_mon = sd.end_time
        if sd.work_day == 'Tuesday':
            end_tue = sd.end_time
        if sd.work_day == 'Wednesday':
            end_wed = sd.end_time
        if sd.work_day == 'Thursday':
            end_thu = sd.end_time
        if sd.work_day == 'Friday':
            end_fri = sd.end_time 
    if end_mon:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Monday',is_holiday=0,exit_time__lt=end_mon)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_mon)
                timeDifference = B - A
                total_early_exit_minutes = total_early_exit_minutes +  ( timeDifference.total_seconds() / 60)
    if end_tue:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Tuesday',is_holiday=0,exit_time__lt=end_tue)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_tue)
                timeDifference = B - A
                total_early_exit_minutes = total_early_exit_minutes +  ( timeDifference.total_seconds() / 60)
    if end_wed:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Wednesday',is_holiday=0,exit_time__lt=end_wed)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_wed)
                timeDifference = B - A
                total_early_exit_minutes = total_early_exit_minutes +  ( timeDifference.total_seconds() / 60)
    if end_thu:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Thursday',is_holiday=0,exit_time__lt=end_thu)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_thu)
                timeDifference = B - A
                total_early_exit_minutes = total_early_exit_minutes +  ( timeDifference.total_seconds() / 60)
    if end_fri:
        if  Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0).exists(): 
            at = Actual_Schedule.objects.filter(user=user,schedule_day='Friday',is_holiday=0,exit_time__lt=end_fri)
            for a in at:
                
                A = datetime.datetime.combine(datetime.date.today(), a.exit_time)
                B = datetime.datetime.combine(datetime.date.today(), end_fri)
                timeDifference = B - A
                total_early_exit_minutes = total_early_exit_minutes +  ( timeDifference.total_seconds() / 60)            
    return total_early_exit_minutes           
def reports(request):
    user = request.user
    schedule = Schedule.objects.filter(user=user)
    actual_schedule = Actual_Schedule.objects.filter(user=user)
    nb_holidays = 0
    nb_vaccation = nb_sickness = nb_official = nb_covid19 = nb_unspecified = 0
    nb_holidays = Actual_Schedule.objects.filter(user=user,is_holiday=1).count()

    nb_vaccation = actual_schedule.filter(is_holiday=1,reason='Vacation').count()
    nb_sickness = actual_schedule.filter(is_holiday=1,reason='Sickness').count()
    nb_official = actual_schedule.filter(is_holiday=1,reason='Official').count()
    nb_covid19 = actual_schedule.filter(is_holiday=1,reason='COVID-19').count()
    nb_unspecified = actual_schedule.filter(is_holiday=1,reason='Unspecified').count()

    total_days_late = 0
    total_days_early = 0
    total_extra_minutes = 0
    total_late_minutes = 0
    total_early_exit_minutes = 0
    net_minutes = 0
    end_mon = end_tue = end_wed = end_thu = end_fri = None
    

    total_days_late = late_days(user)    
    total_days_early = early_days(user) 
    total_extra_minutes = overtime_minutes(user)
    total_late_minutes = late_minutes(user)
    total_early_exit_minutes = early_exit_minutes(user)
    net_minutes = total_extra_minutes - (total_late_minutes + total_early_exit_minutes)
    return render(request, 'tracker/reports.html',{'nb_holidays':nb_holidays,'nb_vaccation':nb_vaccation,'nb_sickness':nb_sickness,
                                                   'nb_official':nb_official,'nb_covid19':nb_covid19,'nb_unspecified':nb_unspecified,
                                                   'total_days_late':total_days_late, 'total_days_early':total_days_early,
                                                   'total_extra_minutes':total_extra_minutes, 'total_late_minutes':total_late_minutes,
                                                   'total_early_exit_minutes':total_early_exit_minutes, 'net_minutes':net_minutes,
                                                    }) 
                                                    
              