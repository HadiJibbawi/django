from django.conf.urls import url
from tracker import views

app_name = 'tracker'

urlpatterns=[
    url(r'index/$', views.index, name='index'),
    url(r'^register/$', views.register, name='register'),
    url(r'^edit_schedule/$', views.edit_schedule, name='edit_schedule'),
    url(r'^add_today/$', views.add_today, name='add_today'),
    url(r'actual_schedule/$', views.actual_schedule, name='actual_schedule'),
    url(r'reports/$', views.reports, name='reports'),
]